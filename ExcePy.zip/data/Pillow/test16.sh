#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard 70a50907c293f68ee9787b7663d78cb92291aa1c
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test16.py
#test-Traceback
#  File "test16.py", line 5, in <module>
#    im.save("test16_temp.jpg", qtables=qtables, subsampling=0)
#  File "./Pillow/PIL/Image.py", line 1657, in save
#    save_handler(self, fp, filename)
#  File "./Pillow/PIL/JpegImagePlugin.py", line 501, in _save
#    if qtables in presets:
#TypeError: unhashable type: 'dict'
#test-errorfilepath
#./Pillow/PIL/JpegImagePlugin.py
