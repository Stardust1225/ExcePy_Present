from PIL import ImageFile

with open('test14.jp2', 'rb') as f:
    data = f.read()

p = ImageFile.Parser()
p.feed(data)
