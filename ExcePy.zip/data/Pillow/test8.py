from PIL import Image

file = "test8.xpm"
data = open(file, "rb").read()

im = Image.open(file)
im.load()
