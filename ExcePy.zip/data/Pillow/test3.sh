#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard c9faa9caa5bee7983970e383773635bf73534980
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test3.py
#test-Traceback
#  File "test3.py", line 19, in <module>
#    ImageOps.fit(lena("RGB").resize((1,1)), (35,35))
#  File "./Pillow/PIL/ImageOps.py", line 306, in fit
#    liveAreaAspectRatio = float(liveSize[0])/float(liveSize[1])
#ZeroDivisionError: float division by zero
#test-errorfilepath
#./Pillow/PIL/ImageOps.py
