from PIL import Image, ImageFile

ImageFile.LOAD_TRUNCATED_IMAGES = True
img = Image.open("test13.gif")
img.convert("RGB")
