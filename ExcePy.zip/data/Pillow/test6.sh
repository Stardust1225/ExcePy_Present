#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard 001bee40ab42373cb3d120f6b7143d2b39aabff3
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test6.py
#test-Traceback
#  File "test6.py", line 5, in <module>
#    im1 = Image.fromarray(ar1)
#  File "./Pillow/PIL/Image.py", line 2167, in fromarray
#    raise TypeError("Cannot handle this data type")
#TypeError: Cannot handle this data type
#test-errorfilepath
#./Pillow/PIL/Image.py
