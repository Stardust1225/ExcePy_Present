o = object()
setattr(o, b'foo', b'bar')
