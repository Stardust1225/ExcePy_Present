#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard 488691bda4b92711aa3b96eebe074febc3375633
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test9.py
#test-Traceback
#  File "test9.py", line 4, in <module>
#    dict(img.tag)
#  File "./Pillow/PIL/TiffImagePlugin.py", line 887, in __getitem__
#    self._setitem(tag, handler(self, data, legacy), legacy)
#  File "./Pillow/PIL/TiffImagePlugin.py", line 556, in _setitem
#    dest[tag], = values
#ValueError: too many values to unpack (expected 1)
#test-errorfilepath
#./Pillow/PIL/TiffImagePlugin.py
