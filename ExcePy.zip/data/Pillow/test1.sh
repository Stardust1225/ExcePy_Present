#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard 66b369aac8e822d7c750461e4043bba2ba3fa8c5
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test1.py
#test-Traceback
#  File "test1.py", line 8, in <module>
#    im.close()
#  File "./Pillow/PIL/Image.py", line 542, in close
#    if Image.DEBUG:
#AttributeError: type object 'Image' has no attribute 'DEBUG'
#test-errorfilepath
#./Pillow/PIL/Image.py

