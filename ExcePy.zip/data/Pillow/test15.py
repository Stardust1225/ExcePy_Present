from PIL import ImageMorph

mop = ImageMorph.MorphOp(patterns=['1:(... ... ...)->0',
                                   'N:(00. 01. ...)->1'])
