#!/bin/bash
cd Pillow
git clean -f
git reset --hard 92507e5d0a692ffc3a5e61f0302a4d29ba3d6d42
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test7.py
#test-Traceback
#  File "test7.py", line 18, in <module>
#    box_size_b = draw.textsize(word)
#  File "./Pillow/PIL/ImageDraw.py", line 281, in textsize
#    return font.getsize(text)
#  File "./Pillow/PIL/ImageFont.py", line 174, in getsize
#    w, h = self.font.getsize(text)[0]
#TypeError: 'int' object is not iterable
#test-errorfilepath
#./Pillow/PIL/ImageFont.py
