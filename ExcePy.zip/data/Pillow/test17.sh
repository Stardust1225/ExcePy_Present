#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard a803528c8acf3015dd45284dea1e070efc7da9e9
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test17.py
#test-Traceback
#  File "test17.py", line 20, in <module>
#    box_size_b = draw.textsize(word)
#  File "./Pillow/PIL/ImageDraw.py", line 281, in textsize
#    return font.getsize(text)
#  File "./Pillow/PIL/ImageFont.py", line 174, in getsize
#    w, h = self.font.getsize(text)[0]
#TypeError: 'int' object is not iterable
#test-errorfilepath
#./Pillow/PIL/ImageFont.py
