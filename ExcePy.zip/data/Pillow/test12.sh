#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard 1f3c9f4feb5f4685d947eb526489d186e0c58b13
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test12.py
#test-Traceback
#  File "test12.py", line 20, in <module>
#    newimg = ImageOps.fit(lena("RGB").resize((100, 1)), (35, 35))
#  File "./Pillow/PIL/ImageOps.py", line 311, in fit
#    liveAreaAspectRatio = float(liveSize[0])/float(liveSize[1])
#ZeroDivisionError: float division by zero
#test-errorfilepath
#./Pillow/PIL/ImageOps.py
