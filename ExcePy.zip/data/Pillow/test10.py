from PIL import ImageFilter, Image

im = Image.open('test10.tif')
im = im.convert('L')
im = im.filter(ImageFilter.GaussianBlur(4))
im.close()