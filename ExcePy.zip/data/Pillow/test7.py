from PIL import Image, ImageDraw, ImageFont

font_path = "test7.ttf"
font_size = 20

img_grey = Image.new("L", (100, 100))
draw = ImageDraw.Draw(img_grey)
word = "testing"
font = ImageFont.truetype(font_path, font_size)

orientation = Image.ROTATE_90
transposed_font = ImageFont.TransposedFont(font, orientation=orientation)

draw.setfont(font)
box_size_a = draw.textsize(word)

draw.setfont(transposed_font)
box_size_b = draw.textsize(word)
