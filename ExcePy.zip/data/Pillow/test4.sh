#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard c41ec5b115142faceafef68d5a523f5e1d1ada17
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test4.py
#test-Traceback
#  File "test4.py", line 2, in <module>
#    setattr(o, b'foo', b'bar')
#TypeError: attribute name must be string, not 'bytes'
#test-errorfilepath
#test4.py
