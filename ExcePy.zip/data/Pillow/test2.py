from PIL import Image
from PIL import ImageFile
im = Image.open("test2.jpg")
info = im._getexif()
