#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard a5ae40c1b43ab97df21ff3655caebf5e66c8813b
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test10.py
#test-Traceback
#  File "test10.py", line 6, in <module>
#    im.close()
#  File "./Pillow/PIL/Image.py", line 542, in close
#    if Image.DEBUG:
#AttributeError: type object 'Image' has no attribute 'DEBUG'
#test-errorfilepath
#./Pillow/PIL/Image.py
