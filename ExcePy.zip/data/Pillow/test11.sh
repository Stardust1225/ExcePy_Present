#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard b8ec793898c9cebd9f3b109d4083be09b17f8abd
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test11.py
#test-Traceback
#  File "test11.py", line 4, in <module>
#    im.thumbnail((75, 75))
#  File "./Pillow/src/PIL/Image.py", line 2280, in thumbnail
#    y = round_aspect(x / aspect, key=lambda n: abs(aspect - x / n))
#  File "./Pillow/src/PIL/Image.py", line 2273, in round_aspect
#    return max(min(math.floor(number), math.ceil(number), key=key), 1)
#  File "./Pillow/src/PIL/Image.py", line 2280, in <lambda>
#    y = round_aspect(x / aspect, key=lambda n: abs(aspect - x / n))
#ZeroDivisionError: division by zero
#test-errorfilepath
#./Pillow/src/PIL/Image.py
