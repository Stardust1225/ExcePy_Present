from PIL import Image

im = Image.open("test16.jpg")
qtables = im.quantization
im.save("test16_temp.jpg", qtables=qtables, subsampling=0)
