from PIL import Image

im = Image.new("L", (200, 2))
im.thumbnail((75, 75))
