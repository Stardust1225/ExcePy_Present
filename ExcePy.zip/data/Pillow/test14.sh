#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard 0e9f07def99d20e0ccf8bfcafdac8054a53f8589
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test14.py
#test-Traceback
#  File "test14.py", line 7, in <module>
#    p.feed(data)
#  File "./Pillow/src/PIL/ImageFile.py", line 406, in feed
#    im.mode, d, a, im.decoderconfig
#  File "./Pillow/src/PIL/Image.py", line 437, in _getdecoder
#    return decoder(mode, *args + extra)
#TypeError: function takes at most 6 arguments (7 given)
#test-errorfilepath
#./Pillow/src/PIL/Image.py
