#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard 3e6db78f75cf9000c3728616464a95799900c55c
pip3 install -e .
cd ..
python3 test5.py
#test-Traceback
#  File "test5.py", line 7, in <module>
#    p.feed(data)
#  File "./Pillow/src/PIL/ImageFile.py", line 411, in feed
#    im.mode, d, a, im.decoderconfig
#  File "./Pillow/src/PIL/Image.py", line 437, in _getdecoder
#    return decoder(mode, *args + extra)
#TypeError: function takes at most 6 arguments (7 given)
#test-errorfilepath
#./Pillow/src/PIL/Image.py
