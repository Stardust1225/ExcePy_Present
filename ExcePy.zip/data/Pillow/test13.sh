#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard 4308872809de106114c76275b997b3a4484012fc
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test13.py
#test-Traceback
#  File "test13.py", line 5, in <module>
#    img.convert("RGB")
#  File "./Pillow/PIL/Image.py", line 843, in convert
#    self.load()
#  File "./Pillow/PIL/ImageFile.py", line 245, in load
#    if not self.map and (not LOAD_TRUNCATED_IMAGES or t == 0) and e < 0:
#UnboundLocalError: local variable 't' referenced before assignment
#test-errorfilepath
#./Pillow/PIL/ImageFile.py
