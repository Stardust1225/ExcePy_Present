from helper import PillowTestCase
from PIL import ImageFilter, Image
out = PillowTestCase().tempfile(template='temp.tif')
im = Image.open('test1.tif')
im = im.convert('L')
im = im.filter(ImageFilter.GaussianBlur(4))
im.save(out, compression='tiff_adobe_deflate')
im.close()
