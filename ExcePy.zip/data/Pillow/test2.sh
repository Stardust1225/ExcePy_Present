#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard ee794e1501aaa53c157631f6b0941a9bf228f58d
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test2.py
#test-Traceback
#  File "test2.py", line 4, in <module>
#    info = im._getexif()
#  File "./Pillow/PIL/JpegImagePlugin.py", line 381, in _getexif
#    for key, value in info.items():
#  File "/usr/lib/python3.6/_collections_abc.py", line 743, in __iter__
#   for key in self._mapping:
#RuntimeError: dictionary changed size during iteration
#test-errorfilepath
#./Pillow/PIL/JpegImagePlugin.py
