#!/bin/bash
cd Pillow
git clean -xdf
git reset --hard b29326b17534f5fec04c0bec35c2f1eff6499f73
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test8.py
#test-Traceback
#  File "test8.py", line 7, in <module>
#    im.load()
#  File "./Pillow/PIL/ImageFile.py", line 167, in load
#    self.load_prepare()
#  File "./Pillow/PIL/ImageFile.py", line 250, in load_prepare
#    Image.Image.load(self)
#  File "./Pillow/PIL/Image.py", line 619, in load
#    if self.info["transparency_palette"]:
#KeyError: 'transparency_palette'
#./Pillow/PIL/Image.py
