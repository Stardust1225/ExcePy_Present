from PIL import Image

img = Image.open("test9.tif")
dict(img.tag)
