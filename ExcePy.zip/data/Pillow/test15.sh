#!/bin/bash
cd Pillow
git clean -f
git reset --hard 04f28b691e961bff44b269652421f447add04c5c
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test15.py
#test-traceback
#  File "test15.py", line 4, in <module>
#    'N:(00. 01. ...)->1'])
#  File "/home/xin/Documents/Pillow/PIL/ImageMorph.py", line 192, in __init__
#    self.lut = LutBuilder(patterns=patterns).build_lut()
#  File "/home/xin/Documents/Pillow/PIL/ImageMorph.py", line 175, in build_lut
#    self.lut[i] = [0, 1][r]
#TypeError: list indices must be integers or slices, not str
