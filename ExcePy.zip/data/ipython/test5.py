import IPython.core.inputtransformer2 as ipt2


def null_cleanup_transformer(line):
    return []


manager = ipt2.TransformerManager()
manager.cleanup_transforms.insert(0, null_cleanup_transformer)
manager.transform_cell("")
