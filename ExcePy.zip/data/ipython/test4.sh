#!/bin/bash
cd ipython
git clean -xdf
git reset --hard 40b4d0f0cfcc4fd7c26f7e73afa47a093bd44178
git reset --hard HEAD^
pip3 install -e .
cd ..
cd ipython
python3 -m IPython < test4.py
#test-Traceback
#<string> in <module>
#
#/usr/lib/python3.6/bdb.py in Bdb.trace_dispatch(self, frame, event, arg)
#     49     return # None
#     50 if event == 'line':
#---> 51     return self.dispatch_line(frame)
#     52 if event == 'call':
#     53     return self.dispatch_call(frame, arg)
#
#/usr/lib/python3.6/bdb.py in Bdb.dispatch_line(self, frame)
#     67 def dispatch_line(self, frame):
#     68     if self.stop_here(frame) or self.break_here(frame):
#---> 69         self.user_line(frame)
#     70         if self.quitting: raise BdbQuit
#     71     return self.trace_dispatch
#
#/usr/lib/python3.6/pdb.py in Pdb.user_line(self, frame)
#    259     self._wait_for_mainpyfile = False
#    260 if self.bp_commands(frame):
#--> 261     self.interaction(frame, None)
#
#./ipython/IPython/core/debugger.py in Pdb.interaction(self, frame, traceback)
#    289 def interaction(self, frame, traceback):
#    290     try:
#--> 291         OldPdb.interaction(self, frame, traceback)
#    292     except KeyboardInterrupt:
#    293         self.stdout.write('\n' + self.shell.get_exception_only())
#
#/usr/lib/python3.6/pdb.py in Pdb.interaction(self, frame, traceback)
#    350     return
#    351 self.print_stack_entry(self.stack[self.curindex])
#--> 352 self._cmdloop()
#    353 self.forget()
#
#/usr/lib/python3.6/pdb.py in Pdb._cmdloop(self)
#    317 try:
#    318     # keyboard interrupts allow for an easy way to cancel
#    319     # the current command, so allow them during interactive input
#    320     self.allow_kbdint = True
#--> 321     self.cmdloop()
#    322     self.allow_kbdint = False
#    323     break
#
#/usr/lib/python3.6/cmd.py in Cmd.cmdloop(self, intro)
#    136                 line = line.rstrip('\r\n')
#    137     line = self.precmd(line)
#--> 138     stop = self.onecmd(line)
#    139     stop = self.postcmd(stop, line)
#    140 self.postloop()
#
#/usr/lib/python3.6/pdb.py in Pdb.onecmd(self, line)
#    411 """Interpret the argument as though it had been typed in response
#    412 to the prompt.
#    413 
#    414 Checks whether this line is typed at the normal prompt or in
#    415 a breakpoint command list definition.
#    416 """
#    417 if not self.commands_defining:
#--> 418     return cmd.Cmd.onecmd(self, line)
#    419 else:
#    420     return self.handle_command_def(line)
#
#/usr/lib/python3.6/cmd.py in Cmd.onecmd(self, line)
#    215 except AttributeError:
#    216     return self.default(line)
#--> 217 return func(arg)
#
#./ipython/IPython/core/debugger.py in Pdb.do_where(self, arg)
#    615 """w(here)
#    616 Print a stack trace, with the most recent frame at the bottom.
#    617 An arrow indicates the "current frame", which determines the
#   (...)
#    620 Take a number as argument as an (optional) number of context line to
#    621 print"""
#    622 if arg:
#--> 623     context = int(arg)
#    624     self.print_stack_trace(context)
#    625 else:
#
#ValueError: invalid literal for int() with base 10: '= 1'
##test-errorfilepath
#./ipython/IPython/core/debugger.py
