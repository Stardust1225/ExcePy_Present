#!/bin/bash 
cd ipython
git clean -xdf
git reset --hard 023e5b5d3ba3d2f04fbbdd1f911ff2b7f11cefbb
git reset --hard HEAD^
pip3 install -e .
cd ..
cd ipython
python3 -m IPython < test1.py
#test-traceback
#<ipython-input-3-9149c3a18107> in <module>
#----> 1 hv.extension('bokeh')
#
#/usr/local/lib/python3.6/dist-packages/param/parameterized.py in #ParameterizedFunction.__new__(class_, *args, **params)
#   3019         inst = class_.instance()
#   3020         inst.param._set_name(class_.__name__)
#-> 3021         return inst.__call__(*args,**params)
#
#/usr/local/lib/python3.6/dist-packages/holoviews/ipython/__init__.py in #notebook_extension.__call__(self, *args, **params)
#    147             completer.completions_sorting_key = self.completions_sorting_key
#    148         if not p.allow_jedi_completion and hasattr(IPCompleter, 'use_jedi'):
#--> 149             ip.run_line_magic('config', 'IPCompleter.use_jedi = False')
#    151         resources = self._get_resources(args, params)
#    153         Store.display_formats = p.display_formats
#
#/./ipython/IPython/core/interactiveshell.py in #InteractiveShell.run_line_magic(self, magic_name, line, _stack_depth)
#   2315                 kwargs['local_ns'] = sys._getframe(stack_depth).f_locals
#   2316             with self.builtin_trap:
#-> 2317                 result = fn(*args, **kwargs)
#   2318             return result
#
#<decorator-gen-48> in config(self, s)
#
#./ipython/IPython/core/magic.py in #_method_magic_marker.<locals>.magic_deco.<locals>.<lambda>(f, *a, **k)
#    186     def magic_deco(arg):
#--> 187         call = lambda f, *a, **k: f(*a, **k)
#    189         if callable(arg):
#    190             # "Naked" decorator call (just @foo, no args)
#    191             func = arg
#
#./ipython/IPython/core/magics/config.py in ConfigMagics.config(self, s)
#    148         # otherwise, assume we are setting configurables.
#    149         # leave quotes on args when splitting, because we want
#    150         # unquoted args to eval in user_ns
#    151         cfg = Config()
#--> 152         exec("cfg."+line, locals(), self.shell.user_ns)
#    154         for configurable in configurables:
#    155             try:
#
#<string> in <module>
#
#AttributeError: 'str' object has no attribute 'IPCompleter'
#test-errorfilepath
#./ipython/IPython/core/magics/config.py

