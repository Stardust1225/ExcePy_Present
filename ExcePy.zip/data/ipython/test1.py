cfg = "TheIPythonTrap"
import holoviews as hv
hv.extension('bokeh')
