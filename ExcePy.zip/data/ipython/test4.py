%debug print()
w = 1
