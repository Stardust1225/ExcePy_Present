#!/bin/bash
cd ipython
git clean -xdf
git reset --hard b3edf6c1ddbae4e8f6ed59947afc883861165d5d
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test5.py 
#test-Traceback
#  File "test5.py", line 10, in <module>
#    manager.transform_cell("")
#  File "./ipython/IPython/core/inputtransformer2.py", line 552, in transform_cell
#    lines = transform(lines)
#  File "./ipython/IPython/core/inputtransformer2.py", line 27, in leading_indent
#    m = _indent_re.match(lines[0])
#IndexError: list index out of range
#test-errorfilepath
#./ipython/IPython/core/inputtransformer2.py
