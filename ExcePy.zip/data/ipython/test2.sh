#!/bin/bash
cd ipython
git clean -xdf
git reset --hard c64ca435c0cc7c9d89036a42870c1fac146534c1
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test2.py
#test-traceback
#  File "test2.py", line 3, in <module>
#    _elide('concatenate((a1, a2, ...), axis')
#  File "./ipython/IPython/terminal/ptutils.py", line 39, in _elide
#    return '{}.{}\N{HORIZONTAL ELLIPSIS}{}.{}'.format(parts[0], parts[1][0], parts[-2][-1], parts[-1])
#IndexError: string index out of range
#test-errorfilepath
#./ipython/IPython/terminal/ptutils.py