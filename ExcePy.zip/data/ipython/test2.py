from IPython.terminal.ptutils import _elide

_elide('concatenate((a1, a2, ...), axis')

