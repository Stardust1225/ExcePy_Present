#!/bin/bash
apt-get install -y git python3-dev python-dev
python3 -m pip install traitlets stack_data pygments pickleshare backcall prompt_toolkit nose testpath pytest nbformat matplotlib ipykernel holoviews hvplot jupyterlab simplegeneric
git clone https://github.com/ipython/ipython.git
python3 -m pip uninstall ipython

