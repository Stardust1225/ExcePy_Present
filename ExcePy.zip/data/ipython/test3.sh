#!/bin/bash
pip3 uninstall ipython
cd ipython
git clean -xdf
git reset --hard 24cb49b3c9e6190f56330b7b0967932f16e3d336
git reset --hard HEAD^
pip3 install -e .
cd ..
cd ipython
python3 -m IPython < test3.py
#test-Traceback
#  File "/usr/lib/python3.6/runpy.py", line 193, in _run_module_as_main
#    "__main__", mod_spec)
#  File "/usr/lib/python3.6/runpy.py", line 85, in _run_code
#    exec(code, run_globals)
#  File "./ipython/IPython/__main__.py", line 14, in <module>
#    start_ipython()
#  File "./ipython/IPython/__init__.py", line 126, in start_ipython
#    return launch_new_instance(argv=argv, **kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/traitlets/config/application.py", line 664, in launch_instance
#    app.start()
#  File "./ipython/IPython/terminal/ipapp.py", line 356, in start
#    self.shell.mainloop()
#  File "./ipython/IPython/terminal/interactiveshell.py", line 558, in mainloop
#    self.interact()
#  File "./ipython/IPython/terminal/interactiveshell.py", line 549, in interact
#    self.run_cell(code, store_history=True)
#  File "./ipython/IPython/core/interactiveshell.py", line 2848, in run_cell
#    raw_cell, store_history, silent, shell_futures)
#  File "./ipython/IPython/core/interactiveshell.py", line 2868, in _run_cell
#    if self.should_run_async(raw_cell):
#  File "./ipython/IPython/core/interactiveshell.py", line 2906, in should_run_async
#    return _should_be_async(cell)
#  File "./ipython/IPython/core/async_helpers.py", line 161, in _should_be_async
#    code = compile(cell, "<>", "exec")
#MemoryError
#test-errorfilepath
#./ipython/IPython/core/async_helpers.py
