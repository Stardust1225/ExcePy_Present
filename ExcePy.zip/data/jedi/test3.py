import textwrap

import jedi


def goto_definitions(src, pos=None):
  script = get_script(src, pos)
  return script.goto_definitions()


def get_script(src, pos, path=None):
  if pos is None:
    lines = src.splitlines()
    pos = len(lines), len(lines[-1])
  return jedi.Script(src, pos[0], pos[1], path)

source = textwrap.dedent(r"""
        x = 0
        a = \
          [1, 2, 3, 4, 5, 6, 7, 8, 9, x]  # <-- here
        """)
for (i, line) in enumerate(source.splitlines()):
  if '<-- here' in line:
    break
column = len(line) - len(']  # <-- here')
defs = goto_definitions(source, (i + 1, column))
