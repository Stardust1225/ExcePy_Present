from jedi import Script

code = '\n'.join([
  'def a_func():',
  '    return "bar"',
  '',
  'var1 = 12',
  '',
  'class AClass:',
  '    """my class"""',
  '    @staticmethod',
  '    def hello():',
  '        func_var = 1',
  '        return func_var',
])
script = Script(code=code)
names = script.get_names(all_scopes=True)
a_func, var1, AClass, hello, func_var = names

a_func.definition_start_position
