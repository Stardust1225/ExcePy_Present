#!/bin/bash
cd jedi
git clean -xdf
git reset --hard 855fb5a936c2b242f3a934a75c2e27a112b49ce0
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test1.py
#test-Traceback
#  File "test1.py", line 20, in <module>
#    a_func.definition_start_position
#AttributeError: 'Name' object has no attribute 'definition_start_position'
#test-errorfilepath
#test1.py
