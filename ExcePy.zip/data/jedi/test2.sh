#!/bin/bash
cd jedi
git clean -xdf
git reset --hard 9b69f3a20f324dc8ea6fdc02e32dad5c009b5670
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test2.py
#test-Traceback
#  File "test2.py", line 4, in <module>
#    raise ImportError("Originally ValueError: " + e.message)
#AttributeError: 'ValueError' object has no attribute 'message'
#test-errorfilepath
#test2.py
