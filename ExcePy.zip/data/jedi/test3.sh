#!/bin/bash
cd jedi
git clean -xdf
git reset --hard 105bb2b1ca9d76d377ed24a10bc7ff0c05a219f3
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test3.py
#test-Traceback
#  File "test3.py", line 26, in <module>
#    defs = goto_definitions(source, (i + 1, column))
#  File "test3.py", line 8, in goto_definitions
#    return script.goto_definitions()
#  File "./jedi/jedi/api_classes.py", line 44, in wrapper
#    result = func(*args, **kwds)
#  File "./jedi/jedi/api.py", line 297, in goto_definitions
#    if next(context) in ('class', 'def'):
#  File "./jedi/jedi/modules.py", line 222, in get_context
#    while pos[1] > 0 and line[pos[1] - 1].isspace():
#IndexError: string index out of range
#test-errorfilepath
#./jedi/jedi/modules.py
