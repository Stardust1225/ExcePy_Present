#!/bin/bash
apt-get install -y python3-dev python-dev git
git clone --recurse-submodules https://github.com/davidhalter/jedi
