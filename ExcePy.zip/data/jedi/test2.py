try:
  raise ValueError('{}.__loader__ is not set') from None
except ValueError as e:
  raise ImportError("Originally ValueError: " + e.message)
