import numpy as np
from sklearn.cluster import linkage_tree
from sklearn.utils.testing import assert_raise_message

X = np.array([[0, 1],
              [0, 0]])
linkage_tree(X, affinity="consine")

