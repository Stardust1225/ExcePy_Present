#!/bin/bash
python3 -m pip install scipy==0.9 numpy==1.6.1
cd scikit-learn
git clean -xdf
git reset --hard 3dc8d2f83bfb94dbb5a7190bac39e046063db4e0
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test4.py
#test-Traceback
#  File "test4.py", line 292, in <module>
#    ('classification', LinearSVC())
#  File "./scikit-learn/sklearn/pipeline.py", line 152, in __init__
#    self._validate_steps()
#  File "./scikit-learn/sklearn/pipeline.py", line 199, in _validate_steps
#    " '%s' (type %s) doesn't" % (t, type(t)))
#TypeError: All intermediate steps should be transformers and implement fit and transform. 'LinearSVC(C=1.0, class_weight=None, dual=False, fit_intercept=True, intercept_scaling=1, loss='squared_hinge', max_iter=1000, multi_class='ovr', penalty='l1', random_state=None, tol=0.001, verbose=0)' (type <class 'sklearn.svm.classes.LinearSVC'>) doesn't
#test-errorfilepath
#./scikit-learn/sklearn/pipeline.py
