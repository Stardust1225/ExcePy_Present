#!/bin/bash
python3 -m pip install scipy==1.1.0 numpy==1.14.0
cd scikit-learn
git clean -xdf
git reset --hard 52e9cc5add6ffe6398fed529f5f110f0961ad28a
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test2.py --all_categories
#test-Traceback
#Traceback (most recent call last):
#  File "test2.py", line 139, in <module>
#    print("%d categories" % len(categories))
#TypeError: object of type 'NoneType' has no len()
#test-errorfilepath
#test2.py
