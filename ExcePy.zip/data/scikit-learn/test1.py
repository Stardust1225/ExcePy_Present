from sklearn.externals.six.moves.urllib.request import urlretrieve
from sklearn.externals.six.moves import urllib
urllib.request.urlretrieve
