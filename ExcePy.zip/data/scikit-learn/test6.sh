#!/bin/bash
python3 -m pip install Cython==0.29.2
cd scikit-learn
git clean -xdf
git reset --hard 3d997697fdd166eff428ea9fd35734b6a8ba113e
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test6.py
#test-Traceback
#  File "test6.py", line 7, in <module>
#    linkage_tree(X, affinity="consine")
#  File "./scikit-learn/sklearn/cluster/hierarchical.py", line 463, in linkage_tree
#    out = hierarchy.linkage(X, method=linkage, metric=affinity)
#  File "/usr/local/lib/python3.6/dist-packages/scipy/cluster/hierarchy.py", line 708, in linkage
#    y = distance.pdist(y, metric)
#  File "/usr/local/lib/python3.6/dist-packages/scipy/spatial/distance.py", line 1963, in pdist
#    raise ValueError('Unknown Distance Metric: %s' % mstr)
#ValueError: Unknown Distance Metric: consine
#test-errorfilepath
#./scikit-learn/sklearn/cluster/hierarchical.py
