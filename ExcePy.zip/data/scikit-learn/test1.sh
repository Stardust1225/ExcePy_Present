#!/bin/bash
python3 -m pip install Cython==0.25.0
cd scikit-learn
git clean -xdf
git reset --hard cceb9b22ac1c36341779aff59de8e6130671c19a
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test1.py
#test-Traceback
#  File "test1.py", line 3, in <module>
#    urllib.request.urlretrieve
#AttributeError: module 'sklearn.externals.six.moves.urllib_request' has no attribute 'urlretrieve'
#test-errorfilepath
#test1.py
