#!/bin/bash
python3 -m pip install scipy==1.1.0 numpy==1.14.0
cd scikit-learn
git clean -xdf
git reset --hard 1557cb8a1910bce6dc33cd5cd3a08c380bdec566
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test3.py
#test-Traceback
#  File "test3.py", line 115, in <module>
#    proj_operator = build_projection_operator(l, l / 7.)
#  File "test3.py", line 83, in build_projection_operator
#    angles = np.linspace(0, np.pi, n_dir, endpoint=False)
#  File "<__array_function__ internals>", line 6, in linspace
#  File "/local/lib/python3.6/site-packages/numpy/core/function_base.py", line 113, in linspace
#    num = operator.index(num)
#TypeError: 'float' object cannot be interpreted as an integer
#test-errorfilepath
#test3.py
