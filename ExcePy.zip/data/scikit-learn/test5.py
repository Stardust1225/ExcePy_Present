from pickle import loads
from pickle import dumps

from nose.tools import assert_equal
from sklearn.datasets.base import Bunch

bunch = Bunch(x="x")
bunch_from_pkl = loads(dumps(bunch))
