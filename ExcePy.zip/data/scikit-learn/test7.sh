#!/bin/bash
python3 -m pip install Cython==0.25.2
cd scikit-learn
git clean -xdf
git reset --hard c554aad456b6302a8dd8838769769eeecc1cf734
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test7.py
#test-Traceback
#  File "test7.py", line 5, in <module>
#    le.inverse_transform([-2])
#  File "./scikit-learn/sklearn/preprocessing/label.py", line 152, in inverse_transform
#    raise ValueError("y contains new labels: %s" % str(diff))
#ValueError: y contains new labels: [-2]
#test-errorfilepath
#./scikit-learn/sklearn/preprocessing/label.py
