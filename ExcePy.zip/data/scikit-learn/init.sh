#!/bin/bash
apt-get install -y python3-dev python-dev git
git clone https://github.com/scikit-learn/scikit-learn.git
pip3 install numpy==1.17
