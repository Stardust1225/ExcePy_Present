from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()
le.fit([1, 2, 3, -1, 1])
le.inverse_transform([-2])
le.inverse_transform([-2, -3, -4])
