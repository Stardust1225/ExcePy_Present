#!/bin/bash
python3 -m pip install Cython==0.22
cd scikit-learn
git clean -xdf
git reset --hard e4b9ff6c9868c3211c1da716d76248115c11feec
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test5.py
#test-Traceback
#  File "test5.py", line 8, in <module>
#    bunch_from_pkl = loads(dumps(bunch))
#  File "./scikit-learn/sklearn/datasets/base.py", line 53, in __getattr__
#    return self[key]
#KeyError: '__setstate__'
#test-errorfilepath
#./scikit-learn/sklearn/datasets/base.py
