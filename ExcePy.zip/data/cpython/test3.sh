#!/bin/bash
cd cpython
git clean -xdf
git reset --hard 4a106ee9e1551fc12c9a767b660c6cdf7b5d9823
git reset --hard HEAD^
./configure --with-pydebug && make -j 8
cd ..
./cpython/python test3.py
#test-Traceback
#  File "test3.py", line 38, in ?
#    m.getdate('Date') 
#  File "./cpython/Lib/rfc822.py", line 367, in getdate
#    return parsedate(data)
#  File "./cpython/Lib/rfc822.py", line 937, in parsedate
#    t = parsedate_tz(data)
#  File "./cpython/Lib/rfc822.py", line 862, in parsedate_tz
#    if data[0][-1] in (',', '.') or data[0].lower() in _daynames:
#IndexError: list index out of range
#test-errorfilepath
#./cpython/Lib/rfc822.py
