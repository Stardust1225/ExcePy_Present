mesg = '''From xxx@ewasher.org Sun Nov 04 16:45:40 2001
X-Claimed-Received: from srvweb.arin.na.it
Received: from fge.com (unverified [64.86.192.76]) by srvweb.arin.na.it
 (EMWAC SMTPRS 0.83) with SMTP id <B0000032669@srvweb.arin.na.it>;
 Sun, 04 Nov 2001 06:23:13 +0100
Message-ID: <1055d6b$662a$5aea>
Mime-Version: 1.0
X-Priority: 
Content-Type: multipart/mixed;
	boundary="----=_NextPart_19187_22992_4C6B.62827801F40B"
To: "farr1@mailexcite.com" <farr1@mailexcite.com>
From: "" <xxx@ewasher.org>
Reply-to: xxx@ewasher.org
Subject: Everything that you ever wanted to know
Date: 
Status: RO
X-Status: 
X-Keywords:
X-UID: 3367


------=_NextPart_19187_22992_4C6B.62827801F40B
Content-Type: text/plain; 
	charset="us-ascii"
Content-Transfer-Encoding: 8bit

Best underground information print now !!!


------=_NextPart_19187_22992_4C6B.62827801F40B--

'''

import rfc822, StringIO

fd = StringIO.StringIO(mesg)
m = rfc822.Message(fd)
m.getdate('Date') 

