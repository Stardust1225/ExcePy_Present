import threading
import traceback

def main():
    with open(__file__, 'a') as fp:
        fp.write(' ')
        traceback.format_stack()

threads = [
    threading.Thread(target=main)
    for i in range(100)
]
[t.start() for t in threads]
[t.join() for t in threads]
main()                                                                                                                                                                                                      
                                                                                                     
                                                                                                     
