from macurl2path import *
from macurl2path import _pncomp2url

url2pathname('doesnt_matter_what')
pathname2url('some_string')
_pncomp2url('something_else')
