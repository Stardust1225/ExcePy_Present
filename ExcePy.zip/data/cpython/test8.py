import rfc822
rfc822.AddressList("<>").addresslist
[('', None)]
str(rfc822.AddressList("<>"))
