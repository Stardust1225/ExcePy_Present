#!/bin/bash
cd cpython
git clean -xdf
git reset --hard b99c132bd9030883f7a3482feb5e2b38c02f4188
git reset --hard HEAD^
./configure --with-pydebug && make -j 8
cd ..
./cpython/python test9.py
#test-Traceback
#   File "test9.py", line 3, in <module>
#     re.compile("\\")
#   File "./cpython/Lib/re.py", line 224, in compile
#     return _compile(pattern, flags)
#   File "./cpython/Lib/re.py", line 293, in _compile
#     p = sre_compile.compile(pattern, flags)
#   File "./cpython/Lib/sre_compile.py", line 540, in compile
#     p = sre_parse.parse(p, flags)
#   File "./cpython/Lib/sre_parse.py", line 779, in parse
#     source = Tokenizer(str)
#   File "./cpython/Lib/sre_parse.py", line 214, in __init__
#     self.__next()
#   File "./cpython/Lib/sre_parse.py", line 227, in __next
#     raise self.error("bogus escape (end of line)") from None
#   File "./cpython/Lib/sre_parse.py", line 266, in error
#     return error(msg, self.string, self.tell() - offset)
#   File "./cpython/Lib/sre_parse.py", line 260, in tell
#     return self.index - len(self.next or '')
# AttributeError: 'Tokenizer' object has no attribute 'next'
#test-errorfilepath
#cpython/Lib/sre_parse.py
