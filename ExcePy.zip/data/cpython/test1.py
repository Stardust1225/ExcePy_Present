import asyncore
d = asyncore.dispatcher()
d.close()
