import weakref
ref = weakref.WeakKeyDictionary()
ref.has_key('asdf')
