#!/bin/bash
cd cpython
git clean -xdf
git reset --hard a4c377cde9b010f6bee5e5e0a15e8545228d31e2
git reset --hard HEAD^
./configure --with-pydebug && make -j 8
cd ..
./cpython/python test1.py
#test-Traceback
#File "test1.py", line 3, in <module>
#    d.close()
#  File "./cpython/Lib/asyncore.py", line 401, in close
#    self.socket.close()
#AttributeError: 'NoneType' object has no attribute 'close'
#test-errorfilepath
#./cpython/Lib/asyncore.py
