#!/bin/bash
cd cpython
git clean -xdf
git reset --hard a77d7a52e88fdbb3068b99bd15eba8a0aa204529
git reset --hard HEAD^
./configure --with-pydebug && make -j 8
cd ..
./cpython/python test6.py
#test-Traceback
#  File "test6.py", line 300, in <module>
#    client.dir(lambda x: l.append(x))
#  File "./cpython/Lib/ftplib.py", line 565, in dir
#    self.retrlines(cmd, func)
#  File "./cpython/Lib/ftplib.py", line 476, in retrlines
#    if isinstance(conn, _SSLSocket):
#TypeError: isinstance() arg 2 must be a type or tuple of types
#test-errorfilepath
#./cpython/Lib/ftplib.py

