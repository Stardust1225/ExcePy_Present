#!/bin/bash
cd cpython
git clean -xdf
git reset --hard 8eba090694d661d98eb24e6894b0c3e2c5c76ba2
git reset --hard HEAD^
./configure --with-pydebug && make -j 8
cd ..
./cpython/python test2.py
#test-Traceback
#  File "test2.py", line 2, in <module>
#    url2pathname('doesnt_matter_what')
#  File "./cpython/Lib/macurl2path.py", line 16, in url2pathname
#    tp = urllib.parsesplittype(pathname)[0]
#AttributeError: 'module' object has no attribute 'parsesplittype'
#test-errorfilepath
#./cpython/Lib/macurl2path.py
