from atexit import register

def x1():
    print "running x1"
    raise SystemExit

register(x1)
