#!/bin/bash
cd cpython
git clean -xdf
git reset --hard d72ea605218bbee6ae46648997d9bb76d0fba460
git reset --hard HEAD^
./configure --with-pydebug && make -j 8
cd ..
./cpython/python test4.py
#test-Traceback
#  File "./cpython/Lib/threading.py", line 950, in _bootstrap_inner
#    self.run()
#  File "./cpython/Lib/threading.py", line 888, in run
#    self._target(*self._args, **self._kwargs)
#  File "./test4.py", line 7, in main
#    traceback.format_stack()
#  File "./cpython/Lib/traceback.py", line 197, in format_stack
#    return format_list(extract_stack(f, limit=limit))
#  File "./cpython/Lib/traceback.py", line 211, in extract_stack
#    stack = StackSummary.extract(walk_stack(f), limit=limit)
#  File "./cpython/Lib/traceback.py", line 362, in extract
#    linecache.checkcache(filename)
#  File "./cpython/Lib/linecache.py", line 77, in checkcache
#    del cache[filename]
#KeyError: '/home/xin/Documents/test4.py'
#test-errorfilepath
#./cpython/Lib/linecache.py
