#!/bin/bash
cd cpython
git clean -xdf
git reset --hard f70ce68c9cce352a34cd30ecf5168d93bc379817
git reset --hard HEAD^
./configure --with-pydebug && make -j 8
cd ..
./cpython/python test11.py
#test-Traceback
#  File "test11.py", line 4, in <module>
#    url2pathname('doesnt_matter_what')
#  File "./cpython/Lib/macurl2path.py", line 16, in url2pathname
#    tp = urllib.parsesplittype(pathname)[0]
#AttributeError: 'module' object has no attribute 'parsesplittype'
#test-errorfilepath
#./cpython/Lib/macurl2path.py
