from random import Random

Random(14064741636871487939).paretovariate(0.01)
