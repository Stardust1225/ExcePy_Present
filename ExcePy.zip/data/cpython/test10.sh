#!/bin/bash
cd cpython
git clean -xdf
git reset --hard 4762382d6346abdef810cdf0a6101cbc1ec5952e
git reset --hard HEAD^
./configure --with-pydebug && make -j 8
cd ..
./cpython/python test10.py
#test-Traceback
#  File "test10.py", line 3, in <module>
#    Random(14064741636871487939).paretovariate(0.01)
#  File "./cpython/Lib/random.py", line 622, in paretovariate
#    return 1.0 / u ** (1.0/alpha)
#ZeroDivisionError: float division by zero
#test-errorfilepath
#./cpython/Lib/random.py
