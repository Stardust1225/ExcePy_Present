#!/bin/bash
cd cpython
git clean -xdf
git reset --hard 3bae7ddf8e63889b185235f85a6695bc05d59059
git reset --hard HEAD^
./configure --with-pydebug --disable-ipv6 && make -j 8
cd ..
./cpython/python test7.py
#test-Traceback
#  File "test7.py", line 3, in ?
#    ref.has_key('asdf')
#  File "./cpython/Lib/weakref.py", line 182, in has_key
#    return self.data.has_key(ref(key))
#TypeError: cannot create weak reference to 'str' object
#test-errorfilepath
#./cpython/Lib/weakref.py

