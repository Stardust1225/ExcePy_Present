from macurl2path import *
url2pathname('doesnt_matter_what')
pathname2url('some_string')
_pncomp2url('something_else')
