import re

re.compile("\\")
re.match(r"\(", '(').group()
re.match(r"\(", ')')
re.match(r"\\", '\\').group()
