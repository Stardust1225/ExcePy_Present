#!/bin/bash
cd cpython
git clean -xdf
git reset --hard a9ef5e565d3e33e3a6f410d9c610ffe5bdc6c474
git reset --hard HEAD^
./configure --with-pydebug && make -j 8
cd ..
./cpython/python test5.py
#test-Traceback
#  File "./cpython/Lib/atexit.py", line 24, in _run_exitfuncs
#    exc_info = sys.exc_info()
#UnboundLocalError: local variable 'sys' referenced before assignment
#test-errorfilepath
#./cpython/Lib/atexit.py

