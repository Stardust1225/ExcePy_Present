#!/bin/bash
cd cpython
git clean -xdf
git reset --hard f830a529961b54d136aac71e1e499e6735627d99
git reset --hard HEAD^
./configure --with-pydebug && make -j 8
cd ..
./cpython/python test8.py
#test-Traceback
#  File "test8.py", line 4, in ?
#    str(rfc822.AddressList("<>"))
#  File "./cpython/Lib/rfc822.py", line 793, in __str__
#    return ", ".join(map(dump_address_pair, self.addresslist))
#TypeError: sequence item 0: expected string, NoneType found
#test-errorfilepath
#./cpython/Lib/rfc822.py

