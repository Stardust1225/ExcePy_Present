#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 1a84db6a20ee606c0e6388267151f8d73145fa1c
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test19.py
#test-Traceback
#  File "test19.py", line 4, in <module>
#    solveset(29 * 2 ** (x + 1) * 615 ** (x / 3) - 123 * 2726 ** (x / 3), x)
#  File "./sympy/sympy/solvers/solveset.py", line 2118, in solveset
#    rv = solveset(f.xreplace({symbol: x}), x, domain)
#  File "./sympy/sympy/solvers/solveset.py", line 2142, in solveset
#    return _solveset(f, symbol, domain, _check=True)
#  File "./sympy/sympy/solvers/solveset.py", line 1093, in _solveset
#    result += _transolve(equation, symbol, domain)
#  File "./sympy/sympy/solvers/solveset.py", line 1965, in _transolve
#    result = add_type(lhs, rhs, symbol, domain)
#  File "./sympy/sympy/solvers/solveset.py", line 1947, in add_type
#    result = _solve_exponential(lhs, rhs, symbol, domain)
#  File "./sympy/sympy/solvers/solveset.py", line 1540, in _solve_exponential
#    b_base, b_exp = b_term.base, b_term.exp
#AttributeError: 'Mul' object has no attribute 'base'
#test-errorfilepath
#./sympy/sympy/solvers/solveset.py
