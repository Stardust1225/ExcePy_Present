#!/bin/bash
cd sympy
git clean -xdf
git reset --hard a16fbd43592a930df60517811f928c208bc7afdc
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test43.py
#test-Traceback
#  File "test43.py", line 5, in <module>
#    manualintegrate(1 / ((x ** 2 + 4) * sqrt(4 * x ** 2 + 1)), x)
#  File "./sympy/sympy/integrals/manualintegrate.py", line 1231, in manualintegrate
#    return _manualintegrate(integral_steps(f, var))
#  File "./sympy/sympy/integrals/manualintegrate.py", line 1019, in integral_steps
#    fallback_rule)(integral)
#  File "./sympy/sympy/strategies/core.py", line 85, in do_one_rl
#    result = rl(expr)
#  File "./sympy/sympy/strategies/core.py", line 85, in do_one_rl
#    result = rl(expr)
#  File "./sympy/sympy/strategies/core.py", line 65, in null_safe_rl
#    result = rule(expr)
#  File "./sympy/sympy/integrals/manualintegrate.py", line 743, in trig_substitution_rule
#    a = match[a]
#TypeError: 'NoneType' object is not subscriptable
#test-errorfilepath
#./sympy/sympy/integrals/manualintegrate.py
