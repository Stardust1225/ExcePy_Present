from sympy import integrate, sign, cos
from sympy.abc import x

integrate((sign(x - 1) - sign(x - 2)) * cos(x), x)
