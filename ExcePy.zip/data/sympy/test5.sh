#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 8df27d84053da133f93f382afd07fdfbdbe5d7c7
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test5.py
#test-Traceback
#  File "test5.py", line 5, in <module>
#    intersection(c1, c2)
#  File "./sympy/sympy/geometry/util.py", line 679, in intersection
#    res = entities[0].intersection(entities[1])
#  File "./sympy/sympy/geometry/ellipse.py", line 1680, in intersection
#    return Ellipse.intersection(self, o)
#  File "./sympy/sympy/geometry/ellipse.py", line 687, in intersection
#    return list(ordered([Point(i) for i in solve([ellipse_equation, o.equation(x, y)], [x, y])]))
#  File "./sympy/sympy/solvers/solvers.py", line 1191, in solve
#    solution = _solve_system(f, symbols, **flags)
#  File "./sympy/sympy/solvers/solvers.py", line 1876, in _solve_system
#    result = solve_poly_system(polys, *symbols)
#  File "./sympy/sympy/solvers/polysys.py", line 34, in solve_poly_system
#    polys, opt = parallel_poly_from_expr(seq, *gens, **args)
#  File "./sympy/sympy/polys/polytools.py", line 4299, in parallel_poly_from_expr
#    return _parallel_poly_from_expr(exprs, opt)
#  File "./sympy/sympy/polys/polytools.py", line 4313, in _parallel_poly_from_expr
#    f, g = f.unify(g)
#  File "./sympy/sympy/polys/polytools.py", line 372, in unify
#    _, per, F, G = f._unify(g)
#  File "./sympy/sympy/polys/polytools.py", line 387, in _unify
#    dom, lev = f.rep.dom.unify(g.rep.dom, gens), len(gens) - 1
#  File "./sympy/sympy/polys/domains/domain.py", line 266, in unify
#    return K0.unify_with_symbols(K1, symbols)
#  File "./sympy/sympy/polys/domains/domain.py", line 246, in unify_with_symbols
#    return K0.unify(K1)
#  File "./sympy/sympy/polys/domains/domain.py", line 322, in unify
#    return K0.__class__(K0.dom.unify(K1.dom), *_unify_gens(K0.orig_ext, K1.orig_ext))
#  File "./sympy/sympy/polys/domains/algebraicfield.py", line 31, in __init__
#    self.ext = to_number_field(ext)
#  File "./sympy/sympy/polys/numberfields.py", line 1068, in to_number_field
#    minpoly, coeffs = primitive_element(extension, gen, polys=True)
#  File "./sympy/sympy/polys/numberfields.py", line 854, in primitive_element
#    g = minimal_polynomial(gen, x, polys=True)
#  File "./sympy/sympy/polys/numberfields.py", line 672, in minimal_polynomial
#    result = _minpoly_compose(ex, x, domain)
#  File "./sympy/sympy/polys/numberfields.py", line 540, in _minpoly_compose
#    if dom.is_QQ and _is_sum_surds(ex):
#  File "./sympy/sympy/simplify/simplify.py", line 211, in _is_sum_surds
#    if not ((y**2).is_Rational and y.is_extended_real):
#TypeError: unsupported operand type(s) for ** or pow(): 'Tuple' and 'int'
#test-errorfilepath
#./sympy/sympy/simplify/simplify.py
