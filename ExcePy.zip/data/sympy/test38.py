from sympy import solve, erf
from sympy.abc import x, S, pi, I

solve(-erf(x ** (S(1) / 3)) ** pi + I, x) == []
