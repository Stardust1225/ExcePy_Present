#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 5ad7031f1b3688780b4b44ec433cf0a396f50275
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test12.py
#test-Traceback
#  File "test12.py", line 3, in <module>
#    int(QQ(2 ** 2000, 3 ** 1250))
#  File "./sympy/sympy/polys/domains/pythonrational.py", line 83, in __int__
#    return int(float(self.p)/self.q)
#OverflowError: int too large to convert to float
#test-errorfilepath
#./sympy/sympy/polys/domains/pythonrational.py
