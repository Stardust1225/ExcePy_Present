#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 8de8cadb99725f7b5efc77879217da7c21fe9229
git reset --hard HEAD^
pip3 install -e .
cd ..
python test23.py
#test-Traceback
#  File "test23.py", line 1, in <module>
#    from sympy import CRootOf, cse
#  File "./sympy/sympy/__init__.py", line 21, in <module>
#    raise ImportError("SymPy now depends on mpmath as an external library. "
#ImportError: SymPy now depends on mpmath as an external library. See https://docs.sympy.org/latest/install.html#mpmath for more information.
#test-errorfilepath
#./sympy/sympy/__init__.py
