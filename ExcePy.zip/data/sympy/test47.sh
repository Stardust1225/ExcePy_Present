#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 003fe5bee6c3513af717fd2784be39d7019117f9
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test47.py
#test-Traceback
#  File "test47.py", line 7, in <module>
#    f.gcd(d)
#  File "./sympy/sympy/core/exprtools.py", line 536, in gcd
#    exp = min(exp, other.factors[factor])
#  File "./sympy/sympy/core/relational.py", line 226, in __nonzero__
#    raise TypeError("symbolic boolean expression has no truth value.")
#TypeError: symbolic boolean expression has no truth value.
#test-errorfilepath
#./sympy/sympy/core/relational.py
