from sympy import ImageSet, Lambda, sqrt, pi, Integers
from sympy.abc import n

ImageSet(Lambda(n, sqrt(pi * n / 2 - 1 + pi / 2)), Integers).contains(0)
