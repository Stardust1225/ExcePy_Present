from sympy import Matrix, Trace

X = Matrix([[1, 2], [3, 4]])
Trace(X) + Trace(X)
