from sympy import sqrt
from sympy.abc import x, a, y, b
from sympy.integrals.manualintegrate import manualintegrate

manualintegrate(1 / ((x ** 2 + 4) * sqrt(4 * x ** 2 + 1)), x)
