from sympy import integrate, sign, cos, symbols

x = symbols("x")
integrate((sign(x - 1) - sign(x - 2)) * cos(x), x)
