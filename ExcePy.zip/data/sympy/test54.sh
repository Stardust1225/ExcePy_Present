#!/bin/bash
cd sympy
git clean -xdf
git reset --hard f7390e5fa2313be1c49959270358b2b0c62a1a57
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test54.py
#test-Traceback
#  File "test54.py", line 4, in <module>
#    integrate(exp(x) / (1 + x) ** 2, x)
#  File "./sympy/sympy/integrals/integrals.py", line 1522, in integrate
#    return integral.doit(**doit_flags)
#  File "./sympy/sympy/integrals/integrals.py", line 576, in doit
#    function, xab[0], **eval_kwargs)
#  File "./sympy/sympy/integrals/integrals.py", line 919, in _eval_integral
#    return NonElementaryIntegral(f, x).doit(risch=False)
#  File "./sympy/sympy/integrals/integrals.py", line 576, in doit
#    function, xab[0], **eval_kwargs)
#  File "./sympy/sympy/integrals/integrals.py", line 1046, in _eval_integral
#    h = meijerint_indefinite(g, x)
#  File "./sympy/sympy/integrals/meijerint.py", line 1621, in meijerint_indefinite
#    res = _meijerint_indefinite_1(f.subs(x, x + a), x)
#  File "./sympy/sympy/integrals/meijerint.py", line 1646, in _meijerint_indefinite_1
#    gs = _rewrite1(f, x)
#  File "./sympy/sympy/integrals/meijerint.py", line 1569, in _rewrite1
#    g = _rewrite_single(g, x, recursive)
#  File "./sympy/sympy/core/cache.py", line 94, in wrapper
#    retval = cfunc(*args, **kwargs)
#  File "./sympy/sympy/integrals/meijerint.py", line 1538, in _rewrite_single
#    g = my_imt(F, s, x, strip).subs(a, 1)
#  File "./sympy/sympy/integrals/meijerint.py", line 1508, in my_imt
#    as_meijerg=True, needeval=True)
#  File "./sympy/sympy/integrals/transforms.py", line 874, in inverse_mellin_transform
#    return InverseMellinTransform(F, s, x, strip[0], strip[1]).doit(**hints)
#  File "./sympy/sympy/integrals/transforms.py", line 134, in doit
#    for x in fn.args]
#  File "./sympy/sympy/integrals/transforms.py", line 134, in <listcomp>
#    for x in fn.args]
#  File "./sympy/sympy/integrals/transforms.py", line 123, in doit
#    self.function_variable, self.transform_variable, **hints)
#  File "./sympy/sympy/integrals/transforms.py", line 818, in _compute_transform
#    return _inverse_mellin_transform(F, s, x, strip, **hints)
#  File "./sympy/sympy/integrals/transforms.py", line 208, in wrapper
#    res = func(*args, **kwargs)
#  File "./sympy/sympy/integrals/transforms.py", line 740, in _inverse_mellin_transform
#    G = meijerg(a, b, C/x**e)
#  File "./sympy/sympy/functions/special/hyper.py", line 478, in __new__
#    raise ValueError("no parameter a1, ..., an may differ from "
#ValueError: no parameter a1, ..., an may differ from any b1, ..., bm by a positive integer
#test-errorfilepath
#./sympy/sympy/functions/special/hyper.py
