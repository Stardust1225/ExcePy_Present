from sympy import capture, pprint, symbols

x, y = symbols("x y")
capture(pprint(x / y))
