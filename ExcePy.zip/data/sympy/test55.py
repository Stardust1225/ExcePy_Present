from sympy import oo

oo > oo
