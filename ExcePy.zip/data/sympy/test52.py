from sympy import Sum, Product, oo
from sympy.abc import m, n

Sum(Product((3 * m - 3), (m, 2, n)) / Product((3 * m + 1), (m, 2, n)), (n, 2, oo)).is_convergent()
