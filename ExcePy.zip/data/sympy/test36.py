from sympy import exp, log
from sympy.abc import x

exp(x * log(x)).series(n=3)
