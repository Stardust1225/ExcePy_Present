from sympy import Symbol, oo, polar_lift

b = Symbol('b', positive=True)
oo ** polar_lift(-b + 1)
