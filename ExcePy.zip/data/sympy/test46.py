from sympy import symbols, exp

x = symbols('x')
exp(x).taylor_term(1, x)