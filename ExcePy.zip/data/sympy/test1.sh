#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 0fc1bf2ea426e63e9caf163a852357eecb7c897f
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test1.py
#test-Traceback
#  File "test1.py", line 5, in <module>
#    H(B)
#  File "./sympy/sympy/stats/rv_interface.py", line 137, in entropy
#    return sum([-prob*log(prob, base) for prob in pdf.dict.values()])
#AttributeError: 'Density' object has no attribute 'values'
#test-errorfilepath
#./sympy/sympy/stats/rv_interface.py

