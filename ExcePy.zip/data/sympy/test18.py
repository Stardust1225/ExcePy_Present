from sympy import limit, cos, oo
from sympy.interactive import x

limit(cos(x)/x, x, oo)
