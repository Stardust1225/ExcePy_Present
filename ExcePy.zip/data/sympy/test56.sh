#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 647a123703e0f5de659087bef860adc3cdf4f9b6
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test56.py
#test-Traceback
#  File "test56.py", line 4, in <module>
#    linear_coeffs(1.0, x, y)
#  File "./sympy/sympy/solvers/solveset.py", line 2218, in linear_coeffs
#    raise ValueError('nonlinear term encountered: %s' % t)
#ValueError: nonlinear term encountered: 1.00000000000000
#test-errorfilepath
#./sympy/sympy/solvers/solveset.py
