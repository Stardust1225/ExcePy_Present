#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 2ad6b40353bf11270ccb21d07162ecbb064f898a
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test20.py
#test-Traceback
#  File "test20.py", line 4, in <module>
#    nonlinsolve([Eq(x, 5 ** (S(1) / 5)), Eq(x * y, 25 * sqrt(5))], x, y)
#TypeError: 'Symbol' object is not callable
#test-errorfilepath
#test20.py
