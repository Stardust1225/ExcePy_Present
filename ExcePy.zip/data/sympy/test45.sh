#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 750f53fd41fea65b2884627a5199981c8f714f58
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test45.py
#test-Traceback
#  File "test45.py", line 4, in <module>
#    Trace(X) + Trace(X)
#  File "./sympy/sympy/core/decorators.py", line 77, in __sympifyit_wrapper
#    return func(a, b)
#  File "./sympy/sympy/core/decorators.py", line 118, in binary_op_wrapper
#    return func(self, other)
#  File "./sympy/sympy/core/expr.py", line 121, in __add__
#    return Add(self, other)
#  File "./sympy/sympy/core/cache.py", line 93, in wrapper
#    retval = func(*args, **kwargs)
#  File "./sympy/sympy/core/operations.py", line 41, in __new__
#    c_part, nc_part, order_symbols = cls.flatten(args)
#  File "./sympy/sympy/core/add.py", line 178, in flatten
#    if s in terms:
#  File "./sympy/sympy/core/basic.py", line 107, in __hash__
#    h = hash((type(self).__name__,) + self._hashable_content())
#TypeError: unhashable type: 'MutableDenseMatrix'
#test-errorfilepath
#./sympy/sympy/core/basic.py
