#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 70259570b20a5424409d41f868c36c043f45e2ab
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test39.py
#test-Traceback
#  File "test39.py", line 4, in <module>
#    Add(Matrix([[3]]), x).subs(x, 2.0)
#  File "./sympy/sympy/core/cache.py", line 96, in wrapper
#    retval = func(*args, **kwargs)
#  File "./sympy/sympy/core/operations.py", line 48, in __new__
#    obj = cls._exec_constructor_postprocessors(obj)
#  File "./sympy/sympy/core/basic.py", line 1791, in _exec_constructor_postprocessors
#    obj = f(obj)
#  File "./sympy/sympy/matrices/expressions/matexpr.py", line 572, in _postprocessor
#    matrices[i] = matrices[i].__add__(cls._from_args(nonmatrices))
#  File "./sympy/sympy/core/decorators.py", line 132, in binary_op_wrapper
#    return func(self, other)
#  File "./sympy/sympy/matrices/common.py", line 1981, in __add__
#    raise TypeError('cannot add %s and %s' % (type(self), type(other)))
#TypeError: cannot add <class 'sympy.matrices.immutable.ImmutableDenseMatrix'> and <class 'sympy.core.symbol.Symbol'>
#test-errorfilepath
#./sympy/sympy/matrices/common.py
