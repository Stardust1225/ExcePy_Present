from sympy import limit, exp, oo, symbols

x, y = symbols('x, y')

limit(exp(x) / (x * exp(x * y) + exp(x * y)), x, oo)
