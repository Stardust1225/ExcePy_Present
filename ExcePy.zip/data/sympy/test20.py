from sympy import nonlinsolve, Eq, sqrt
from sympy.abc import x, S, y

nonlinsolve([Eq(x, 5 ** (S(1) / 5)), Eq(x * y, 25 * sqrt(5))], x, y)
