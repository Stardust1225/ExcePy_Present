#!/bin/bash
cd sympy
git clean -xdf
git reset --hard d5c27a419a2f1300bdc679eaa22aa328820a6fac
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test52.py
#test-Traceback
#RecursionError: maximum recursion depth exceeded while calling a Python object
#test-errorfilepath
#test52.py
