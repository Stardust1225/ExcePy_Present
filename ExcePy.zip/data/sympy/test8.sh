#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 2b190bac7407bde8a91fa5ed2da107f4f9333364
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test8.py
#test-Traceback
#  File "test8.py", line 5, in <module>
#    limit(exp(x) / (x * exp(x * y) + exp(x * y)), x, oo)
#  File "./sympy/sympy/series/limits.py", line 85, in limit
#    r = gruntz(e, z, z0, dir)
#  File "./sympy/sympy/series/gruntz.py", line 632, in gruntz
#    r = limitinf(e, z)
#  File "./sympy/sympy/core/cache.py", line 93, in wrapper
#    r = func(*args, **kw_args)
#  File "./sympy/sympy/series/gruntz.py", line 416, in limitinf
#    c0, e0 = mrv_leadterm(e, x)
#  File "./sympy/sympy/core/cache.py", line 93, in wrapper
#    r = func(*args, **kw_args)
#  File "./sympy/sympy/series/gruntz.py", line 501, in mrv_leadterm
#    series = calculate_series(f, w, logx=logw)
#  File "./sympy/sympy/series/gruntz.py", line 455, in calculate_series
#    series = e.nseries(x, n=n, logx=logx)
#  File "./sympy/sympy/core/expr.py", line 2596, in nseries
#    return self._eval_nseries(x, n=n, logx=logx)
#  File "./sympy/sympy/core/mul.py", line 1442, in _eval_nseries
#    terms = [t.nseries(x, n=n, logx=logx) for t in self.args]
#  File "./sympy/sympy/core/mul.py", line 1442, in <listcomp>
#    terms = [t.nseries(x, n=n, logx=logx) for t in self.args]
#  File "./sympy/sympy/core/expr.py", line 2596, in nseries
#    return self._eval_nseries(x, n=n, logx=logx)
#  File "./sympy/sympy/core/power.py", line 839, in _eval_nseries
#    b = b_orig._eval_nseries(x, n=nuse, logx=logx)
#  File "./sympy/sympy/core/add.py", line 354, in _eval_nseries
#    terms = [t.nseries(x, n=n, logx=logx) for t in self.args]
#  File "./sympy/sympy/core/add.py", line 354, in <listcomp>
#    terms = [t.nseries(x, n=n, logx=logx) for t in self.args]
#  File "./sympy/sympy/core/expr.py", line 2596, in nseries
#    return self._eval_nseries(x, n=n, logx=logx)
#  File "./sympy/sympy/core/mul.py", line 1442, in _eval_nseries
#    terms = [t.nseries(x, n=n, logx=logx) for t in self.args]
#  File "./sympy/sympy/core/mul.py", line 1442, in <listcomp>
#    terms = [t.nseries(x, n=n, logx=logx) for t in self.args]
#  File "./sympy/sympy/core/expr.py", line 2596, in nseries
#    return self._eval_nseries(x, n=n, logx=logx)
#  File "./sympy/sympy/core/power.py", line 903, in _eval_nseries
#    return exp(e*log(b))._eval_nseries(x, n=n, logx=logx)
#  File "./sympy/sympy/functions/elementary/exponential.py", line 419, in _eval_nseries
#    exp_series = exp(t)._taylor(t, n)
#  File "./sympy/sympy/functions/elementary/exponential.py", line 430, in _taylor
#    for i in xrange(n):
#TypeError: 'Add' object cannot be interpreted as an integer
#test-errorfilepath
#./sympy/sympy/functions/elementary/exponential.py
