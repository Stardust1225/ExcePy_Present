#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 41f2eb357ba3ea087b894872ac737c3133395861
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test59.py
#test-Traceback
#  File "test59.py", line 4, in <module>
#    Derivative(x, y).xreplace({x: 2 * z, y: 2 * z})
#  File "./sympy/sympy/core/basic.py", line 1172, in xreplace
#    return self.func(*args)
#  File "./sympy/sympy/core/function.py", line 1030, in __new__
#    Can\'t differentiate wrt the variable: %s, %s''' % (v, count)))
#ValueError: Can't differentiate wrt the variable: 2*z, 1
#test-errorfilepath
#./sympy/sympy/core/function.py
