from sympy.abc import x, y
from sympy.solvers.solveset import linear_coeffs

linear_coeffs(1.0, x, y)
