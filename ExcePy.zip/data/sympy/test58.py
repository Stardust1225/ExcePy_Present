from sympy.combinatorics import Cycle

Cycle(3).list(2)
