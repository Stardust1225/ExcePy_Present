from sympy import *
r = Symbol('r', real=True, positive=True)
a = Symbol('a', real=True, positive=True)
Integral(1/r**2,(r,oo,a)).doit()
