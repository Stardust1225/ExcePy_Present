from sympy import asec

asec(0).is_real
