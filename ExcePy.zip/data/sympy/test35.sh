#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 574b20db166d788912d9148f4e73479f40408368
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test35.py
#test-Traceback
#  File "test35.py", line 4, in <module>
#    ImageSet(Lambda(n, sqrt(pi * n / 2 - 1 + pi / 2)), Integers).contains(0)
#  File "./sympy/sympy/sets/sets.py", line 325, in contains
#    c = self._contains(other)
#  File "./sympy/sympy/sets/fancysets.py", line 477, in _contains
#    solnset = _solveset_multi(equations, variables, base_sets)
#  File "./sympy/sympy/solvers/solveset.py", line 2070, in _solveset_multi
#    solsets = [solveset(eq, sym, domain) for eq in eqs]
#  File "./sympy/sympy/solvers/solveset.py", line 2070, in <listcomp>
#    solsets = [solveset(eq, sym, domain) for eq in eqs]
#  File "./sympy/sympy/solvers/solveset.py", line 2021, in solveset
#    return solveset(f.xreplace({symbol: r}), r, domain
#  File "./sympy/sympy/solvers/solveset.py", line 2039, in solveset
#    return _solveset(f, symbol, domain, _check=True)
#  File "./sympy/sympy/solvers/solveset.py", line 948, in _solveset
#    result = solver(Add(f.lhs, - f.rhs, evaluate=False), symbol, domain)
#  File "./sympy/sympy/solvers/solveset.py", line 915, in <lambda>
#    solver = lambda f, x, domain=domain: _solveset(f, x, domain)
#  File "./sympy/sympy/solvers/solveset.py", line 965, in _solveset
#    lhs, rhs_s = inverter(f, 0, symbol)
#  File "./sympy/sympy/solvers/solveset.py", line 916, in <lambda>
#    inverter = lambda f, rhs, symbol: _invert(f, rhs, symbol, domain)
#  File "./sympy/sympy/solvers/solveset.py", line 168, in _invert
#    x1, s = _invert_real(f_x, FiniteSet(y), x)
#  File "./sympy/sympy/solvers/solveset.py", line 243, in _invert_real
#    return (_inv, _set.intersect(base_positive))
#  File "./sympy/sympy/sets/sets.py", line 131, in intersect
#    return Intersection(self, other)
#  File "./sympy/sympy/sets/sets.py", line 1351, in __new__
#    return simplify_intersection(args)
#  File "./sympy/sympy/sets/sets.py", line 2411, in simplify_intersection
#    rv = Intersection._handle_finite_sets(args)
#  File "./sympy/sympy/sets/sets.py", line 1519, in _handle_finite_sets
#    return Intersection(*sets, evaluate=False)
#  File "./sympy/sympy/sets/sets.py", line 1353, in __new__
#    args = list(ordered(args, Set._infimum_key))
#  File "./sympy/sympy/core/compatibility.py", line 663, in ordered
#    for k in sorted(d.keys()):
#  File "./sympy/sympy/core/relational.py", line 384, in __nonzero__
#    raise TypeError("cannot determine truth value of Relational")
#TypeError: cannot determine truth value of Relational
#test-errorfilepath
#./sympy/sympy/core/relational.py
