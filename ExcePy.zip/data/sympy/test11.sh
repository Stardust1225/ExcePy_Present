#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 6ce0a049e000478714e4dc75dc778e2ce49de547
git reset --hard HEAD^
pip install -e .
cd ..
python test11.py
#test-Traceback
#  File "test11.py", line 4, in <module>
#    oo ** polar_lift(-b + 1)
#  File "./sympy/sympy/core/decorators.py", line 65, in __sympifyit_wrapper
#    return func(a, sympify(b, strict=True))
#  File "./sympy/sympy/core/decorators.py", line 105, in binary_op_wrapper
#    return func(self, other)
#  File "./sympy/sympy/core/expr.py", line 129, in __pow__
#    return Pow(self, other)
#  File "./sympy/sympy/core/cache.py", line 91, in wrapper
#    func_cache_it_cache[k] = r = func(*args, **kw_args)
#  File "./sympy/sympy/core/power.py", line 85, in __new__
#    obj = b._eval_power(e)
#  File "./sympy/sympy/core/numbers.py", line 1976, in _eval_power
#    n = exp.evalf()
#  File "./sympy/sympy/core/evalf.py", line 1057, in evalf
#    result = evalf(self, prec+4, options)
#  File "./sympy/sympy/core/evalf.py", line 988, in evalf
#    re = re._to_mpmath(prec, allow_ints=False)._mpf_
#  File "./sympy/sympy/core/evalf.py", line 1124, in _to_mpmath
#    raise ValueError(errmsg)
#ValueError: cannot convert to mpmath number
#test-errorfilepath
#./sympy/sympy/core/evalf.py

