#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 5012bc49ea5b00759501d43ae49d2540f8c6811b
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test50.py
#test-Traceback
#  File "test50.py", line 6, in <module>
#    expr.diff(A)
#  File "./sympy/sympy/core/expr.py", line 3028, in diff
#    return Derivative(self, *new_symbols, **assumptions)
#  File "./sympy/sympy/core/function.py", line 1260, in __new__
#    obj = expr._eval_derivative_n_times(v, count)
#  File "./sympy/sympy/core/basic.py", line 1620, in _eval_derivative_n_times
#    obj2 = obj._accept_eval_derivative(s)
#  File "./sympy/sympy/core/basic.py", line 1596, in _accept_eval_derivative
#    return s._visit_eval_derivative_scalar(self)
#  File "./sympy/sympy/core/basic.py", line 1601, in _visit_eval_derivative_scalar
#    return base._eval_derivative(self)
#  File "./sympy/sympy/matrices/expressions/matexpr.py", line 218, in _eval_derivative
#    M = M.replace(lambda x: isinstance(x, Trace), getsum)
#  File "./sympy/sympy/core/basic.py", line 1422, in replace
#    rv = bottom_up(self, rec_replace, atoms=True)
#  File "./sympy/sympy/simplify/simplify.py", line 1087, in bottom_up
#    for a in rv.args])
#  File "./sympy/sympy/simplify/simplify.py", line 1087, in <listcomp>
#    for a in rv.args])
#  File "./sympy/sympy/simplify/simplify.py", line 1090, in bottom_up
#    rv = F(rv)
#  File "./sympy/sympy/core/basic.py", line 1407, in rec_replace
#    new = _value(expr, result)
#  File "./sympy/sympy/core/basic.py", line 1391, in <lambda>
#    _value = lambda expr, result: value(expr)
#  File "./sympy/sympy/matrices/expressions/matexpr.py", line 217, in getsum
#    return Sum(x.args[0], (di, 0, x.args[0].shape[0]-1))
#NameError: name 'Sum' is not defined
#test-errorfilepath
#./sympy/sympy/matrices/expressions/matexpr.py
