#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 8a7e06b37ffa6a774183a65ef0df0ca4143a3fa1
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test57.py
#test-Traceback
#  File "test57.py", line 4, in <module>
#    powsimp(-0.1 ** x)
#  File "./sympy/sympy/simplify/powsimp.py", line 169, in powsimp
#    m = multiplicity(abs(b), abs(coeff))
#  File "./sympy/sympy/ntheory/factor_.py", line 232, in multiplicity
#    raise ValueError('expecting ints or fractions, got %s and %s' % (p, n))
#ValueError: expecting ints or fractions, got 0.100000000000000 and 1
#test-errorfilepath
#./sympy/sympy/ntheory/factor_.pyf
