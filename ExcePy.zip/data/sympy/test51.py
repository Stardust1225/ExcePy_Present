from sympy import *
from sympy.simplify.trigsimp import *
from sympy.abc import x

trigsimp_groebner(csc(x) * sin(x))
