#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 22aedc8c7fd2beee513b869b4a6d71641797e289
git reset --hard HEAD^
python -m pip install -e .
cd ..
python test60.py
#test-Traceback
#  File "test60.py", line 3, in <module>
#    nP(0, replacement=True)
#  File "./sympy/sympy/functions/combinatorial/numbers.py", line 751, in nP
#    return Integer(_nP(_multiset_histogram(n), k, replacement))
#  File "./sympy/sympy/functions/combinatorial/numbers.py", line 706, in _multiset_histogram
#    n = list(n)
#TypeError: 'int' object is not iterable
#test-errorfilepath
#./sympy/sympy/functions/combinatorial/numbers.py
