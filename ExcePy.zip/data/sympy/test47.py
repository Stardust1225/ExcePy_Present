from sympy import symbols
from sympy.core.exprtools import Factors

x, y = symbols("x y")
n, d = x ** (2 + y), x ** 2
f = Factors(n)
f.gcd(d)
