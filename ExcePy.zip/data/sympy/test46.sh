#!/bin/bash
cd sympy
git clean -xdf
git reset --hard e243d0586e669dc9d18db0a705f2bb7883f14634
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test46.py
#test-Traceback
#  File "test46.py", line 4, in <module>
#    exp(x).taylor_term(1, x)
#  File "./sympy/sympy/core/cache.py", line 93, in wrapper
#    retval = func(*args, **kwargs)
#  File "./sympy/sympy/functions/elementary/exponential.py", line 304, in taylor_term
#    return x**n/factorial()(n)
#  File "./sympy/sympy/core/cache.py", line 93, in wrapper
#    retval = func(*args, **kwargs)
#  File "./sympy/sympy/core/function.py", line 373, in __new__
#    'given': n})
#TypeError: factorial takes exactly 1 argument (0 given)
#test-errorfilepath
#./sympy/sympy/core/function.py
