from sympy.combinatorics import PermutationGroup, Permutation

s4 = PermutationGroup(Permutation(0, 1, 2, 3), Permutation(3)(0, 1))
s6 = PermutationGroup(Permutation(0, 1, 2, 3, 5), Permutation(5)(0, 1))
s6.is_normal(s4)
