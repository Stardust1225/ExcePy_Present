#!/bin/bash
cd sympy
git clean -xdf
git reset --hard de0a1a72e45bf1ead69b527a2c798e59372758e2
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test24.py
#test-Traceback
#  File "test24.py", line 4, in <module>
#    periodicity(sin(expint(1, x))/expint(1, x), x)
#  File "./sympy/sympy/calculus/util.py", line 506, in periodicity
#    period = _periodicity(g.args, symbol)
#  File "./sympy/sympy/calculus/util.py", line 585, in _periodicity
#    return periods[0]
#IndexError: list index out of range
#test-errorfilepath
#./sympy/sympy/calculus/util.py
