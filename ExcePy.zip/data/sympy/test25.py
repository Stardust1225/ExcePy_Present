from sympy import S
from sympy.simplify.sqrtdenest import _sqrt_match

I = S.ImaginaryUnit
_sqrt_match(4 + I)
