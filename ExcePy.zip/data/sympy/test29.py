from sympy import O

O(1) * O(1)

