from sympy import sympify

f1 = sympify("a%c")
f2 = sympify("x%z")
f1.equals(f2)
