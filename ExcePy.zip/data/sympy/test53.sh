#!/bin/bash
cd sympy
git clean -xdf
git reset --hard a531dfdf2c536620fdaf080f7470dde08c257e92
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test53.py
#test-Traceback
#RecursionError: maximum recursion depth exceeded in comparison
#test-errorfilepath
#test53.py
