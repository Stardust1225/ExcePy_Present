from sympy import Symbol, Piecewise, Eq

d = Symbol("d", integer=True)
n = Symbol("n", integer=True)
t = Symbol("t", real=True, positive=True)
expr = Piecewise((-d + 2 * n, Eq(1 / t, 1)), (t ** (1 - 4 * n) * t ** (4 * n - 1) * (-d + 2 * n), True))
assert expr.simplify() == -d + 2 * n
