from sympy import *
x = Symbol('x', real=True)
solve(abs((abs(x**2-1)-x))-x)
