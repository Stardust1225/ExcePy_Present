from sympy import Matrix

Matrix([]).eigenvals()
