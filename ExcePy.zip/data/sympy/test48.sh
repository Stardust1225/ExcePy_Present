#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 467d9ad09bd490bfdd2d029686cf27ef28eeb9b3
git reset --hard HEAD^
python -m pip install -e .
cd ..
python test48.py
#test-Traceback
#  File "test48.py", line 3, in <module>
#    for c in (Logic, Logic(1)):
#  File "./sympy/sympy/core/logic.py", line 63, in __new__
#    obj.args = tuple(args)
#TypeError: 'int' object is not iterable
#test-errorfilepath
#./sympy/sympy/core/logic.py
