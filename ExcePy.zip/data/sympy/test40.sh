#!/bin/bash
cd sympy
git clean -xdf
git reset --hard d9fea248edea5e7c3f706c7007ce6a73a2b35c2a
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test40.py
#test-Traceback
#  File "test40.py", line 5, in <module>
#    integrate(f, (y, 0, 1))
#  File "./sympy/sympy/integrals/integrals.py", line 1465, in integrate
#    risch=risch, manual=manual)
#  File "./sympy/sympy/integrals/integrals.py", line 632, in doit
#    evalued = Add(*others)._eval_interval(x, a, b)
#  File "./sympy/sympy/core/expr.py", line 879, in _eval_interval
#    for s in singularities:
#TypeError: 'ConditionSet' object is not iterable
#test-errorfilepath
#./sympy/sympy/core/expr.py
