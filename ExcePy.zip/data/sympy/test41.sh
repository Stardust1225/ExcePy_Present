#!/bin/bash
cd sympy
git clean -xdf
git reset --hard b5bfbbdfacfa6a16f41d72f9a15ca7b6b86805e8
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test41.py
#test-Traceback
#  File "test41.py", line 4, in <module>
#    integrate(exp(I * x) * log(x), x).has(Ei)
#  File "./sympy/sympy/integrals/integrals.py", line 1390, in integrate
#    risch=risch, manual=manual)
#  File "./sympy/sympy/integrals/integrals.py", line 530, in doit
#    function, xab[0], **eval_kwargs)
#  File "./sympy/sympy/integrals/integrals.py", line 865, in _eval_integral
#    return NonElementaryIntegral(f, x).doit(risch=False)
#  File "./sympy/sympy/integrals/integrals.py", line 530, in doit
#    function, xab[0], **eval_kwargs)
#  File "./sympy/sympy/integrals/integrals.py", line 991, in _eval_integral
#    h = meijerint_indefinite(g, x)
#  File "./sympy/sympy/integrals/meijerint.py", line 1620, in meijerint_indefinite
#    res = _meijerint_indefinite_1(f.subs(x, x + a), x)
#  File "./sympy/sympy/integrals/meijerint.py", line 1645, in _meijerint_indefinite_1
#    gs = _rewrite1(f, x)
#  File "./sympy/sympy/integrals/meijerint.py", line 1568, in _rewrite1
#    g = _rewrite_single(g, x, recursive)
#  File "./sympy/sympy/core/cache.py", line 95, in wrapper
#    retval = func(*args, **kwargs)
#  File "./sympy/sympy/integrals/meijerint.py", line 1523, in _rewrite_single
#    simplify=False, needeval=True)
#  File "./sympy/sympy/integrals/transforms.py", line 351, in mellin_transform
#    return MellinTransform(f, x, s).doit(**hints)
#  File "./sympy/sympy/integrals/transforms.py", line 117, in doit
#    self.function_variable, self.transform_variable, **hints)
#  File "./sympy/sympy/integrals/transforms.py", line 294, in _compute_transform
#    return _mellin_transform(f, x, s, **hints)
#  File "./sympy/sympy/integrals/transforms.py", line 195, in wrapper
#    res = func(*args, **kwargs)
#  File "./sympy/sympy/integrals/transforms.py", line 219, in _mellin_transform
#    F = integrator(x**(s - 1) * f, x)
#  File "./sympy/sympy/integrals/meijerint.py", line 1514, in my_integrator
#    r = _meijerint_definite_4(f, x, only_double=True)
#  File "./sympy/sympy/integrals/meijerint.py", line 2010, in _meijerint_definite_4
#    cond = And(cond, _check_antecedents(f1_, f2_, x))
#  File "./sympy/sympy/integrals/meijerint.py", line 1017, in _check_antecedents
#    Or(And(Ne(zos, 1), abs(arg_(1 - zos)) < pi),
#  File "./sympy/sympy/core/expr.py", line 336, in __lt__
#    raise TypeError("Invalid NaN comparison")
#TypeError: Invalid NaN comparison
#test-errorfilepath
#./sympy/sympy/core/expr.py
