#!/bin/bash
cd sympy
git clean -xdf
git reset --hard cdc1e9088a1cb0c29e431a5c3a209e2aaccb72a0
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test7.py
#test-Traceback
#  File "test7.py", line 4, in <module>
#    integrate((sign(x - 1) - sign(x - 2)) * cos(x), x)
#  File "./sympy/sympy/utilities/decorator.py", line 37, in threaded_func
#    return func(expr, *args, **kwargs)
#  File "./sympy/sympy/integrals/integrals.py", line 1252, in integrate
#    risch=risch, manual=manual)
#  File "./sympy/sympy/integrals/integrals.py", line 482, in doit
#    conds=conds)
#  File "./sympy/sympy/integrals/integrals.py", line 890, in _eval_integral
#    for arg in result.args
#  File "./sympy/sympy/integrals/integrals.py", line 890, in <listcomp>
#    for arg in result.args
#  File "./sympy/sympy/core/basic.py", line 1519, in doit
#    for term in self.args]
#  File "./sympy/sympy/core/basic.py", line 1519, in <listcomp>
#    for term in self.args]
#  File "./sympy/sympy/integrals/integrals.py", line 396, in doit
#    function = function.doit(**hints)
#  File "./sympy/sympy/core/basic.py", line 1519, in doit
#    for term in self.args]
#  File "./sympy/sympy/core/basic.py", line 1519, in <listcomp>
#    for term in self.args]
#TypeError: doit() got an unexpected keyword argument 'manual'
#test-errorfilepath
#./sympy/sympy/core/basic.py
