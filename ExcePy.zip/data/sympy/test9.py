import sympy

sympy.ntheory.is_gaussian_prime(1 + 1j)
