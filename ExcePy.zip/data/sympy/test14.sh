#!/bin/bash
cd sympy
git clean -xdf
git reset --hard b3d54957195d49107cb02e38eff5ae75cc75fc61
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test14.py
#test-Traceback
#  File "test14.py", line 3, in <module>
#    asec(0).is_real
#  File "./sympy/sympy/core/assumptions.py", line 245, in getit
#    return _ask(fact, self)
#  File "./sympy/sympy/core/assumptions.py", line 300, in _ask
#    _ask(pk, obj)
#  File "./sympy/sympy/core/assumptions.py", line 288, in _ask
#    a = evaluate(obj)
#  File "./sympy/sympy/core/expr.py", line 693, in _eval_is_positive
#    n2 = self._eval_evalf(2)
#  File "./sympy/sympy/core/function.py", line 487, in _eval_evalf
#    v = func(*args)
#  File "/usr/local/lib/python3.6/dist-packages/mpmath/ctx_mp_python.py", line 1021, in f_wrapped
#    retval = f(ctx, *args, **kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/mpmath/functions/functions.py", line 119, in asec
#    def asec(ctx, z): return ctx.acos(ctx.one / z)
#  File "<string>", line 7, in __div__
#  File "/usr/local/lib/python3.6/dist-packages/mpmath/libmp/libmpf.py", line 960, in mpf_div
#    raise ZeroDivisionError
#ZeroDivisionError
#test-errorfilepath
#./sympy/sympy/core/function.py
