from sympy import Add, Matrix
from sympy.abc import x

Add(Matrix([[3]]), x).subs(x, 2.0)
