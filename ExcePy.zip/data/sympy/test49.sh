#!/bin/bash
cd sympy
git clean -xdf
git reset --hard d1da4ac0412e7537f57baadabea709d58eddd1ba
git reset --hard HEAD^
python -m pip install -e .
cd ..
python test49.py
#test-Traceback
#  File "test49.py", line 4, in <module>
#    capture(pprint(x / y))
#  File "./sympy/sympy/utilities/iterables.py", line 461, in capture
#    func()
#TypeError: 'NoneType' object is not callable
#test-errorfilepath
#./sympy/sympy/utilities/iterables.py
