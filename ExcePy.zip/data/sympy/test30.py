from sympy import SparseMatrix

SparseMatrix([])