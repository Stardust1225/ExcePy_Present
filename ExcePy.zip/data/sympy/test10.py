def concat_badly(a, b):
  return (a + " + %s") % b
concat_badly("a % 2", "b")  
