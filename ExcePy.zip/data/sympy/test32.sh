#!/bin/bash
cd sympy
git clean -xdf
git reset --hard dc2f2785cfd8dc4f23c5f659d9ab6f7e3e097102
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test32.py
#test-Traceback
#  File "test32.py", line 5, in <module>
#    dsolve(v, g(x))
#  File "./sympy/sympy/solvers/ode.py", line 659, in dsolve
#    return _helper_simplify(eq, hint, hints, simplify)
#  File "./sympy/sympy/solvers/ode.py", line 681, in _helper_simplify
#    sols = solvefunc(eq, func, order, match)
#  File "./sympy/sympy/solvers/ode.py", line 4726, in ode_nth_linear_constant_coeff_undetermined_coefficients
#    return _solve_undetermined_coefficients(eq, func, order, match)
#  File "./sympy/sympy/solvers/ode.py", line 4819, in _solve_undetermined_coefficients
#    coeffsdict[s[x]] += s['coeff']
#KeyError: (x - 3)**3
#test-errorfilepath
#./sympy/sympy/solvers/ode.py
