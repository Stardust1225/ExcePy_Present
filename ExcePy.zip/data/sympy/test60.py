from sympy.functions.combinatorial.numbers import nP

nP(0, replacement=True)