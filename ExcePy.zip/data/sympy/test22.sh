#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 1280ab4dbcc5c45969c9999b636e6c4525320a0b
git reset --hard HEAD^
python -m pip install -e .
cd ..
python test22.py
#test-Traceback
#  File "test22.py", line 3, in <module>
#    AlgebraicNumber(sqrt(2)) == None
#  File "./sympy/sympy/polys/numberfields.py", line 444, in __eq__
#    b = to_number_field(b, a)
#  File "./sympy/sympy/polys/numberfields.py", line 371, in to_number_field
#    minpoly, coeffs = primitive_element(extension, gen, polys=True)
#  File "./sympy/sympy/polys/numberfields.py", line 165, in primitive_element
#    extension = [ AlgebraicNumber(ext, gen=x) for ext in extension ]
#  File "./sympy/sympy/polys/numberfields.py", line 405, in __new__
#    elif expr.is_AlgebraicNumber:
#AttributeError: 'NoneType' object has no attribute 'is_AlgebraicNumber'
#test-errorfilepath
#./sympy/sympy/polys/numberfields.py
