from sympy import powsimp, E, oo
from sympy.abc import x

powsimp(-0.1 ** x)
