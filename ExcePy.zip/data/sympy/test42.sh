#!/bin/bash
cd sympy
git clean -xdf
git reset --hard c770854ed1bef5f39b3faed08654543527941a5a
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test42.py
#test-Traceback
#  File "test42.py", line 4, in <module>
#    integrate(1 / (x + y) ** 2, (x, 0, 1))
#  File "./sympy/sympy/integrals/integrals.py", line 1364, in integrate
#    risch=risch, manual=manual)
#  File "./sympy/sympy/integrals/integrals.py", line 595, in doit
#    evalued = Add(*others)._eval_interval(x, a, b)
#  File "./sympy/sympy/core/expr.py", line 866, in _eval_interval
#    if a < s < b:
#  File "./sympy/sympy/core/numbers.py", line 2147, in __lt__
#    return Rational.__lt__(self, other)
#  File "./sympy/sympy/core/numbers.py", line 1805, in __lt__
#    return Expr.__lt__(expr, other)
#  File "./sympy/sympy/core/expr.py", line 341, in __lt__
#    dif = self - other
#  File "./sympy/sympy/core/numbers.py", line 2071, in __sub__
#    return Rational.__sub__(self, other)
#  File "./sympy/sympy/core/decorators.py", line 91, in __sympifyit_wrapper
#    return func(a, b)
#  File "./sympy/sympy/core/numbers.py", line 1595, in __sub__
#    return Number.__sub__(self, other)
#  File "./sympy/sympy/core/decorators.py", line 91, in __sympifyit_wrapper
#    return func(a, b)
#  File "./sympy/sympy/core/numbers.py", line 653, in __sub__
#    return AtomicExpr.__sub__(self, other)
#  File "./sympy/sympy/core/decorators.py", line 91, in __sympifyit_wrapper
#    return func(a, b)
#  File "./sympy/sympy/core/decorators.py", line 132, in binary_op_wrapper
#    return func(self, other)
#  File "./sympy/sympy/core/expr.py", line 130, in __sub__
#    return Add(self, -other)
#TypeError: bad operand type for unary -: 'And'
#test-errorfilepath
#./sympy/sympy/core/expr.py
