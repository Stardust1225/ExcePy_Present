#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 1cde35e43f84bc0f3e44518dcb11b7544a999610
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test16.py
#test-Traceback
#  File "test16.py", line 5, in <module>
#    f1.equals(f2)
#  File "./sympy/sympy/core/expr.py", line 557, in equals
#    constant = diff.is_constant(simplify=False, failing_number=True)
#  File "./sympy/sympy/core/expr.py", line 480, in is_constant
#    a = self.subs(list(zip(free, [0]*len(free))))
#  File "./sympy/sympy/core/basic.py", line 976, in subs
#    rv = rv._subs(old, new, **kwargs)
#  File "./sympy/sympy/core/cache.py", line 100, in wrapper
#    r = func(*args, **kw_args)
#  File "./sympy/sympy/core/basic.py", line 1090, in _subs
#    rv = fallback(self, old, new)
#  File "./sympy/sympy/core/basic.py", line 1062, in fallback
#    arg = arg._subs(old, new, **hints)
#  File "./sympy/sympy/core/cache.py", line 100, in wrapper
#    r = func(*args, **kw_args)
#  File "./sympy/sympy/core/basic.py", line 1090, in _subs
#    rv = fallback(self, old, new)
#  File "./sympy/sympy/core/basic.py", line 1067, in fallback
#    rv = self.func(*args)
#  File "./sympy/sympy/core/cache.py", line 100, in wrapper
#    r = func(*args, **kw_args)
#  File "./sympy/sympy/core/function.py", line 369, in __new__
#    result = super(Function, cls).__new__(cls, *args, **options)
#  File "./sympy/sympy/core/cache.py", line 100, in wrapper
#    r = func(*args, **kw_args)
#  File "./sympy/sympy/core/function.py", line 199, in __new__
#    evaluated = cls.eval(*args)
#  File "./sympy/sympy/core/mod.py", line 121, in eval
#    rv = doit(p, q)
#  File "./sympy/sympy/core/mod.py", line 44, in doit
#    return (p % q)
#  File "./sympy/sympy/core/numbers.py", line 1664, in __mod__
#    return Integer(self.p % other.p)
#ZeroDivisionError: integer division or modulo by zero
#test-errorfilepath
#./sympy/sympy/core/numbers.py
