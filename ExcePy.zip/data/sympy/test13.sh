#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 92789cb65929c939a263b659846fe98c5b1e3df9
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test13.py
#test-Traceback
#  File "test13.py", line 21, in <module>
#    R.dup_isolate_real_roots(a * g)
#  File "./sympy/sympy/polys/compatibility.py", line 921, in dup_isolate_real_roots
#    return dup_isolate_real_roots(self.to_dense(f), self.domain, eps=eps, inf=inf, sup=sup, basis=basis, fast=fast)
#  File "./sympy/sympy/polys/rootisolation.py", line 545, in dup_isolate_real_roots
#    I_pos = dup_inner_isolate_positive_roots(f, K, eps=eps, inf=inf, sup=sup, fast=fast)
#  File "./sympy/sympy/polys/rootisolation.py", line 426, in dup_inner_isolate_positive_roots
#    roots = dup_inner_isolate_real_roots(f, K, eps=eps, fast=fast)
#  File "./sympy/sympy/polys/rootisolation.py", line 313, in dup_inner_isolate_real_roots
#    A = dup_root_lower_bound(f, K)
#  File "./sympy/sympy/polys/rootisolation.py", line 125, in dup_root_lower_bound
#    bound = dup_root_upper_bound(dup_reverse(f), K)
#  File "./sympy/sympy/polys/rootisolation.py", line 114, in dup_root_upper_bound
#    return 2.0**(max(P) + 1)
#OverflowError: (34, 'Numerical result out of range')
#test-errorfilepath
#./sympy/sympy/polys/rootisolation.py
