from sympy import symbols, Eq, dsolve

x, g = symbols('x g')
v = Eq(g(x).diff(x).diff(x), (x - 2) ** 2 + (x - 3) ** 3)
dsolve(v, g(x))
