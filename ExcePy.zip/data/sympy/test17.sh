#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 07933cd11c8050ffb24def7ed1e6724833eee230
git reset --hard HEAD^
python -m pip install -e .
cd ..
python test17.py
#test-Traceback
#  File "test17.py", line 3, in <module>
#    1 / Float(0)
#  File "./sympy/sympy/core/decorators.py", line 74, in __sympifyit_wrapper
#    return func(a, b)
#  File "./sympy/sympy/core/decorators.py", line 115, in binary_op_wrapper
#    return func(self, other)
#  File "./sympy/sympy/core/expr.py", line 185, in __rdiv__
#    return Mul(other, Pow(self, S.NegativeOne))
#  File "./sympy/sympy/core/cache.py", line 92, in wrapper
#    func_cache_it_cache[k] = r = func(*args, **kw_args)
#  File "./sympy/sympy/core/power.py", line 102, in __new__
#    obj = b._eval_power(e)
#  File "./sympy/sympy/core/numbers.py", line 802, in _eval_power
#    mlib.mpf_pow_int(self._mpf_, expt.p, prec, rnd), prec)
#  File "./sympy/sympy/mpmath/libmp/libmpf.py", line 1044, in mpf_pow_int
#    if n == -1: return mpf_div(fone, s, prec, rnd)
#  File "./sympy/sympy/mpmath/libmp/libmpf.py", line 934, in mpf_div
#    raise ZeroDivisionError
#ZeroDivisionError
#test-errorfilepath
#./sympy/sympy/mpmath/libmp/libmpf.py
