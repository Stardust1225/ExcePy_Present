#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 4d4f9ad75c580f99ec4e1666fdbd2e1fe47b12ea
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test34.py
#test-Traceback
#  File "test34.py", line 4, in <module>
#    Eq(n * cos(n) - 3 * sin(n), 0).as_set()
#  File "./sympy/sympy/logic/boolalg.py", line 159, in as_set
#    return self.subs(reps)._eval_as_set()
#  File "./sympy/sympy/core/relational.py", line 395, in _eval_as_set
#    return solve_univariate_inequality(self, x, relational=False)
#  File "./sympy/sympy/solvers/inequalities.py", line 534, in solve_univariate_inequality
#    ''' % expr.subs(gen, Symbol('x'))))
#NotImplementedError: The inequality, Eq(x*cos(x) - 3*sin(x), 0), cannot be solved usingsolve_univariate_inequality.
#test-errorfilepath
#./sympy/sympy/solvers/inequalities.py
