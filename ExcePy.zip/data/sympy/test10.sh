#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 1f25f9b55438944948d7261e366e5632d9d59b14
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test10.py
#test-Traceback
#  File "test10.py", line 3, in <module>
#    concat_badly("a % 2", "b")
#  File "test10.py", line 2, in concat_badly
#    return (a + " + %s") % b
#ValueError: unsupported format character ' ' (0x20) at index 5
#test-errorfilepath
#test10.py
