from sympy.core.logic import Logic

for c in (Logic, Logic(1)):
    tuple(c)
