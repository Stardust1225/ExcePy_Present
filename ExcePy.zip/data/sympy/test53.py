from sympy import latex
from sympy.parsing.sympy_parser import parse_expr

expr = parse_expr('5/1', evaluate=False)
latex(expr)
