#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 97a87711554828f8c85f498159ca84605792d160
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test21.py
#test-Traceback
#  File "test21.py", line 4, in <module>
#    limit(sqrt(30) * 5 ** (-5 * x - 1) * (46656 * x) ** x * (5 * x + 2) ** (5 * x + 5 * S.Half) *
#AttributeError: 'Symbol' object has no attribute 'Half'
#test-errorfilepath
#test21.py
