from sympy import KroneckerDelta, Symbol

p = Symbol('p', prime=True)
KroneckerDelta(p, 0)