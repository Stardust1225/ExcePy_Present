from sympy import *

x, y, z = var('x y z')
Derivative(x, y).xreplace({x: 2 * z, y: 2 * z})
