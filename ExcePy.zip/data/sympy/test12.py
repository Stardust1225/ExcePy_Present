from sympy import QQ

int(QQ(2 ** 2000, 3 ** 1250))
