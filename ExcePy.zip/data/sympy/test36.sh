#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 4db172694083be19cbcbd911b46c1f111c1c2031
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test36.py
#test-Traceback
#  File "test36.py", line 4, in <module>
#    exp(x * log(x)).series(n=3)
#  File "./sympy/sympy/core/expr.py", line 2871, in series
#    rv = self.subs(x, xpos).series(xpos, x0, n, dir, logx=logx)
#  File "./sympy/sympy/core/expr.py", line 2878, in series
#    s1 = self._eval_nseries(x, n=n, logx=logx)
#  File "./sympy/sympy/functions/elementary/exponential.py", line 451, in _eval_nseries
#    r = exp(arg0)*exp_series.subs(t, arg_series - arg0)
#  File "./sympy/sympy/core/basic.py", line 971, in subs
#    rv = rv._subs(old, new, **kwargs)
#  File "./sympy/sympy/core/cache.py", line 96, in wrapper
#    retval = func(*args, **kwargs)
#  File "./sympy/sympy/core/basic.py", line 1085, in _subs
#    rv = fallback(self, old, new)
#  File "./sympy/sympy/core/basic.py", line 1057, in fallback
#    arg = arg._subs(old, new, **hints)
#  File "./sympy/sympy/core/cache.py", line 96, in wrapper
#    retval = func(*args, **kwargs)
#  File "./sympy/sympy/core/basic.py", line 1083, in _subs
#    rv = self._eval_subs(old, new)
#  File "./sympy/sympy/series/order.py", line 445, in _eval_subs
#    res = [dict(zip((d, ), sol))]
#TypeError: zip argument #2 must support iteration
#test-errorfilepath
#./sympy/sympy/series/order.py
