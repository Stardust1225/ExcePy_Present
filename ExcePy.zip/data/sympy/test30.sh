#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 6a9be10fc5c8fe7e813d64e8d30c9cd2a8499b02
git reset --hard HEAD^
python -m pip install -e .
cd ..
python test30.py
#test-Traceback
#  File "test30.py", line 3, in <module>
#    SparseMatrix([])
#  File "./sympy/sympy/matrices/matrices.py", line 2971, in __init__
#    if not is_sequence(mat[0]):
#IndexError: list index out of range
#test-errorfilepath
#./sympy/sympy/matrices/matrices.py
