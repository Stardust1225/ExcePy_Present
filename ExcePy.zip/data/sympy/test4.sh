#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 65c15350b485cee4d558d458a01e0171e20199c6
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test4.py
#test-Traceback
#  File "test4.py", line 3, in <module>
#    solve(abs((abs(x**2-1)-x))-x)
#  File "./sympy/sympy/solvers/solvers.py", line 1029, in solve
#    'is not real or imaginary.' % e)
#NotImplementedError: solving Abs(-x + Piecewise((x**2 - 1, x**2 - 1 >= 0), (1 - x**2, True))) when the argument is not real or imaginary.
#test-errorfilepath
#./sympy/sympy/solvers/solvers.py

