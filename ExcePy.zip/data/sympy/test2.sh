#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 747f0a596db4bb30aeec36b2d350ab117b215945
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test2.py
#test-Traceback
#  File "test2.py", line 2, in <module>
#    evaluate_pauli_product(1)
#  File "./sympy/sympy/physics/paulialgebra.py", line 157, in evaluate_pauli_product
#    tmp = arg.as_coeff_mul()
#AttributeError: 'int' object has no attribute 'as_coeff_mul'
#test-errorfilepath
#./sympy/sympy/physics/paulialgebra.py

