from sympy import Circle, Point2D, sqrt, intersection

c1 = Circle(Point2D(180 + 24 * sqrt(210), 168), 231)
c2 = Circle(Point2D(889, 89 + 2 * sqrt(9879)), 174)
intersection(c1, c2)
