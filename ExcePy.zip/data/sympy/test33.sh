#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 50d47cfe61f9982e8f1cf2e99bc3cdfa4dc2079c
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test33.py
#test-Traceback
#  File "test33.py", line 4, in <module>
#    trigsimp_groebner(csc(x) * sin(x))
#  File "./sympy/sympy/simplify/trigsimp.py", line 379, in trigsimp_groebner
#    num = Poly(num, gens=gens+freegens).eject(*gens)
#NameError: name 'Poly' is not defined
#test-errorfilepath
#./sympy/sympy/simplify/trigsimp.py
