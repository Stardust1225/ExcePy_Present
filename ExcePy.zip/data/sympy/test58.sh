#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 54d2da14dba81dca07087f682f3b5fd3e9577b25
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test58.py
#test-Traceback
#  File "test58.py", line 3, in <module>
#    Cycle(3).list(2)
#  File "./sympy/sympy/combinatorics/permutations.py", line 372, in list
#    big = max([i for i in self.keys() if self[i] != i])
#ValueError: max() arg is an empty sequence
#test-errorfilepath
#./sympy/sympy/combinatorics/permutations.py
