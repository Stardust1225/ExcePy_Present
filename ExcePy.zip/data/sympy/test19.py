from sympy import solveset
from sympy.abc import x

solveset(29 * 2 ** (x + 1) * 615 ** (x / 3) - 123 * 2726 ** (x / 3), x)
