#!/bin/bash
cd sympy
git clean -xdf
git reset --hard dd32579b06ae7c90fba7342026888bd0bb6402a4
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test55.py
#test-Traceback
#  File "test55.py", line 3, in <module>
#    oo > oo
#  File "./sympy/sympy/core/expr.py", line 387, in __gt__
#    return self._cmp(other, ">", StrictGreaterThan)
#  File "./sympy/sympy/core/expr.py", line 372, in _cmp
#    raise ValueError("Undefined comparison of infinite values")
#ValueError: Undefined comparison of infinite values
#test-errorfilepath
#./sympy/sympy/core/expr.py
