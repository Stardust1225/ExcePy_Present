#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 294fb1524f6b5d92d2caeca150f23a87bf308417
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test6.py
#test-Traceback
#  File "test6.py", line 4, in <module>
#    Integral(1/r**2,(r,oo,a)).doit()
#  File "./sympy/sympy/integrals/integrals.py", line 495, in doit
#    ret = try_meijerg(function, xab)
#  File "./sympy/sympy/integrals/integrals.py", line 467, in try_meijerg
#    res = meijerint_definite(function, x, a, b)
#  File "./sympy/sympy/integrals/meijerint.py", line 1803, in meijerint_definite
#    return -meijerint_definite(f, x, b, oo)
#TypeError: bad operand type for unary -: 'tuple'
#test-errorfilepath
#./sympy/sympy/integrals/meijerint.py
