from sympy import Trace, MatrixSymbol, symbols, Derivative

k = symbols("k")
A = MatrixSymbol("A", k, k)
expr = Trace(A) * A
expr.diff(A)
