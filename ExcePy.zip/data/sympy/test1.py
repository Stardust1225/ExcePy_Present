from sympy import *
from sympy.stats import *

n, p = symbols('n p')
B = Binomial('B', n, p)
H(B)
