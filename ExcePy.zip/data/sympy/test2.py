from sympy.physics.paulialgebra import Pauli, evaluate_pauli_product
evaluate_pauli_product(1)
