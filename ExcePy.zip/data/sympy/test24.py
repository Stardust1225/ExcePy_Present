from sympy import periodicity, sin, expint
from sympy.abc import x

periodicity(sin(expint(1, x))/expint(1, x), x)
