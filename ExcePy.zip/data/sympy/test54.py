from sympy import integrate, exp
from sympy.abc import x

integrate(exp(x) / (1 + x) ** 2, x)
