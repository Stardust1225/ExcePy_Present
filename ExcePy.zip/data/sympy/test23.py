from sympy import CRootOf, cse
from sympy.abc import x

eq = CRootOf(x ** 5 + 11 * x - 2, 0) + CRootOf(x ** 5 + 11 * x - 2, 1)
cse(eq) == ([], [eq])
