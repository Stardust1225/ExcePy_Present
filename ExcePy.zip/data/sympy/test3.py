from sympy import symbols, Function, Eq, dsolve

V, I = symbols("V I", cls=Function)
RC, t, C, Vs, L, R1, V0, I0 = symbols("RC t C Vs L R1 V0 I0")
system = [Eq(V(t).diff(t), -1/RC*V(t) + I(t)/C), Eq(I(t).diff(t), -R1/L*I(t) - 1/L*V(t) + Vs/L)]
ics = {V(0): V0, I(0): I0}
dsolve(system, [V(t), I(t)], ics=ics)
