#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 9e017ea8a22688ddb1f9b6b933b3fa563dd328e1
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test27.py
#test-Traceback
#  File "test27.py", line 5, in <module>
#    s6.is_normal(s4)
#  File "./sympy/sympy/combinatorics/perm_groups.py", line 1597, in is_normal
#    p = _af_rmuln(g1, g2, _af_invert(g1))
#  File "./sympy/sympy/combinatorics/permutations.py", line 81, in _af_rmuln
#    return [p0[p1[i]] for i in p2]
#  File "./sympy/sympy/combinatorics/permutations.py", line 81, in <listcomp>
#    return [p0[p1[i]] for i in p2]
#IndexError: list index out of range
#test-errorfilepath
#./sympy/sympy/combinatorics/permutations.py
