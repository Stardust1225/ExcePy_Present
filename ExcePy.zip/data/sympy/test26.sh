#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 5ed90ba9232c8e29591990ee8deba16d55749ef4
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test26.py
#test-Traceback
#  File "test26.py", line 3, in <module>
#    Matrix([]).eigenvals()
#  File "./sympy/sympy/matrices/matrices.py", line 3062, in eigenvals
#    return mat.berkowitz_eigenvals(**flags)
#  File "./sympy/sympy/matrices/matrices.py", line 3043, in berkowitz_eigenvals
#    return roots(self.berkowitz_charpoly(Dummy('x')), **flags)
#  File "./sympy/sympy/matrices/matrices.py", line 3031, in berkowitz_charpoly
#    return PurePoly(list(map(simplify, self.berkowitz()[-1])), x)
#  File "./sympy/sympy/matrices/matrices.py", line 2955, in berkowitz
#    polys = [self._new([S.One, -A[0, 0]])]
#  File "./sympy/sympy/matrices/dense.py", line 91, in __getitem__
#    return self.extract(i, j)
#  File "./sympy/sympy/matrices/matrices.py", line 1075, in extract
#    rowsList = [a2idx(k, self.rows) for k in rowsList]
#  File "./sympy/sympy/matrices/matrices.py", line 1075, in <listcomp>
#    rowsList = [a2idx(k, self.rows) for k in rowsList]
#  File "./sympy/sympy/matrices/matrices.py", line 4435, in a2idx
#    raise IndexError("Index out of range: a[%s]" % (j, ))
#IndexError: Index out of range: a[0]
#test-errorfilepath
#./sympy/sympy/matrices/matrices.py
