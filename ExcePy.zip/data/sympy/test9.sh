#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 62f7afff08aa05ef5e78df36aafa7430762d6c90
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test9.py
#test-Traceback
#  File "test9.py", line 3, in <module>
#    sympy.ntheory.is_gaussian_prime(1 + 1j)
#  File "./sympy/sympy/ntheory/primetest.py", line 656, in is_gaussian_prime
#    a = as_int(a)
#  File "./sympy/sympy/core/compatibility.py", line 303, in as_int
#    raise ValueError('%s is not an integer' % (n,))
#ValueError: 1.00000000000000 is not an integer
#test-errorfilepath
#./sympy/sympy/core/compatibility.py
