from sympy import integrate, exp, I, log, Ei
from sympy.abc import x

integrate(exp(I * x) * log(x), x).has(Ei)
