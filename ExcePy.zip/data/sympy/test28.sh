#!/bin/bash
cd sympy
git clean -xdf
git reset --hard e93f87294f36c6807492a6af4ebd543ff70e7325
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test28.py
#test-Traceback
#  File "test28.py", line 4, in <module>
#    KroneckerDelta(p, 0)
#  File "./sympy/sympy/core/cache.py", line 91, in wrapper
#    retval = cfunc(*args, **kwargs)
#  File "./sympy/sympy/core/function.py", line 376, in __new__
#    result = super(Function, cls).__new__(cls, *args, **options)
#  File "./sympy/sympy/core/cache.py", line 91, in wrapper
#    retval = cfunc(*args, **kwargs)
#  File "./sympy/sympy/core/function.py", line 200, in __new__
#    evaluated = cls.eval(*args)
#  File "./sympy/sympy/functions/special/tensor_functions.py", line 167, in eval
#    return cls(0, diff.args[0])
#IndexError: tuple index out of range
#test-errorfilepath
#./sympy/sympy/functions/special/tensor_functions.py
