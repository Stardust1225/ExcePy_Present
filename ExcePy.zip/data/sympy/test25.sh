#!/bin/bash
cd sympy
git clean -xdf
git reset --hard f99ed644c4baa15dce312a8ff520cecd9ae9ac6d
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test25.py
#test-Traceback
#  File "test25.py", line 5, in <module>
#    _sqrt_match(4 + I)
#  File "./sympy/sympy/simplify/sqrtdenest.py", line 160, in _sqrt_match
#    r, b, a = split_surds(p)
#  File "./sympy/sympy/simplify/radsimp.py", line 1080, in split_surds
#    g, b1, b2 = _split_gcd(*surds)
#  File "./sympy/sympy/simplify/radsimp.py", line 1116, in _split_gcd
#    g = a[0]
#IndexError: tuple index out of range
#test-errorfilepath
#./sympy/sympy/simplify/radsimp.py
