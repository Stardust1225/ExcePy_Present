#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 3418c8ad696f08f4a8c802de2b28258af55bd6a3
git reset --hard HEAD^
python -m pip install -e .
cd ..
python test18.py
#test-Traceback
#  File "test18.py", line 4, in <module>
#    limit(cos(x)/x, x, oo)
#  File "./sympy/sympy/series/limits.py", line 79, in limit
#    r = heuristics(e, z, z0, dir)
#  File "./sympy/sympy/series/limits.py", line 84, in heuristics
#    return limit(e.subs(z, 1/z), z, sympify(0), "+")
#  File "./sympy/sympy/series/limits.py", line 79, in limit
#    r = heuristics(e, z, z0, dir)
#  File "./sympy/sympy/series/limits.py", line 89, in heuristics
#    r.append(a.limit(z, z0, dir))
#  File "./sympy/sympy/core/expr.py", line 746, in limit
#    return limit(self, x, xlim, direction)
#  File "./sympy/sympy/series/limits.py", line 79, in limit
#    r = heuristics(e, z, z0, dir)
#  File "./sympy/sympy/series/limits.py", line 98, in heuristics
#    return e.subs(e.args[0], limit(e.args[0], z, z0, dir))
#  File "./sympy/sympy/core/basic.py", line 705, in subs
#    return self._subs_old_new(old, new)
#  File "./sympy/sympy/core/cache.py", line 85, in wrapper
#    func_cache_it_cache[k] = r = func(*args, **kw_args)
#  File "./sympy/sympy/core/basic.py", line 714, in _subs_old_new
#    return self._eval_subs(old, new)
#  File "./sympy/sympy/core/function.py", line 167, in _eval_subs
#    return Basic._seq_subs(self, old, new)
#  File "./sympy/sympy/core/basic.py", line 799, in _seq_subs
#    return self.func(*[s.subs(old, new) for s in args])
#  File "./sympy/sympy/core/multidimensional.py", line 136, in wrapper
#    return f(*args, **kwargs)
#  File "./sympy/sympy/core/cache.py", line 85, in wrapper
#    func_cache_it_cache[k] = r = func(*args, **kw_args)
#  File "./sympy/sympy/core/function.py", line 212, in __new__
#    return Application.__new__(cls, *args, **options)
#  File "./sympy/sympy/core/multidimensional.py", line 136, in wrapper
#    return f(*args, **kwargs)
#  File "./sympy/sympy/core/cache.py", line 85, in wrapper
#    func_cache_it_cache[k] = r = func(*args, **kw_args)
#  File "./sympy/sympy/core/function.py", line 110, in __new__
#    evaluated = cls.eval(*args)
#  File "./sympy/sympy/functions/elementary/trigonometric.py", line 303, in eval
#    Q, P = 2*p // q, p % q
#ZeroDivisionError: integer division or modulo by zero
#test-errorfilepath
#./sympy/sympy/functions/elementary/trigonometric.py
