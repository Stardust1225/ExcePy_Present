#!/bin/bash
cd sympy
git clean -xdf
git reset --hard f5216255a829b75d081a6601e71c478a39a752f1
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test38.py
#test-Traceback
#  File "test38.py", line 4, in <module>
#    solve(-erf(x ** (S(1) / 3)) ** pi + I, x) == []
#TypeError: 'Symbol' object is not callable
#test-errorfilepath
#test38.py
