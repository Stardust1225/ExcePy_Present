#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 714993f3467ff891e7acb6fb875499c2e498c0b5
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test37.py
#test-Traceback
#  File "test37.py", line 7, in <module>
#    assert expr.simplify() == -d + 2 * n
#  File "./sympy/sympy/core/basic.py", line 1655, in simplify
#    return simplify(self, **kwargs)
#  File "./sympy/sympy/simplify/simplify.py", line 559, in simplify
#    return _eval_simplify(**kwargs)
#  File "./sympy/sympy/functions/elementary/piecewise.py", line 321, in _eval_simplify
#    return piecewise_simplify(self, **kwargs)
#  File "./sympy/sympy/functions/elementary/piecewise.py", line 1200, in piecewise_simplify
#    for i, (expr, cond) in enumerate(args):
#TypeError: 'Mul' object is not iterable
#test-errorfilepath
#./sympy/sympy/functions/elementary/piecewise.py
