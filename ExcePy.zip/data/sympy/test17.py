from sympy import Float

1 / Float(0)
