from sympy import *
from sympy.abc import x, y

f = (4 * (1 / y - 1) * exp(-2 * (1 / y - 1))) / (y ** 2)
integrate(f, (y, 0, 1))
