#!/bin/bash
apt-get install -y python3-dev python-dev git
git clone https://github.com/sympy/sympy.git
