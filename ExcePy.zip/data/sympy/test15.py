import inspect
from sympy import lambdify, Symbol

x = Symbol('x')
f = lambdify(x, x ** 2)
inspect.getsource(f)
