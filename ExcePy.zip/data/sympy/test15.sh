#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 8a892b200a9a7b04e3c86514b7cea9ad3c8be36b
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test15.py
#test-Traceback
#  File "test15.py", line 7, in <module>
#    inspect.getsource(f)
#  File "/usr/lib/python3.6/inspect.py", line 973, in getsource
#    lines, lnum = getsourcelines(object)
#  File "/usr/lib/python3.6/inspect.py", line 955, in getsourcelines
#    lines, lnum = findsource(object)
#  File "/usr/lib/python3.6/inspect.py", line 786, in findsource
#    raise OSError('could not get source code')
#OSError: could not get source code
#test-errorfilepath
#test15.py
