from sympy import Eq, cos, sin, symbols

n = symbols("n")
Eq(n * cos(n) - 3 * sin(n), 0).as_set()
