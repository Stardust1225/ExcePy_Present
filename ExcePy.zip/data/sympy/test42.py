from sympy import integrate
from sympy.abc import x, y

integrate(1 / (x + y) ** 2, (x, 0, 1))
