from sympy import AlgebraicNumber, sqrt

AlgebraicNumber(sqrt(2)) == None
