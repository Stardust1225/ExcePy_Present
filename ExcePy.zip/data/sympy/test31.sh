#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 4ad2b02a72dd0a6f74a457a110602af17bde166e
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test31.py
#test-Traceback
#  File "test31.py", line 7, in <module>
#    dsolve(system, [V(t), I(t)], ics=ics)
#  File "./sympy/sympy/solvers/ode.py", line 584, in dsolve
#    match = classify_sysode(eq, func)
#  File "./sympy/sympy/solvers/ode.py", line 1377, in classify_sysode
#    if not order[func]:
#KeyError: I(t)
#test-errorfilepath
