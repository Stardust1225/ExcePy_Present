#!/bin/bash
cd sympy
git clean -xdf
git reset --hard 597148ea0d2c34722323383feae8503311cd6f31
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test29.py
#test-Traceback
#  File "test29.py", line 3, in <module>
#    O(1) * O(1)
#  File "./sympy/sympy/core/decorators.py", line 77, in __sympifyit_wrapper
#    return func(a, b)
#  File "./sympy/sympy/core/decorators.py", line 118, in binary_op_wrapper
#    return func(self, other)
#  File "./sympy/sympy/core/expr.py", line 141, in __mul__
#    return Mul(self, other)
#  File "./sympy/sympy/core/cache.py", line 91, in wrapper
#    retval = cfunc(*args, **kwargs)
#  File "./sympy/sympy/core/operations.py", line 41, in __new__
#    c_part, nc_part, order_symbols = cls.flatten(args)
#  File "./sympy/sympy/core/mul.py", line 237, in flatten
#    o, order_symbols = o.as_expr_variables(order_symbols)
#  File "./sympy/sympy/series/order.py", line 307, in as_expr_variables
#    if order_symbols[0][1] != self.point[0]:
#IndexError: tuple index out of range
#test-errorfilepath
#./sympy/sympy/series/order.py
