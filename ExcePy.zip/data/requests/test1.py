from http.cookies import SimpleCookie

import requests

sclst = ['dwac_bcIBMiaagZmkYaaadeYtg11eVR=j9jHdmPjUhgDOhyH9f89X4lQgehEmflVyeA%3D|dw-only|||CNY|false|Asia%2FShanghai|true; Path=/',
 'sid=j9jHdmPjUhgDOhyH9f89X4lQgehEmflVyeA; Path=/',
 'geoLocation=CN; Path=/',
 'dwpersonalization_fae107a9dd0fc32ed99532ec1977f31f=bc8sEiaagZqRsaaadk8XoNTL8h20150506; Expires=Sun, 14-Jun-2015 10:37:07 GMT; Path=/',
 'dwanonymous_fae107a9dd0fc32ed99532ec1977f31f=abjpA8kng31LjPp8ZEERDT4XVg; Version=1; Comment="Demandware anonymous cookie for site Sites-abercrombie_cn-Site"; Max-Age=15552000; Expires=Tue, 10-Nov-2015 10:37:07 GMT; Path=/',
 'myStore=91156; Path=/',
 'AF_PREF=en_CN; Path=/',
 'dwsid=MiHJy3KYZKDcN0lZg4HS1zSpj1VV4s_tFu39ar0KXNpAx9aX8X2LlvZQ9m5fOOknb6QXtmmukHcOjmivYf31hg==; path=/; HttpOnly']

for sc in sclst:
  C = SimpleCookie(sc)
  for morsel in C.values():
    cookie = requests.cookies.morsel_to_cookie(morsel)
