#!/bin/bash
python3 -m pip install lxml
cd requests
git clean -xdf
git reset --hard 2f55393593fb0d8818fa014bc004dfed73564110
git reset --hard HEAD^
python -m pip install -e .
cd ..
python test3.py
#test-Traceback
#  File "test3.py", line 6, in <module>
#    tree = etree.parse(r, parser)
#  File "src/lxml/etree.pyx", line 3521, in lxml.etree.parse
#  File "src/lxml/parser.pxi", line 1875, in lxml.etree._parseDocument
#TypeError: 'NoneType' object is not callable
#test-errorfilepath
#test3.py
