from http.cookies import SimpleCookie

import requests

str_cookie = "B=9a3jpi98r1dd8&b=3&s=fb; expires=Sun, 07-Jun-2015 16:15:36 GMT; path=/; domain=.yahoo.com"
C = SimpleCookie(str_cookie)
for morsel in C.values():
  cookie = requests.cookies.morsel_to_cookie(morsel)
  print(cookie)
