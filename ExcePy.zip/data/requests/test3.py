import requests
import lxml.etree as etree

r = requests.get('http://www.google.com')
parser = etree.HTMLParser()
tree = etree.parse(r, parser)
