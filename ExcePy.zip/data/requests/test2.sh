#!/bin/bash
cd requests
git clean -xdf
git reset --hard 961790f95c7c06dc073d882acb28810a22d27b77
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test2.py
#test-Traceback
#  File "test2.py", line 8, in <module>
#    cookie = requests.cookies.morsel_to_cookie(morsel)
#  File "./requests/requests/cookies.py", line 374, in morsel_to_cookie
#    rfc2109=False,)
#  File "./requests/requests/cookies.py", line 344, in create_cookie
#    raise TypeError(err % list(badargs))
#TypeError: create_cookie() got unexpected keyword arguments: ['path_specified', 'domain_specified', 'domain_initial_dot', 'port_specified']
#test-errorfilepath
#./requests/requests/cookies.py

