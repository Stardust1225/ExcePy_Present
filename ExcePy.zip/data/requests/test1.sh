#!/bin/bash
cd requests
git clean -xdf
git reset --hard cda95d3cdee339f10d48287395368e31c386f296
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test1.py
#test-Traceback
#  File "test1.py", line 17, in <module>
#    cookie = requests.cookies.morsel_to_cookie(morsel)
#  File "./requests/requests/cookies.py", line 418, in morsel_to_cookie
#    expires = time.time() + morsel['max-age']
#TypeError: unsupported operand type(s) for +: 'float' and 'str'
#test-errorfilepath
#./requests/requests/cookies.py
