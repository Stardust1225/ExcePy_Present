import numpy as np
from skimage import transform

img = np.random.random((100, 100))
tested_angles = np.array([np.pi / 2])
h, theta, d = transform.hough_line(img, theta=tested_angles)
accum, angles, dists = transform.hough_line_peaks(h, theta, d, threshold=2)
