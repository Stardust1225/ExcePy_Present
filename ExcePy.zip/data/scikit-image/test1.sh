#!/bin/bash
cd scikit-image
git clean -xdf
git reset --hard e13e59664d01bf337b900c61b7af4741f654b4d1
git reset --hard HEAD^
python3 setup.py develop
cd ..
python3 test1.py
#test-Traceback
#  File "./test1.py", line 7, in <module>
#    accum, angles, dists = transform.hough_line_peaks(h, theta, d, threshold=2)
#  File "./scikit-image/skimage/transform/hough_transform.py", line 64, in hough_line_peaks
#    num_peaks=num_peaks)
#  File "./scikit-image/skimage/feature/peak.py", line 349, in _prominent_peaks
#    img_max[ycoords_nh, xcoords_nh] = 0
#IndexError: index -9 is out of bounds for axis 1 with size 1
#test-errorfilepath
