import numpy as np

a = np.matrix([[1, 2, 0]])
np.partition(a, 1, axis=None)
