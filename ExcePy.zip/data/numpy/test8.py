import numpy.polynomial as poly
from numpy.core import array

coefs = [0 + 1j, 1 + 1j, -2 + 2j, 3 + 0j]
p2 = poly.Polynomial(array(coefs, dtype=object))
poly.set_default_printstyle('unicode')
str(p2)
