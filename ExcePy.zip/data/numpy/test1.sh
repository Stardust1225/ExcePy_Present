#!/bin/bash
cd numpy
git clean -xdf
git reset --hard ef5656d842459a6c338ee03ee422d7bd4b8beb61
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test1.py
#test-Traceback
#  File "./numpy/numpy/lib/npyio.py", line 223, in __del__
#    self.close()
#  File "./numpy/numpy/lib/npyio.py", line 214, in close
#    if self.zip is not None:
#AttributeError: 'NpzFile' object has no attribute 'zip'
#test-errorfilepath
#./numpy/numpy/lib/npyio.py
