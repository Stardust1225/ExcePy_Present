#!/bin/bash
cd numpy
git clean -xdf
git reset --hard 3caf1223b9b8e4747fb7b41b2fbd2122ee175d03
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test6.py
#test-Traceback
#  File "test6.py", line 5, in <module>
#    r = np.rec.fromrecords([], dtype=dtype)
#  File "./numpy/numpy/core/records.py", line 658, in fromrecords
#    nfields = len(recList[0])
#IndexError: list index out of range
#test-errorfilepath
#./numpy/numpy/core/records.py

