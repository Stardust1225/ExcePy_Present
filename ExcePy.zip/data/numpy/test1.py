import zipfile
with zipfile.ZipFile('spam.zip', 'w') as myzip:
  myzip.writestr('spam.zip', 'eggs')
with open('spam.zip', 'w+b') as fh:
  fh.seek(2)
  fh.write(b"\xde\xad\xc0\xde")

from numpy.lib.npyio import NpzFile
NpzFile('spam.zip')
