#!/bin/bash
cd numpy
git clean -xdf
git reset --hard b60f33dd0747574570764ac8072386dccc85dd44
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test7.py
#test-Traceback
#  File "test7.py", line 6, in <module>
#    memmap(tmpfp, shape=(0, 4), mode='w+')
#  File "./numpy/numpy/core/memmap.py", line 250, in __new__
#    fid.seek(bytes - 1, 0)
#  File "/usr/lib/python3.8/tempfile.py", line 613, in func_wrapper
#    return func(*args, **kwargs)
#OSError: [Errno 22] Invalid argument
#test-errorfilepath
#./numpy/numpy/core/memmap.py
