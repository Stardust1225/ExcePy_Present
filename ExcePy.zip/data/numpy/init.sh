#!/bin/bash
apt-get install -y git python3-dev python-dev
git clone https://github.com/numpy/numpy.git
pip3 install cython
