#!/bin/bash
cd numpy
git clean -xdf
git reset --hard 66365a57ff9b68a191fd232dc823cc2cf69d267f
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test8.py
#test-Traceback
#  File "test8.py", line 7, in <module>
#    str(p2)
#  File "./numpy/numpy/polynomial/_polybase.py", line 333, in __str__
#    return self._generate_string(self._str_term_unicode)
#  File "./numpy/numpy/polynomial/_polybase.py", line 350, in _generate_string
#    if coef >= 0:
#TypeError: '>=' not supported between instances of 'complex' and 'int'
#test-errorfilepath
#./numpy/numpy/polynomial/_polybase.py
