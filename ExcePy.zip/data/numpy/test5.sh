#!/bin/bash
cd numpy
git clean -xdf
git reset --hard 144197146dec4097baa2783fdd28762015d0e32b
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test5.py
#test-Traceback
#  File "test5.py", line 5, in <module>
#    ma[[]]
#  File "./numpy/numpy/ma/core.py", line 3252, in __getitem__
#    dout._fill_value = self._fill_value[indx]
#IndexError: too many indices for array
#test-errorfilepath
#./numpy/numpy/ma/core.py

