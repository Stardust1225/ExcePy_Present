from tempfile import NamedTemporaryFile

from numpy import memmap

tmpfp = NamedTemporaryFile(prefix='mmap')
memmap(tmpfp, shape=(0, 4), mode='w+')
