import numpy as np
from numpy.testing import assert_array_equal

a = np.array([-2, 0, 127], dtype=np.int8)
hist, edges = np.histogram(a, bins="auto")
