import numpy as np

b = np.poly1d([2, 6, 6, 1])
a = np.poly1d([-1j, (1 + 2j), -(2 + 1j), 1])
q, r = np.polydiv(b, a)
