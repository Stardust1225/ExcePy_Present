#!/bin/bash
cd numpy
git clean -xdf
git reset --hard 3ff4924ead45ef6db81778daae08e3c939ea4629
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test10.py
#test-Traceback
#  File "test10.py", line 5, in <module>
#    hist, edges = np.histogram(a, bins="auto")
#  File "<__array_function__ internals>", line 5, in histogram
#  File "./numpy/numpy/lib/histograms.py", line 785, in histogram
#    bin_edges, uniform_bins = _get_bin_edges(a, bins, range, weights)
#  File "./numpy/numpy/lib/histograms.py", line 439, in _get_bin_edges
#    bin_edges = np.linspace(
#  File "<__array_function__ internals>", line 5, in linspace
#  File "./numpy/numpy/core/function_base.py", line 124, in linspace
#    raise ValueError("Number of samples, %s, must be non-negative." % num)
#ValueError: Number of samples, -1, must be non-negative.
#test-errorfilepath
#./numpy/numpy/core/function_base.py
