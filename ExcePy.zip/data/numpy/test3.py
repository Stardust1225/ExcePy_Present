from numpy.lib import _datasource
ds = _datasource.DataSource()
del ds._istmpdest
ds.__del__()
