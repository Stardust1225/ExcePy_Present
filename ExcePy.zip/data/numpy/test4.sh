#!/bin/bash
cd numpy
git clean -xdf
git reset --hard 2582c681082e6c2c74d424e255afa8efefa4f899
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test4.py
#test-Traceback
#  File "test4.py", line 4, in <module>
#    a.mean(axis=2)
#  File "./numpy/numpy/core/_methods.py", line 147, in _mean
#    rcount = _count_reduce_items(arr, axis)
#  File "./numpy/numpy/core/_methods.py", line 66, in _count_reduce_items
#    items *= arr.shape[ax]
#IndexError: tuple index out of range
#test-errorfilepath
#./numpy/numpy/core/_methods.py

