#!/bin/bash
cd numpy
git clean -xdf
git reset --hard e988535a06c8150e28e6858d7be0a5d2f7e08fa9
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test9.py
#test-Traceback
#  File "test9.py", line 5, in <module>
#    q, r = np.polydiv(b, a)
#  File "./numpy/numpy/lib/polynomial.py", line 904, in polydiv
#    r[k:k+n+1] -= d*v
#TypeError: Cannot cast ufunc subtract output from dtype('complex128') to dtype('float64') with casting rule 'same_kind'
#test-errorfilepath
#./numpy/numpy/lib/polynomial.py

