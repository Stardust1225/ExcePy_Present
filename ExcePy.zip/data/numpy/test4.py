import numpy as np

a = np.arange(10)
a.mean(axis=2)
