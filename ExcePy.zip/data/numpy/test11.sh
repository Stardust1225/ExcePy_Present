#!/bin/bash
cd numpy
git clean -xdf
git reset --hard 1e45ea470eaae8d23c161f78931e946847e2b7e4
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test11.py
#test-Traceback
#  File "test11.py", line 4, in <module>
#    np.partition(a, 1, axis=None)
#  File "./numpy/numpy/core/fromnumeric.py", line 664, in partition
#    a.partition(kth, axis=axis, kind=kind, order=order)
#ValueError: kth(=1) out of bounds (1)
#test-errorfilepath
#./numpy/numpy/core/fromnumeric.py
