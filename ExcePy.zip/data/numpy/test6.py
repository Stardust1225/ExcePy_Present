import numpy as np
from nose.tools import assert_equal

dtype = [('a', np.float), ('b', np.float)]
r = np.rec.fromrecords([], dtype=dtype)
