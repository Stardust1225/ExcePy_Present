#!/bin/bash
cd numpy
git clean -xdf
git reset --hard 619422b493eaf88c42373af1725ac0aa2297fa91
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test2.py
#test-Traceback
#  File "test2.py", line 5, in <module>
#    print(a['b']['c'])
#  File "./numpy/numpy/ma/core.py", line 3308, in __getitem__
#    if dout._fill_value.ndim > 0:
#AttributeError: 'str' object has no attribute 'ndim'
#test-errorfilepath
#./numpy/numpy/ma/core.py
