import numpy as np

my_dtype = np.dtype([('b', [('c', object)], (1,))])
a = np.ma.masked_all((1,), my_dtype)
print(a['b']['c'])
