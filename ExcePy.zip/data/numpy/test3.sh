#!/bin/bash
cd numpy
git clean -xdf
git reset --hard 470d53fc6bc8267fec7d7cf5c7116d5e7437d789
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test3.py
#test-Traceback
#  File "test3.py", line 4, in <module>
#    ds.__del__()
#  File "./numpy/numpy/lib/_datasource.py", line 326, in __del__
#    if self._istmpdest:
#AttributeError: 'DataSource' object has no attribute '_istmpdest'
#test-errorfilepath
#./numpy/numpy/lib/_datasource.py

