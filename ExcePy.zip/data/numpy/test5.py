import numpy as np
from numpy.ma.testutils import assert_array_equal

ma = np.ma.MaskedArray([(1, 1.), (2, 2.), (3, 3.)], dtype='i4,f4')
ma[[]]
