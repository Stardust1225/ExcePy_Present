import io
import textwrap
import scipy.io

s = """\
            %%MatrixMarket matrix array real general
              3  3 999
            1.0
            2.0
            3.0
            4.0
            5.0
            6.0
            7.0
            8.0
            9.0
            """
text = textwrap.dedent(s).encode('ascii')
scipy.io.mmread(io.BytesIO(text))