from scipy.optimize import minimize, Bounds

bnds = Bounds(1, 2)
opts = {'maxiter': 1000, 'verbose': 2}
res = minimize(lambda x: x ** 2, x0=2., method='trust-constr', bounds=bnds, options=opts)

opts = {'maxiter': 1000, 'verbose': 3}
res = minimize(lambda x: x ** 2, x0=2., method='trust-constr', bounds=bnds, options=opts)
