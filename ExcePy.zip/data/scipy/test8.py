import numpy as np
from scipy import optimize

F = np.array([[1, 1, 1], [1, 1, 0], [1, 0, 1], [1, 0, 0], [1, 0, 0]])
K = np.array([1., 0.3, 0.5])
startparams = np.zeros(3, np.float64)


def func(x):
    log_pdot = np.dot(F, x)
    logZ = np.log(sum(np.exp(log_pdot)))
    f = logZ - np.dot(K, x)
    return f


def grad(x):
    log_pdot = np.dot(F, x)
    logZ = np.log(sum(np.exp(log_pdot)))
    p = np.exp(log_pdot - logZ)
    return np.dot(F.transpose(), p) - K


opts = {'maxiter': -1}
result = optimize.minimize(func, startparams,
                           method='Newton-CG', jac=grad,
                           args=(), options=opts)
result.status == 1
