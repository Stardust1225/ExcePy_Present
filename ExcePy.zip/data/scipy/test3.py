from scipy.optimize import NonlinearConstraint, Bounds, minimize


def function(x): return x[0] ** 2 + x[1] ** 2


def functionjacobian(x): return np.array([2. * x[0], 2. * x[1]])

import numpy as np

def functionhvp(x, v): return 2. * v


def constraint(x): return np.array([x[0] ** 2 - x[1] ** 2])


def constraintjacobian(x): return np.array([[2 * x[0], -2 * x[1]]])


def constraintlcoh(x, v): return np.array([[2., 0.], [0., -2.]]) * v[0]


constraint = NonlinearConstraint(constraint, 1., np.inf, constraintjacobian, constraintlcoh)

startpoint = [1., 2.]

bounds = Bounds([-np.inf, -np.inf], [np.inf, np.inf])

result = minimize(
    function,
    startpoint,
    method='trust-constr',
    jac=functionjacobian,
    hessp=functionhvp,
    constraints=[constraint],
    bounds=bounds,
)
