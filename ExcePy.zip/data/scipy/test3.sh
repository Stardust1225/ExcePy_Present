#!/bin/bash
cd scipy
git clean -xdf
git reset --hard 39e134763d22842e6eff566ba6cb851c766fe1c1
git reset --hard HEAD^
python3 setup.py build -j 4 && python3 setup.py develop
cd ..
python3 test3.py
#test-Traceback
#  File "test3.py", line 29, in <module>
#    result = minimize(
#  File "./scipy/scipy/optimize/_minimize.py", line 610, in minimize
#    return _minimize_trustregion_constr(fun, x0, args, jac, hess, hessp,
#  File "./scipy/scipy/optimize/_trustregion_constr/minimize_trustregion_constr.py", line 508, in _minimize_trustregion_constr
#    _, result = tr_interior_point(
#  File "./scipy/scipy/optimize/_trustregion_constr/tr_interior_point.py", line 305, in tr_interior_point
#    subprob = BarrierSubproblem(
#  File "./scipy/scipy/optimize/_trustregion_constr/tr_interior_point.py", line 53, in __init__
#    self.fun0 = self._compute_function(fun0, constr_ineq0, s0)
#  File "./scipy/scipy/optimize/_trustregion_constr/tr_interior_point.py", line 93, in _compute_function
#    s[self.enforce_feasibility] = -c_ineq[self.enforce_feasibility]
#IndexError: arrays used as indices must be of integer (or boolean) type
#test-errorfilepath
#./scipy/scipy/optimize/_trustregion_constr/tr_interior_point.py
