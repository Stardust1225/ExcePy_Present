import numpy as np
from scipy import linalg

hamiltonian = np.mat('[1,0,0,0;0,-1,0,0;0,0,-1,0;0,0,0,1]')

t_list = np.linspace(0, 10, 100)
unitary = [linalg.expm(-(1j) * t * hamiltonian) for t in t_list]
