#!/bin/bash
python3 -m pip install numpy==1.16.5 Cython
cd scipy
git clean -xdf
git reset --hard 72358b88b2918e0f296cd3769464fff447b8d55e
git reset --hard HEAD^
python3 setup.py build -j 4 && python3 setup.py develop
cd ..
python3 test1.py
#test-Traceback
#  File "test1.py", line 5, in <module>
#    result = stats.ttest_ind_from_stats(0, 0, 6, 0, 0, 6, equal_var=False)
#  File "./scipy/scipy/stats/stats.py", line 5612, in ttest_ind_from_stats
#    df, denom = _unequal_var_ttest_denom(std1**2, nobs1,
#  File "./scipy/scipy/stats/stats.py", line 5480, in _unequal_var_ttest_denom
#    df = (vn1 + vn2)**2 / (vn1**2 / (n1 - 1) + vn2**2 / (n2 - 1))
#ZeroDivisionError: float division by zero
#test-errorfilepath
#./scipy/scipy/stats/stats.py
