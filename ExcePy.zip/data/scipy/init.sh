#!/bin/bash
apt-get install -y python3-dev python-dev git
apt-get install -y gcc gfortran python-dev libopenblas-dev liblapack-dev cython
apt-get install -y libopenblas-base libatlas3-base
git clone https://github.com/scipy/scipy.git
