import numpy as np
from nose.tools import assert_equal
from scipy import stats

result = stats.ttest_ind_from_stats(0, 0, 6, 0, 0, 6, equal_var=False)