#!/bin/bash
cd scipy
git clean -xdf
git reset --hard ba7f2c0357cfe26ee51fb890404f3f7324b95939
git reset --hard HEAD^
python3 setup.py build -j 4 && python3 setup.py develop
cd ..
python3 test2.py
#test-Traceback
#  File "test2.py", line 3, in <module>
#    savgol_coeffs(window_length=7, polyorder=3, deriv=4)
#  File "./scipy/scipy/signal/_savitzky_golay.py", line 132, in savgol_coeffs
#    y[deriv] = factorial(deriv) / (delta ** deriv)
#IndexError: index 4 is out of bounds for axis 0 with size 4
#test-errorfilepath
#./scipy/scipy/signal/_savitzky_golay.py
