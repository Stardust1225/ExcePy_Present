from scipy.signal import savgol_coeffs

savgol_coeffs(window_length=7, polyorder=3, deriv=4)
