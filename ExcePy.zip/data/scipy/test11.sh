#!/bin/bash
cd scipy
git clean -xdf
git reset --hard ec9b47bfca0fcd4c3835b30a2bcd5d28baa63fd5
git reset --hard HEAD^
python3 -m pip install numpy==1.11.3
python3 -m pip install Cython==0.25
python3 setup.py build -j 4
python3 setup.py develop
cd ..
python3 test11.py
#test-Traceback
#  File "test11.py", line 7, in <module>
#    unitary = [linalg.expm(-(1j) * t * hamiltonian) for t in t_list]
#  File "test11.py", line 7, in <listcomp>
#    unitary = [linalg.expm(-(1j) * t * hamiltonian) for t in t_list]
#  File "./scipy/scipy/linalg/matfuncs.py", line 261, in expm
#    return scipy.sparse.linalg.expm(A)
#  File "./scipy/scipy/sparse/linalg/matfuncs.py", line 582, in expm
#    return _expm(A, use_exact_onenorm='auto')
#  File "./scipy/scipy/sparse/linalg/matfuncs.py", line 637, in _expm
#    X = _fragment_2_1(X, h.A, s)
#  File "./scipy/scipy/sparse/linalg/matfuncs.py", line 755, in _fragment_2_1
#    X[k, k] = exp_diag[k]
#TypeError: only length-1 arrays can be converted to Python scalars
#test-errorfilepath
#./scipy/scipy/sparse/linalg/matfuncs.py
