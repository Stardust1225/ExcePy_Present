#!/bin/bash
cd scipy
git clean -xdf
git reset --hard 248c30b2afcfc16b32b7f96eaaf9c5c75e8ece82
git reset --hard HEAD^
python3 -m pip install numpy==1.13.3 && python3 -m pip install Cython==0.29.3 && python3 setup.py build -j 4 && python3 setup.py develop
cd ..
python3 test7.py
#test-Traceback
#  File "test7.py", line 10, in <module>
#    radau.step()
#  File "./scipy/scipy/integrate/_ivp/base.py", line 182, in step
#    success, message = self._step_impl()
#  File "./scipy/scipy/integrate/_ivp/radau.py", line 451, in _step_impl
#    LU_real, LU_complex, self.solve_lu)
#  File "./scipy/scipy/integrate/_ivp/radau.py", line 138, in solve_collocation_system
#    return converged, k + 1, Z, rate
#UnboundLocalError: local variable 'rate' referenced before assignment
#test-errorfilepath
#./scipy/scipy/integrate/_ivp/radau.py
