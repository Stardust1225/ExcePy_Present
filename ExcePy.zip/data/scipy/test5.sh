#!/bin/bash
cd scipy
git clean -xdf
git reset --hard a037f212d6ae8d2a0a88d1a9a25760e6aa10f216
git reset --hard HEAD^
python3 -m pip install numpy==1.14.5 && python3 -m pip install Cython==0.29.18 && python3 setup.py build -j 4 && python3 setup.py develop
cd ..
python3 test5.py
#test-Traceback
#Traceback (most recent call last):
#  File "test5.py", line 18, in <module>
#    scipy.io.mmread(io.BytesIO(text))
#  File "/home/xin/Documents/scipy/scipy/scipy/io/mmio.py", line 72, in mmread
#    return MMFile().read(source)
#  File "/home/xin/Documents/scipy/scipy/scipy/io/mmio.py", line 423, in read
#    self._parse_header(stream)
#  File "/home/xin/Documents/scipy/scipy/scipy/io/mmio.py", line 487, in _parse_header
#    self.__class__.info(stream)
#  File "/home/xin/Documents/scipy/scipy/scipy/io/mmio.py", line 259, in info
#    raise ValueError("Header line not of length 3: " + line)
#TypeError: must be str, not bytes
