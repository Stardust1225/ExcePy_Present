#!/bin/bash
cd scipy
git clean -xdf
git reset --hard be7496a2b32ec7bfa5c8924df98fa0313fb51c16
git reset --hard HEAD^
python3 -m pip install numpy==1.8.2 && python3 -m pip install Cython==0.29.3 && python3 setup.py build -j 4 && python3 setup.py develop
cd ..
python3 test6.py
#test-Traceback
#  File "test6.py", line 26, in <module>
#    args=(), options=opts)
#  File "./scipy/scipy/optimize/_minimize.py", line 484, in minimize
#    **options)
#  File "./scipy/scipy/optimize/optimize.py", line 1566, in _minimize_newtoncg
#    return terminate(1, msg)
#  File "./scipy/scipy/optimize/optimize.py", line 1538, in terminate
#    result = OptimizeResult(fun=fval, jac=gfk, nfev=fcalls[0],
#NameError: free variable 'gfk' referenced before assignment in enclosing scope
#test-errorfilepath
#./scipy/scipy/optimize/optimize.py
