#!/bin/bash
cd scipy
git clean -xdf
git reset --hard 5ad5cebd8f1d50ec1126181608e4bf624fe4072f
git reset --hard HEAD^
python3 -m pip install numpy==1.17.1 Cython==0.29.13 && python3 setup.py build -j 4 && python3 setup.py develop
cd ..
python3 test10.py
#test-Traceback
#  File "test10.py", line 5, in <module>
#    res = minimize(lambda x: x ** 2, x0=2., method='trust-constr', bounds=bnds, options=opts)
#  File "./scipy/scipy/optimize/_minimize.py", line 622, in minimize
#    callback=callback, **options)
#  File "./scipy/scipy/optimize/_trustregion_constr/minimize_trustregion_constr.py", line 519, in _minimize_trustregion_constr
#    factorization_method)
#  File "./scipy/scipy/optimize/_trustregion_constr/tr_interior_point.py", line 329, in tr_interior_point
#    factorization_method, trust_lb, trust_ub, subprob.scaling)
#  File "./scipy/scipy/optimize/_trustregion_constr/equality_constrained_sqp.py", line 96, in equality_constrained_sqp
#    trust_radius, penalty, cg_info):
#  File "./scipy/scipy/optimize/_trustregion_constr/tr_interior_point.py", line 257, in stop_criteria
#    self.tolerance):
#  File "./scipy/scipy/optimize/_trustregion_constr/minimize_trustregion_constr.py", line 454, in stop_criteria
#    state.constr_violation)
#  File "./scipy/scipy/optimize/_trustregion_constr/report.py", line 22, in print_iteration
#    print(fmt.format(*args))
#TypeError: unsupported format string passed to numpy.ndarray.__format__
#test-errorfilepath
#./scipy/scipy/optimize/_trustregion_constr/report.py
