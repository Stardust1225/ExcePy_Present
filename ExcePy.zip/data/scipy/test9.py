import numpy as np
from scipy import stats

np.random.seed(12345678)
n1 = 2097152
rvs1 = stats.uniform.rvs(size=n1, loc=0., scale=1)
rvs2 = rvs1 + 1
stats.ks_2samp(rvs1, rvs2, alternative='greater', mode='asymp')
stats.ks_2samp(rvs1, rvs2, alternative='less', mode='asymp')
stats.ks_2samp(rvs1, rvs2, alternative='two-sided', mode='asymp')
