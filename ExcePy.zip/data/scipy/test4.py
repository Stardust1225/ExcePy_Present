import numpy as np
from scipy.linalg import cdf2rdf

X = np.array([
    [[1, 2, 3], [1, 2, 3], [2, 5, 6 + 1j]],
    [[1, 2, 3], [1, 2, 3], [2, 5, 6 - 1j]],
])
w, v = np.linalg.eig(X)
cdf2rdf(w, v)
