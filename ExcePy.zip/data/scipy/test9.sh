#!/bin/bash
cd scipy
git clean -xdf
git reset --hard f974e4baaf04c3e359f1abc0fe4fbb0579045f2d
git reset --hard HEAD^
python3 -m pip install numpy==1.19 Cython==0.29.20 && python3 setup.py build -j 4 && python3 setup.py develop
cd ..
python3 test9.py
#test-Traceback
#  File "test9.py", line 8, in <module>
#    stats.ks_2samp(rvs1, rvs2, alternative='greater', mode='asymp')
#  File "./scipy/scipy/stats/stats.py", line 6741, in ks_2samp
#    expt = -2 * z**2 - 2 * z * (m + 2*n)/np.sqrt(m*n*(m+n))/3.0
#TypeError: loop of ufunc does not support argument 0 of type int which has no callable sqrt method
#test-errorfilepath
#./scipy/scipy/stats/stats.py
