#!/bin/bash
cd scipy
git clean -xdf
git reset --hard c06bd99c7cc5f2a7a284ea7ab315c49c4c8cf518
git reset --hard HEAD^
python3 setup.py build -j 4 && python3 setup.py develop
cd ..
python3 test4.py
#test-Traceback
#  File "test4.py", line 9, in <module>
#    cdf2rdf(w, v)
#  File "./scipy/scipy/linalg/decomp.py", line 1391, in cdf2rdf
#    w_mat[mat, j, k] = w[mat, j].imag
#IndexError: index 3 is out of bounds for axis 2 with size 3
#test-errorfilepath
#./scipy/scipy/linalg/decomp.py
