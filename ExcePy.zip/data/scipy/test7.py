import numpy as np
from scipy.integrate import Radau


def fun(t, y):
    return (1,) if t == 0 else (np.nan,)


radau = Radau(fun, t0=0, y0=(0,), t_bound=1)
radau.step()
