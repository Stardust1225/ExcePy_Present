#!/bin/bash
cd pandas
git clean -xdf
git reset --hard 39602e7d7c5b663696f5a6eca9e66e65483bc868
git reset --hard HEAD^
python3 -m pip install numpy==1.13.3
python3 -m pip install Cython==0.29.13
pip3 install -e .
cd ..
python3 test2.py
#test-Traceback
#  File "test2.py", line 5, in <module>
#    lambda rows: pd.DataFrame({'var': [rows.iloc[-1]['var']],
#  File "./pandas/pandas/core/groupby/groupby.py", line 727, in apply
#    result = self._python_apply_general(f)
#  File "./pandas/pandas/core/groupby/groupby.py", line 743, in _python_apply_general
#    keys, values, mutated = self.grouper.apply(f, self._selected_obj, self.axis)
#  File "./pandas/pandas/core/groupby/ops.py", line 240, in apply
#   res = f(group)
#  File "test2.py", line 6, in <lambda>
#    'val': [rows.iloc[-1]['vau']]}))
#  File "./pandas/pandas/core/series.py", line 1081, in __getitem__
#    result = self.index.get_value(self, key)
#  File "./pandas/pandas/core/indexes/base.py", line 4672, in get_value
#    raise e1
#  File "./pandas/pandas/core/indexes/base.py", line 4658, in get_value
#    return self._engine.get_value(s, k, tz=getattr(series.dtype, "tz", None))
#  File "pandas/_libs/index.pyx", line 77, in pandas._libs.index.IndexEngine.get_value
#  File "pandas/_libs/index.pyx", line 85, in pandas._libs.index.IndexEngine.get_value
#  File "pandas/_libs/index.pyx", line 128, in pandas._libs.index.IndexEngine.get_loc
#  File "pandas/_libs/hashtable_class_helper.pxi", line 1607, in pandas._libs.hashtable.PyObjectHashTable.get_item
#  File "pandas/_libs/hashtable_class_helper.pxi", line 1614, in pandas._libs.hashtable.PyObjectHashTable.get_item
#KeyError: 'vau'
#test-errorfilepath
#./pandas/pandas/core/indexes/base.pys
