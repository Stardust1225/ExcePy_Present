#!/bin/bash
cd pandas
git clean -xdf
git reset --hard e6d8953f8cd5ad9f22894a8948e9b6340ad819f4
git reset --hard HEAD^
python3 -m pip install numpy==1.9.0
python3 -m pip install Cython==0.23
pip3 install -e .
cd ..
python3 test3.py
#test-Traceback
#  File "test3.py", line 9, in <module>
#    sig = make_signature(deprecate_kwarg)
#  File "./pandas/pandas/util/_decorators.py", line 245, in make_signature
#    defaults = ('',) * n_wo_defaults + spec.defaults
#TypeError: can only concatenate tuple (not "list") to tuple
#test-errorfilepath
#./pandas/pandas/util/_decorators.py

