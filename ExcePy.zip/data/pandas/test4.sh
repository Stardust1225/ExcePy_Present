#!/bin/bash
cd pandas
git clean -xdf
git reset --hard 55921715933c4c127c31324f38771d5597f777ad
git reset --hard HEAD^
python3 -m pip install numpy==1.7.0
python3 -m pip install Cython==0.19.1
pip3 install -e .
cd ..
python3 test4.py
#test-Traceback
#  File "test4.py", line 5, in <module>
#    s.iloc[1::2] = [1, 3, 5]
#  File "./pandas/pandas/core/indexing.py", line 118, in __setitem__
#    self._setitem_with_indexer(indexer, value)
#  File "./pandas/pandas/core/indexing.py", line 498, in _setitem_with_indexer
#    self.obj._data = self.obj._data.setitem(indexer=indexer, value=value)
#  File "./pandas/pandas/core/internals.py", line 2483, in setitem
#    return self.apply('setitem', **kwargs)
#  File "./pandas/pandas/core/internals.py", line 2459, in apply
#    applied = getattr(b, f)(**kwargs)
#  File "./pandas/pandas/core/internals.py", line 570, in setitem
#    raise ValueError("cannot set using a slice indexer with a "
#ValueError: cannot set using a slice indexer with a different length than the value
#test-errorfilepath
#./pandas/pandas/core/internals.py
