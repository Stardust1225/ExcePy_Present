#!/bin/bash
cd pandas
git clean -xdf
git reset --hard abf8493486fa53605f9696996c0a43ba937a314b
git reset --hard HEAD^
python3 -m pip install numpy==1.7.0
python3 -m pip install Cython==0.19.1
pip3 install -e .
cd ..
python3 test5.py
#test-Traceback
#  File "test5.py", line 8, in <module>
#    result = idx.delete(0)
#  File "./pandas/pandas/tseries/index.py", line 1630, in delete
#    return DatetimeIndex(new_dates, name=self.name, freq=freq, tz=self.tz)
#  File "./pandas/pandas/tseries/index.py", line 317, in __new__
#    'conform to passed frequency {1}'.format(inferred, freq.freqstr))
#ValueError: Inferred frequency None from passed dates does notconform to passed frequency H
#test-errorfilepath
#./pandas/pandas/tseries/index.py
