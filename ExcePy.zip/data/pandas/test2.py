import pandas as pd

test = pd.DataFrame({'var': ['a', 'a', 'b', 'b'], 'val': range(4)})
test.groupby('var').apply(
    lambda rows: pd.DataFrame({'var': [rows.iloc[-1]['var']],
                               'val': [rows.iloc[-1]['vau']]}))
