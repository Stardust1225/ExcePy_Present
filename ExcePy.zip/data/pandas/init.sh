#!/bin/bash
apt-get install -y git python3-dev python-dev
git clone https://github.com/pandas-dev/pandas.git
