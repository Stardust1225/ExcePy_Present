from pandas.util._decorators import deprecate_kwarg, make_signature
from pandas.util._validators import validate_kwargs

sig = make_signature(validate_kwargs)
assert sig == (['fname', 'kwargs', 'compat_args'],
               ['fname', 'kwargs', 'compat_args'])

# Case where the func does have default kwargs
sig = make_signature(deprecate_kwarg)
assert sig == (['old_arg_name', 'new_arg_name',
                'mapping=None', 'stacklevel=2'],
               ['old_arg_name', 'new_arg_name', 'mapping', 'stacklevel'])
