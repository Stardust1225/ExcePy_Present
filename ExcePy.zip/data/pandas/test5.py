from pandas import date_range

for tz in [None, 'Asia/Tokyo', 'US/Pacific']:
    idx = date_range(start='2000-01-01 09:00', periods=10,
                     freq='H', name='idx', tz=tz)
    expected = date_range(start='2000-01-01 10:00', periods=9,
                          freq='H', name='idx', tz=tz)
    result = idx.delete(0)
