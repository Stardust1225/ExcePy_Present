#!/bin/bash
cd pandas
git clean -xdf
git reset --hard 70802c2a4bdd5e377b36b5dff0203cf844460fd6
git reset --hard HEAD^
pip3 install numpy==1.15
pip3 install -e.
cd ..
python3 test1.py
#test-Traceback
#  File "test1.py", line 4, in <module>
#    df.drop(columns=['A','not_occurring'])
#  File "./pandas/pandas/core/frame.py", line 3901, in drop
#    return super(DataFrame, self).drop(labels=labels, axis=axis,
#  File "./pandas/pandas/core/generic.py", line 3778, in drop
#    obj = obj._drop_axis(labels, axis, level=level, errors=errors)
#  File "./pandas/pandas/core/generic.py", line 3810, in _drop_axis
#    new_axis = axis.drop(labels, errors=errors)
#  File "./pandas/pandas/core/indexes/base.py", line 4979, in drop
#    raise KeyError(
#KeyError: "['not_occurring'] not found in axis"
#test-errorfilepath
#./pandas/pandas/core/indexes/base.py
