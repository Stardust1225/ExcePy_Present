#!/bin/bash
cd tensorflow
git reset --hard eebc5e7bf8e2113ee5417bbc03f61f4027ec981b
pip3 install tensorflow==2.0.0b0
cd ..
python3 test3.py
#test-Traceback
#  File "test3.py", line 5, in <module>
#    [[.9, .05, .05], [.5, .89, .6], [.05, .01, .94]])
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/losses.py", line 123, in __call__
#    losses = self.call(y_true, y_pred)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/losses.py", line 215, in call
#    return self.fn(y_true, y_pred, **self._fn_kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/losses.py", line 953, in sparse_categorical_crossentropy
#    y_true, y_pred, from_logits=from_logits, axis=axis)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/backend.py", line 4257, in sparse_categorical_crossentropy
#    output.op.type != 'Softmax'):
#AttributeError: 'list' object has no attribute 'op'
