from tensorflow.keras.models import load_model
model = load_model("model_6_combined_2_DA.h5")
print(model.summary())