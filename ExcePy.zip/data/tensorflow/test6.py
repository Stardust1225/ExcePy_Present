import tensorflow as tf

for policy in ["float32", "mixed_float16"]:
    for run_eagerly in [False, True]:
        print(policy, run_eagerly)
        tf.keras.mixed_precision.experimental.set_policy(policy)
        model = tf.keras.Sequential([
            tf.keras.layers.Dense(1024),
            tf.keras.layers.Dense(5),
        ])
        model.compile(optimizer="rmsprop", loss="mse", run_eagerly=run_eagerly)
        model.fit(tf.random.uniform(shape=(1024, 32)), tf.random.uniform(shape=(1024, 5)))
