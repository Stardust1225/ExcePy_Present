import tensorflow as tf
tf.boolean_mask([1, 2, 3], [True, False, True], axis=tf.constant(0, dtype=tf.int32))
