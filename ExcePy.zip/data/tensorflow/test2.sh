#!/bin/bash
cd tensorflow
git reset --hard 1b8786471f49d6f13ce237524e694a81ca930957
sudo pip3 install tensorflow==2.0.0-beta1
cd ..
python3 test2.py
#test-Traceback
#  File "test2.py", line 39, in <module>
#    validation_data = ({'input_0' : val_input_0, 'input_1':  val_input_1}, val_labels) )
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/training.py", line 643, in fit
#    use_multiprocessing=use_multiprocessing)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/training_arrays.py", line 664, in fit
#    steps_name='steps_per_epoch')
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/training_arrays.py", line 210, in model_iteration
#    val_samples_or_steps = val_inputs and val_inputs[0].shape[0] or None
#KeyError: 0
