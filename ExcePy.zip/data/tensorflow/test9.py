import tensorflow as tf
raw = tf.ones((2))
tf.train.shuffle_batch([raw], batch_size=2, capacity=4, min_after_dequeue=4, seed=5)
