#!/bin/bash
cd tensorflow
git reset --hard a744818876ab362ad4112b625f40b2a0dbdafb12
sudo pip3 install tensorflow==2.1.0
cd ..
python3 test10.py
#test-Traceback
#  File "test10.py", line 6, in <module>
#    m.update_state([0, 1, 1, 1], [1, 0, 1, 1])
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/utils/metrics_utils.py", line 76, in decorated
#    update_op = update_state_fn(*args, **kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/metrics.py", line 1342, in update_state
#    sample_weight=sample_weight)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/utils/metrics_utils.py", line 440, in update_confusion_matrix_variables
#    variables_to_update[matrix_cond]))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/utils/metrics_utils.py", line 416, in weighted_assign_add
#    return var.assign_add(math_ops.reduce_sum(label_and_pred, 1))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow_core/python/ops/resource_variable_ops.py", line 785, in assign_add
#    self.handle, ops.convert_to_tensor(delta, dtype=self.dtype),
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow_core/python/framework/ops.py", line 1290, in convert_to_tensor
#    (dtype.name, value.dtype.name, value))
#ValueError: Tensor conversion requested dtype float64 for Tensor with dtype float32: <tf.Tensor: shape=(1,), dtype=float32, numpy=array([2.], dtype=float32)>
