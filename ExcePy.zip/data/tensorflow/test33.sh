#!/bin/bash
cd tensorflow
git reset --hard fa867b0e3fe5f6c36405a7019ec6b8b0e001bed5
sudo pip3 install tensorflow==1.2.0rc1
cd ..
python3 test33.py
#test-Traceback
#  File "test33.py", line 6, in <module>
#    foo = array_ops.sparse_placeholder(dtypes.float32, shape=(10, 47))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/array_ops.py", line 1594, in sparse_placeholder
#    dense_shape=shape)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/sparse_tensor.py", line 127, in __init__
#    dense_shape, name="dense_shape", dtype=dtypes.int64)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/ops.py", line 676, in convert_to_tensor
#    as_ref=False)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/ops.py", line 741, in internal_convert_to_tensor
#    ret = conversion_func(value, dtype=dtype, name=name, as_ref=as_ref)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/ops.py", line 614, in _TensorTensorConversionFunction
#    % (dtype.name, t.dtype.name, str(t)))
#ValueError: Tensor conversion requested dtype int64 for Tensor with dtype int32: 'Tensor("Const:0", shape=(2,), dtype=int32)'
