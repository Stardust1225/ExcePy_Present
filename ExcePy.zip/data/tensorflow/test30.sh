#!/bin/bash
cd tensorflow
git reset --hard 10f93e513d04320ca0a24cd8421bcf46283c887f
sudo pip3 install tensorflow==2.0.0
cd ..
python3 test30.py
#test-Traceback
#  File "test30.py", line 5, in <module>
#    np.array(42.0).__index__()
#TypeError: only integer scalar arrays can be converted to a scalar index
