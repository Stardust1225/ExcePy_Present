import tensorflow as tf

a = tf.constant(list("ababa"))
print(a)
b = tf.sparse.from_dense(a)
print(b)
