import tensorflow as tf
frame_length = 512
frame_step = 256
signal = tf.random.uniform(shape=(1000,))
x = tf.signal.stft(signal, frame_length, frame_step)
y = tf.signal.inverse_stft(x, frame_length, frame_step)
