#!/bin/bash
cd tensorflow
git reset --hard aae0fc015b531b23ecd46b096d19d45b64ba7d31
sudo pip3 install tensorflow==2.4.0
cd ..
python3 test23.py
#test-Traceback
#  File "test23.py", line 12, in <module>
#    dtype=dtype))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/tensor_util.py", line 640, in MakeNdarray
#    raise TypeError("Unsupported tensor type: %s" % tensor.dtype)
#TypeError: Unsupported tensor type: 22
