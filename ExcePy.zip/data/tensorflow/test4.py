import tensorflow as tf
tf.math.real(1.)
