#!/bin/bash
cd tensorflow
git reset --hard 390eed2958d950aa76c7d5a84e1f17360d14f9fd
pip3 install tensorflow==2.0.0a0
cd ..
python3 test1.py
#test-Traceback
#  File "test1.py", line 19, in <module>
#    my_vars = module.variables
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/module/module.py", line 131, in variables
#    return tuple(self._flatten(predicate=_IS_VARIABLE))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/module/module.py", line 304, in _flatten_module
#    for leaf_path, leaf in nest.flatten_with_tuple_paths(module_dict[key]):
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/util/nest.py", line 1175, in flatten_with_tuple_paths
#    return list(zip(yield_flat_paths(structure), flatten(structure)))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/util/nest.py", line 1132, in yield_flat_paths
#    for k, _ in _yield_flat_up_to(nest, nest):
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/util/nest.py", line 614, in _yield_flat_up_to
#    input_tree = dict(_yield_sorted_items(input_tree))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/util/nest.py", line 164, in _yield_sorted_items
#    yield key, iterable[key]
#KeyError: 'hello'
