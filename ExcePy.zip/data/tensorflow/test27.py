from tensorflow.python.autograph.operators import py_builtins
from tensorflow.python.data.ops import dataset_ops

dataset = dataset_ops.DatasetV2.from_tensor_slices([3, 2, 1])
t = py_builtins.len_(dataset)
