import tensorflow as tf
import numpy as np

tf.constant(42.0).__index__()
np.array(42.0).__index__()
