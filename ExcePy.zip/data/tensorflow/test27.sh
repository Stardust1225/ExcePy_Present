#!/bin/bash
cd tensorflow
git reset --hard 753d1e1a6acb7133b51f95c88a416f92ce1149f4
sudo pip3 install tensorflow==2.2.0
cd ..
python3 test27.py
#test-Traceback
#  File "test27.py", line 5, in <module>
#    t = py_builtins.len_(dataset)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/autograph/operators/py_builtins.py", line 233, in len_
#    return _py_len(s)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/autograph/operators/py_builtins.py", line 278, in _py_len
#    return len(s)
#TypeError: object of type 'TensorSliceDataset' has no len()
