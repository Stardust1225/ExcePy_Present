from tensorflow import variable_scope
from tensorflow.python.eager import context


def _testPartitionConcatenatesAlongCorrectAxis(use_resource):
    def _part_axis_0(**unused_kwargs):
        return (2, 1, 1)

    def _part_axis_1(**unused_kwargs):
        return (1, 2, 1)

    with variable_scope.variable_scope("root", use_resource=use_resource):
        v0 = variable_scope.get_variable(
            "n0", shape=(2, 2, 2), partitioner=_part_axis_0)
        v1 = variable_scope.get_variable(
            "n1", shape=(2, 2, 2), partitioner=_part_axis_1)

with context.eager_mode():
    _testPartitionConcatenatesAlongCorrectAxis(use_resource=True)
