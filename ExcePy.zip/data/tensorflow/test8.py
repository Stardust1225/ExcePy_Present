import tensorflow as tf
from tensorflow.python import debug as tf_debug

with tf.train.MonitoredSession() as sess:
  sess = tf_debug.LocalCLIDebugWrapperSession(sess)
del sess
