import tensorflow as tf

tf.keras.backend.set_floatx('float64')
inputs = tf.keras.layers.Input(shape=(28, 28, 1))
x = tf.keras.layers.Conv2D(filters=32, kernel_size=3, strides=2, padding='same')(inputs)
x = tf.keras.layers.LeakyReLU(0.2)(x)
x = tf.keras.layers.Conv2D(filters=64, kernel_size=3, strides=2, padding='same')(x)
x = tf.keras.layers.BatchNormalization()(x)
