import tensorflow as tf
sample_string = tf.sparse.SparseTensor(indices=[[0, 0], [1, 2]], values=['a', 'b'], dense_shape=[3, 4])
tf.sparse.to_dense( sample_string )
