#!/bin/bash
cd tensorflow
git reset --hard 5da215da086da25561afb6059ad52ac8c1cc7e98
sudo pip3 install tensorflow==2.2.0
cd ..
python3 test26.py
#test-Traceback
#  File "test26.py", line 5, in <module>
#    b = tf.sparse.from_dense(a)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/sparse_ops.py", line 121, in from_dense
#    math_ops.not_equal(tensor, array_ops.constant(0, tensor.dtype)))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 262, in constant
#    allow_broadcast=True)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 270, in _constant_impl
#    t = convert_to_eager_tensor(value, ctx, dtype)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 96, in convert_to_eager_tensor
#    return ops.EagerTensor(value, ctx.device_name, dtype)
#TypeError: Cannot convert 0 to EagerTensor of dtype string
