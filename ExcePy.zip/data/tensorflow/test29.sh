#!/bin/bash
cd tensorflow
git reset --hard 1015e48633745f76e888618bfcf3b3dba8a99b0e
sudo pip3 install tensorflow==2.0.0
cd ..
python3 test29.py
#test-Traceback
#  File "test29.py", line 3, in <module>
#    tf.one_hot(indices=[0, 1, 2], depth=3, on_value=1., off_value=0., dtype=tf.float16)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow_core/python/ops/array_ops.py", line 3489, in one_hot
#    "dtype parameter {1}".format(on_dtype, dtype))
#TypeError: dtype <dtype: 'float32'> of on_value does not match dtype parameter <dtype: 'float16'>
