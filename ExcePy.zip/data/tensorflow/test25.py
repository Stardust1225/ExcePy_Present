from tensorflow.python.framework import dtypes as dtypes_lib
from tensorflow.python.ops import array_ops, math_ops
from tensorflow.python.eager import def_function


@def_function.function(autograph=False)
def f():
    return math_ops.cast(
        array_ops.ones([2, 3], dtype=dtypes_lib.quint8), dtypes_lib.int32)


f()
