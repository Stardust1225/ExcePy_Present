#!/bin/bash
wget https://raw.githubusercontent.com/vogon101/skincancer/master/models/model_6_combined_2_DA.h5
cd tensorflow
git reset --hard aa59c42debb5146da4f9192321c92fe06eaec35d
sudo pip3 install tensorflow==2.3.1
cd ..
python3 test21.py
#test-Traceback
#  File "test21.py", line 2, in <module>
#    model = load_model("model_6_combined_2_DA.h5")
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/saving/save.py", line 182, in load_model
#    return hdf5_format.load_model_from_hdf5(filepath, custom_objects, compile)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/saving/hdf5_format.py", line 178, in load_model_from_hdf5
#    custom_objects=custom_objects)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/saving/model_config.py", line 55, in model_from_config
#    return deserialize(config, custom_objects=custom_objects)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/layers/serialization.py", line 175, in deserialize
#    printable_module_name='layer')
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/utils/generic_utils.py", line 358, in deserialize_keras_object
#    list(custom_objects.items())))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/training.py", line 2239, in from_config
#    config, custom_objects=custom_objects)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/functional.py", line 617, in from_config
#    config, custom_objects)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/functional.py", line 1204, in reconstruct_from_config
#    process_layer(layer_data)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/functional.py", line 1189, in process_layer
#    node_count_by_layer[layer] = int(_should_skip_first_node(layer))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/functional.py", line 1033, in _should_skip_first_node
#    isinstance(layer._layers[0], input_layer_module.InputLayer))
#IndexError: list index out of range
