#!/bin/bash
cd tensorflow
git reset --hard eed165e3d59903ff844cd682b8be4bffc23b9005
sudo pip3 install tensorflow==1.14.0
cd ..
python3 test13.py
#test-Traceback
#  File "test13.py", line 2, in <module>
#    tf.boolean_mask([1, 2, 3], [True, False, True], axis=tf.constant(0, dtype=tf.int32))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/array_ops.py", line 1371, in boolean_mask
#    shape_tensor[axis:axis + ndims_mask].assert_is_compatible_with(shape_mask)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/tensor_shape.py", line 863, in __getitem__
#    return TensorShape(self._dims[key])
#TypeError: slice indices must be integers or None or have an __index__ method
