#!/bin/bash
cd tensorflow
git reset --hard 70ade1b64f65d0a2275672d27129627ff116a997
sudo pip3 install tensorflow==0.12.1
cd ..
python3 test9.py
#test-Traceback
#  File "test9.py", line 3, in <module>
#    tf.train.shuffle_batch([raw], batch_size=2, capacity=4, min_after_dequeue=4, seed=5)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/training/input.py", line 906, in shuffle_batch
#    (1. / (capacity - min_after_dequeue)))
#ZeroDivisionError: float division by zero
