#!/bin/bash
cd tensorflow
git reset --hard 2b681a72d1e785b3d3cbdc9f3f4fded627665f40
sudo pip3 install tensorflow==1.14.0
cd ..
python3 test16.py
#test-Traceback
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/op_def_library.py", line 527, in _apply_op_helper
#    preferred_dtype=default_dtype)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/ops.py", line 1224, in internal_convert_to_tensor
#    ret = conversion_func(value, dtype=dtype, name=name, as_ref=as_ref)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 305, in _constant_tensor_conversion_function
#    return constant(v, dtype=dtype, name=name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 246, in constant
#    allow_broadcast=True)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 284, in _constant_impl
#    allow_broadcast=allow_broadcast))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/tensor_util.py", line 466, in make_tensor_proto
#    _AssertCompatible(values, dtype)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/tensor_util.py", line 371, in _AssertCompatible
#    (dtype.name, repr(mismatch), type(mismatch).__name__))
#TypeError: Expected string, got 0 of type 'int' instead.
