from tensorflow.python.framework import tensor_util, dtypes

dtype = dtypes.uint64
t = tensor_util.make_tensor_proto(10, dtype=dtype)
a = tensor_util.MakeNdarray(t)
