import numpy as np
from tensorflow.python.framework import tensor_util
from tensorflow.python.framework import dtypes

dtype = dtypes.uint32
nptype = np.uint32
np.array([[10, 11, 12, 12], [12, 12, 12, 12], [12, 12, 12, 12]],
         dtype=nptype),
tensor_util.MakeNdarray(
    tensor_util.make_tensor_proto([10, 11, 12],
                                  shape=[3, 4],
                                  dtype=dtype))
