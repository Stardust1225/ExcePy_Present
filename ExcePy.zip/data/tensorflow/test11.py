import tensorflow as tf
tf.range(tf.constant(102), dtype=tf.float32)
