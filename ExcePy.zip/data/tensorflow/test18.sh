#!/bin/bash
cd tensorflow
git reset --hard 2ec7666f428cb588d783b8b6da2862a16b4aa713
sudo pip3 install tensorflow==1.12.0 keras==2.2.4
cd ..
python3 test18.py
#test-Traceback
#  File "test18.py", line 16, in <module>
#    run_eagerly=testing_utils.should_run_eagerly())
#AttributeError: module 'tensorflow.python.keras.testing_utils' has no attribute 'should_run_eagerly'
