import tensorflow as tf
x = tf.get_variable(shape = [4, 4],
                    initializer=tf.keras.initializers.glorot_uniform(),
                    regularizer=tf.keras.regularizers.l2(0.),
                    name="v")
