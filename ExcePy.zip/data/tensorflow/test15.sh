#!/bin/bash
cd tensorflow
git reset --hard 10396ff82a9216a3ce5c5770eefa85bc0a973d38
sudo pip3 install tensorflow==2.0.0b1
sudo pip3 install pandas
cd ..
python3 test15.py
#test-Traceback
#  File "test15.py", line 5, in <module>
#    net = tf.keras.layers.BatchNormalization(virtual_batch_size=8)(inp)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/base_layer.py", line 662, in __call__
#    outputs = call_fn(inputs, *args, **kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/layers/normalization.py", line 644, in call
#    inputs = array_ops.reshape(inputs, expanded_shape)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/gen_array_ops.py", line 7715, in reshape
#    "Reshape", tensor=tensor, shape=shape, name=name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/op_def_library.py", line 530, in _apply_op_helper
#    raise err
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/op_def_library.py", line 527, in _apply_op_helper
#    preferred_dtype=default_dtype)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/ops.py", line 1237, in internal_convert_to_tensor
#    ret = conversion_func(value, dtype=dtype, name=name, as_ref=as_ref)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 305, in _constant_tensor_conversion_function
#    return constant(v, dtype=dtype, name=name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 246, in constant
#    allow_broadcast=True)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 284, in _constant_impl
#    allow_broadcast=allow_broadcast))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/tensor_util.py", line 563, in make_tensor_proto
#    "supported type." % (type(values), values))
#TypeError: Failed to convert object of type <class 'list'> to Tensor. Contents: [8, -1, None, None, 3]. Consider casting elements to a supported type.
