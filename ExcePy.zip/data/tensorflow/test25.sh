#!/bin/bash
cd tensorflow
git reset --hard 0f3763e26dea978bf51c8e5170f2dbe03a973d3c
sudo pip3 install tensorflow==2.3.0rc0
cd ..
python3 test25.py
#test-Traceback
#  File "test25.py", line 12, in <module>
#    f()
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/def_function.py", line 780, in __call__
#    result = self._call(*args, **kwds)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/def_function.py", line 823, in _call
#    self._initialize(args, kwds, add_initializers_to=initializers)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/def_function.py", line 697, in _initialize
#    *args, **kwds))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/function.py", line 2855, in _get_concrete_function_internal_garbage_collected
#    graph_function, _, _ = self._maybe_define_function(args, kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/function.py", line 3213, in _maybe_define_function
#    graph_function = self._create_graph_function(args, kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/function.py", line 3075, in _create_graph_function
#    capture_by_value=self._capture_by_value),
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/func_graph.py", line 986, in func_graph_from_py_func
#    func_outputs = python_func(*func_args, **func_kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/def_function.py", line 600, in wrapped_fn
#    return weak_wrapped_fn().__wrapped__(*args, **kwds)
#  File "test25.py", line 9, in f
#    array_ops.ones([2, 3], dtype=dtypes_lib.quint8), dtypes_lib.int32)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/util/dispatch.py", line 201, in wrapper
#    return target(*args, **kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/array_ops.py", line 3053, in ones
#    output = fill(shape, constant(one, dtype=dtype), name=name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 264, in constant
#    allow_broadcast=True)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/constant_op.py", line 282, in _constant_impl
#    allow_broadcast=allow_broadcast))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/tensor_util.py", line 456, in make_tensor_proto
#    _AssertCompatible(values, dtype)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/tensor_util.py", line 336, in _AssertCompatible
#    (dtype.name, repr(mismatch), type(mismatch).__name__))
#TypeError: Expected quint8, got 1 of type 'int' instead.
