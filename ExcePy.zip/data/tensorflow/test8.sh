#!/bin/bash
cd tensorflow
git reset --hard cdc36a3b1f7d227984bb5e415b555ed334737f82
sudo pip3 install tensorflow==1.4.0
cd ..
python3 test8.py
#test-Traceback
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/debug/wrappers/framework.py", line 705, in __del__
#    self._sess.__del__()
#AttributeError: 'MonitoredSession' object has no attribute '__del__'
