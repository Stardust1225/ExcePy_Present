#!/bin/bash
cd tensorflow
git reset --hard c0219bdebd43dc5b18d6f6034efa57c336208c10
sudo pip3 install tensorflow==2.0.0rc2
cd ..
python3 test17.py
#test-Traceback
#  File "test17.py", line 5, in <module>
#    [5], alpha=np.ones([2, 1, 3]), beta=np.ones([3]), dtype=np.float32)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow_core/python/ops/random_ops.py", line 492, in random_gamma
#    np.finfo(dtype.as_numpy_dtype).tiny,
#AttributeError: type object 'numpy.float32' has no attribute 'as_numpy_dtype'
