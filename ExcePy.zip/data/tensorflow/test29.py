import tensorflow as tf

tf.one_hot(indices=[0, 1, 2], depth=3, on_value=1., off_value=0., dtype=tf.float16)
