#!/bin/bash
cd tensorflow
git reset --hard ac4717707dc3c9d1441ffe85d6563e868f9677e3
sudo pip3 install tensorflow==1.7.1
cd ..
python3 test12.py
#test-Traceback
#  File "test12.py", line 35, in <module>
#    outputs_2, _ = lstm(inputs_2)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/layers/base.py", line 696, in __call__
#    self.build(input_shapes)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/contrib/cudnn_rnn/python/layers/cudnn_rnn.py", line 358, in build
#    "opaque_kernel", initializer=opaque_params_t, validate_shape=False)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/variable_scope.py", line 1297, in get_variable
#    constraint=constraint)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/variable_scope.py", line 1093, in get_variable
#    constraint=constraint)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/variable_scope.py", line 431, in get_variable
#    return custom_getter(**custom_getter_kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/contrib/cudnn_rnn/python/layers/cudnn_rnn.py", line 291, in _update_trainable_weights
#    variable = getter(*args, **kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/variable_scope.py", line 408, in _true_getter
#    use_resource=use_resource, constraint=constraint)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/variable_scope.py", line 758, in _get_single_variable
#    found_type_str))
#ValueError: Trying to share variable cudnn_rnn/cudnn_bi_lstm/opaque_kernel, but specified dtype float32 and found dtype float16_ref.
