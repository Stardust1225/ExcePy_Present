import tensorflow as tf

with tf.train.MonitoredTrainingSession() as sess:
    sess.close()
