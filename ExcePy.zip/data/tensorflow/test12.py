import tensorflow as tf

num_layers = 1
num_units = 40
batch_size = 60
dir_count = 2

inputDType = tf.float16  # Does not work
# inputDType = tf.float32 # Works

inputs_1 = tf.random_uniform([
    num_layers * dir_count, batch_size, num_units], dtype=inputDType)

inputs_2 = tf.random_uniform([
    num_layers * dir_count, batch_size, num_units], dtype=inputDType)

with tf.variable_scope("cudnn_rnn", reuse=False):
    lstm = tf.contrib.cudnn_rnn.CudnnLSTM(
        num_layers=num_layers,
        num_units=num_units,
        direction="bidirectional",
        dtype=inputDType,
        name="cudnn_bi_lstm")

    outputs_1, _ = lstm(inputs_1)

with tf.variable_scope("cudnn_rnn", reuse=True):
    lstm = tf.contrib.cudnn_rnn.CudnnLSTM(
        num_layers=num_layers,
        num_units=num_units,
        direction="bidirectional",
        dtype=inputDType,
        name="cudnn_bi_lstm")

    outputs_2, _ = lstm(inputs_2)

loss1 = tf.reduce_sum(outputs_1)
loss2 = tf.reduce_sum(outputs_2)
loss = loss1 + loss2
var = lstm.trainable_variables[0]

grad = tf.gradients(loss, var)[0]
print('grad.shape: %s' % grad.shape)
print('var.shape: %s' % var.shape)

opt = tf.train.AdamOptimizer()
train_op = opt.apply_gradients([(grad, lstm.trainable_variables[0])])

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    print(sess.run(outputs_1))
    print(sess.run(outputs_2))
    sess.run(train_op)
    print(sess.run(outputs_1))
    print(sess.run(outputs_2))
