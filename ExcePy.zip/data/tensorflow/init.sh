#!/bin/bash
apt-get install -y python3-dev python-dev git
python3 -m pip install --upgrade pip
git clone https://github.com/tensorflow/tensorflow.git
