#!/bin/bash
cd tensorflow
git reset --hard 35c2a97ddca6da7d5a21d5ee3e2869eec68299f9
sudo pip3 install tensorflow==2.4.0rc3
cd ..
python3 test32.py
#test-Traceback
#  File "test32.py", line 4, in <module>
#    tf.nest.flatten(structure=np.zeros((1)), expand_composites=tf.ones((2)))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/util/nest.py", line 340, in flatten
#    expand_composites = bool(expand_composites)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/ops.py", line 992, in __bool__
#    return bool(self._numpy())
#ValueError: The truth value of an array with more than one element is ambiguous. Use a.any() or a.all()
