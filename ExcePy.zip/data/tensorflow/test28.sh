#!/bin/bash
cd tensorflow
git reset --hard 2ebc291f6a94163c49fc835d3afc93892e645e45
sudo pip3 install tensorflow==2.1.3
cd ..
python3 test28.py
#test-Traceback
#  File "test28.py", line 8, in <module>
#    x = tf.keras.layers.BatchNormalization()(x)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/base_layer.py", line 922, in __call__
#    outputs = call_fn(cast_inputs, *args, **kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/layers/normalization.py", line 741, in call
#    outputs = self._fused_batch_norm(inputs, training=training)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/layers/normalization.py", line 604, in _fused_batch_norm
#    _fused_batch_norm_inference)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/utils/tf_utils.py", line 65, in smart_cond
#    pred, true_fn=true_fn, false_fn=false_fn, name=name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/smart_cond.py", line 59, in smart_cond
#    name=name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/util/deprecation.py", line 507, in new_func
#    return func(*args, **kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/control_flow_ops.py", line 1177, in cond
#    return cond_v2.cond_v2(pred, true_fn, false_fn, name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/cond_v2.py", line 84, in cond_v2
#    op_return_value=pred)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/func_graph.py", line 981, in func_graph_from_py_func
#    func_outputs = python_func(*func_args, **func_kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/layers/normalization.py", line 579, in _fused_batch_norm_training
#    exponential_avg_factor=exponential_avg_factor)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/nn_impl.py", line 1544, in fused_batch_norm
#    name=name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/gen_nn_ops.py", line 4279, in fused_batch_norm_v3
#    name=name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/op_def_library.py", line 578, in _apply_op_helper
#    param_name=input_name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/op_def_library.py", line 61, in _SatisfiesTypeConstraint
#    ", ".join(dtypes.as_dtype(x).name for x in allowed_list)))
#TypeError: Value passed to parameter 'x' has DataType float64 not in list of allowed values: float16, bfloat16, float32
