#!/bin/bash
cd tensorflow
git reset --hard eb1fde6216a1fa3b66330ecf07e7b206a2e84df4
sudo pip3 install tensorflow==2.0.0a0
cd ..
python3 test5.py
#test-Traceback
#  File "test4.py", line 2, in <module>
#    tf.math.real(1.)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/util/dispatch.py", line 180, in wrapper
#    return target(*args, **kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/math_ops.py", line 522, in real
#    if input.dtype.is_complex:
#AttributeError: 'float' object has no attribute 'dtype'
