#!/bin/bash
cd tensorflow
git reset --hard edf5029353c452a5599dd02e95adee5657cd5599
sudo pip3 install tensorflow==2.2.0
sudo pip3 install pandas
sudo pip3 install sklearn
cd ..
python3 test14.py
#test-Traceback
#  File "test14.py", line 87, in <module>
#    main()
#  File "test14.py", line 76, in main
#    train_step(x, y)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/def_function.py", line 580, in __call__
#    result = self._call(*args, **kwds)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/def_function.py", line 627, in _call
#    self._initialize(args, kwds, add_initializers_to=initializers)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/def_function.py", line 506, in _initialize
#    *args, **kwds))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/function.py", line 2446, in _get_concrete_function_internal_garbage_collected
#    graph_function, _, _ = self._maybe_define_function(args, kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/function.py", line 2777, in _maybe_define_function
#    graph_function = self._create_graph_function(args, kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/function.py", line 2667, in _create_graph_function
#    capture_by_value=self._capture_by_value),
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/func_graph.py", line 981, in func_graph_from_py_func
#    func_outputs = python_func(*func_args, **func_kwargs)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/eager/def_function.py", line 441, in wrapped_fn
#    return weak_wrapped_fn().__wrapped__(*args, **kwds)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/func_graph.py", line 968, in wrapper
#    raise e.ag_error_metadata.to_exception(e)
#TypeError: in user code:
