#!/bin/bash
cd tensorflow
git reset --hard 9770648bd385639feeaebfbb9b38fb6da9d50914
sudo pip3 install tensorflow==2.0.0b1
cd ..
python3 test11.py
#test-Traceback
#  File "test11.py", line 2, in <module>
#    tf.range(tf.constant(102), dtype=tf.float32)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/math_ops.py", line 1305, in range
#    limit = ops.convert_to_tensor(limit, dtype=dtype, name="limit")
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/ops.py", line 1100, in convert_to_tensor
#    return convert_to_tensor_v2(value, dtype, preferred_dtype, name)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/ops.py", line 1158, in convert_to_tensor_v2
#    as_ref=False)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/ops.py", line 1180, in internal_convert_to_tensor
#    value = _TensorTensorConversionFunction(value, dtype=dtype)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/framework/ops.py", line 1036, in _TensorTensorConversionFunction
#    (dtype.name, t.dtype.name, str(t)))
#ValueError: Tensor conversion requested dtype float32 for Tensor with dtype int32: 'tf.Tensor(102, shape=(), dtype=int32)'
