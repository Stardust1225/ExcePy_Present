import tensorflow as tf
import numpy as np

tf.nest.flatten(structure=np.zeros((1)), expand_composites=tf.ones((2)))
