import keras
from tensorflow.python.keras import testing_utils
from tensorflow.python.ops import math_ops
from tensorflow.python.training.adam import AdamOptimizer
import numpy as np


class TestModel(keras.models.Model):
    def call(self, inputs, training=None, mask=None):
        return math_ops.to_float(inputs['id'])


model = TestModel()
model.compile(
    optimizer=AdamOptimizer(), loss='mean_squared_error', metrics=['mse'],
    run_eagerly=testing_utils.should_run_eagerly())
x = {'id': np.array([[3], [1]])}
y = np.array([[4], [2]])
val_dataset = (x, y)
history = model.fit(
    x,
    y,
    batch_size=32,
    steps_per_epoch=2,
    validation_data=val_dataset,
    validation_steps=2)
model.evaluate(x, y)
model.predict([7])
