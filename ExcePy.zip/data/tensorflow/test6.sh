#!/bin/bash
cd tensorflow
git reset --hard ab80014d88857d143238071e58b0c81e708431f0
sudo pip3 install tensorflow==2.4.0rc3
cd ..
python3 test6.py
#test-Traceback
#  File "test6.py", line 12, in <module>
#    model.fit(tf.random.uniform(shape=(1024, 32)), tf.random.uniform(shape=(1024, 5)))
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/training.py", line 1064, in fit
#    steps_per_execution=self._steps_per_execution)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/data_adapter.py", line 1099, in __init__
#    adapter_cls = select_data_adapter(x, y)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/data_adapter.py", line 958, in select_data_adapter
#    adapter_cls = [cls for cls in ALL_ADAPTER_CLS if cls.can_handle(x, y)]
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/data_adapter.py", line 958, in <listcomp>
#    adapter_cls = [cls for cls in ALL_ADAPTER_CLS if cls.can_handle(x, y)]
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/data_adapter.py", line 543, in can_handle
#    return (any(_is_composite(v) for v in flat_inputs) and
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/data_adapter.py", line 543, in <genexpr>
#    return (any(_is_composite(v) for v in flat_inputs) and
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/data_adapter.py", line 534, in _is_composite
#    if scipy_sparse is not None and scipy_sparse.issparse(v):
#AttributeError: module 'scipy.sparse' has no attribute 'issparse'
