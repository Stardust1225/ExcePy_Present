from tensorflow.python.ops import random_ops
import numpy as np

random_ops.random_gamma(
    [5], alpha=np.ones([2, 1, 3]), beta=np.ones([3]), dtype=np.float32)
