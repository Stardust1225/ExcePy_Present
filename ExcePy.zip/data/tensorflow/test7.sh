#!/bin/bash
cd tensorflow
git reset --hard c475edf9513d6bceae992775869fb9dd0b2c848a
pip3 install tensorflow==1.10.1
cd ..
python3 test7.py
#test-Traceback
#  File "test7.py", line 5, in <module>
#    name="v")
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/variable_scope.py", line 1467, in get_variable
#    aggregation=aggregation)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/variable_scope.py", line 1217, in get_variable
#    aggregation=aggregation)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/variable_scope.py", line 527, in get_variable
#    aggregation=aggregation)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/variable_scope.py", line 481, in _true_getter
#    aggregation=aggregation)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/variable_scope.py", line 930, in _get_single_variable
#    loss_name = loss.name
#AttributeError: 'float' object has no attribute 'name'
