#!/bin/bash
cd tensorflow
git reset --hard 9e6183e4acbb1b795069947faf778a47709d2029
sudo pip3 install tensorflow==1.3.0rc2
cd ..
python3 test20.py
#test-Traceback
#  File "test20.py", line 4, in <module>
#    sess.close()
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/training/monitored_session.py", line 534, in __exit__
#    self._close_internal(exception_type)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/training/monitored_session.py", line 569, in _close_internal
#    self._sess.close()
#AttributeError: 'NoneType' object has no attribute 'close'
