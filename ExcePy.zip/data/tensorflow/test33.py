from tensorflow import Session
from tensorflow.python.framework import dtypes
from tensorflow.python.ops import array_ops

with Session() as sess:
    foo = array_ops.sparse_placeholder(dtypes.float32, shape=(10, 47))
    foo.get_shape()

    foo = array_ops.sparse_placeholder(dtypes.float32, shape=(None, 47))
    foo.get_shape()
