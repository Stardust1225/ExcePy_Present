#!/bin/bash
cd tensorflow
git reset --hard a7f51164e664198d4e37563b33df34ef66e8f826
sudo pip3 install tensorflow==1.12.0
cd ..
python3 test19.py
#test-Traceback
#  File "test19.py", line 19, in <module>
#    _testPartitionConcatenatesAlongCorrectAxis(use_resource=True)
#  File "test19.py", line 12, in _testPartitionConcatenatesAlongCorrectAxis
#    with variable_scope.variable_scope("root", use_resource=use_resource):
#AttributeError: type object 'variable_scope' has no attribute 'variable_scope'
