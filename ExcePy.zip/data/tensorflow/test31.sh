#!/bin/bash
cd tensorflow
git reset --hard bb2e09ad7207c504296962192fa5f1b7ec53a659
sudo pip3 install tensorflow==2.4.0rc3
cd ..
python3 test31.py
#test-Traceback
#  File "test31.py", line 14, in <module>
#    model.summary()
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/training.py", line 2384, in summary
#    print_fn=print_fn)
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/utils/layer_utils.py", line 252, in print_summary
#    print_layer_summary(layers[i])
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/utils/layer_utils.py", line 210, in print_layer_summary
#    fields = [name + ' (' + cls_name + ')', output_shape, layer.count_params()]
#  File "/usr/local/lib/python3.6/dist-packages/tensorflow/python/keras/engine/base_layer.py", line 2208, in count_params
#    '.build(batch_input_shape)`.')
#ValueError: You tried to call `count_params` on concatenate, but the layer isn't built. You can build it manually via: `concatenate.build(batch_input_shape)`.
