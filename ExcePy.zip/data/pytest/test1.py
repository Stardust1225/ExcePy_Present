import pytest

def f():
    return

assert f() == 10

