#!/bin/bash 
cd pytest
git clean -xdf
git reset --hard 8c96b65082b469b3bc8f1c6f8618924b002b22df
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test2.py
#test-Traceback
#Traceback (most recent call last):
#  File "test2.py", line 3, in <module>
#    import pytest
#  File "./pytest/src/pytest.py", line 8, in <module>
#    from _pytest.config import cmdline
#  File "./pytest/src/_pytest/config/__init__.py", line 23, in <module>
#    import _pytest.hookspec  # the extension point definitions
#  File "./pytest/src/_pytest/hookspec.py", line 503, in <module>
#    @hookspec(historic=True, warn_on_impl=PYTEST_LOGWARNING)
#TypeError: __call__() got an unexpected keyword argument 'warn_on_impl'
#test-errorfilepath
#./pytest/src/_pytest/hookspec.py
