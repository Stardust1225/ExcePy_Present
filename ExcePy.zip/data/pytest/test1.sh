#!/bin/bash 
cd pytest
git clean -xdf
git reset --hard 65be1231b12367de3ff14b5718125d12a54b26b1
git reset --hard HEAD^
pip3 install -e .
cd ..
pytest test1.py
#test-Traceback
#pytest/_pytest/python.py:209: in fget
#    return self._obj
#E   AttributeError: 'Module' object has no attribute '_obj'
#test-errorfilepath
#./pytest/_pytest/python.py
