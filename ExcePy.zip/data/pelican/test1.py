import os

from pelican import readers
from pelican.tests.support import get_settings


reader = readers.MarkdownReader(settings=get_settings())
content, metadata = reader.read(os.path.join('test1.md'))
