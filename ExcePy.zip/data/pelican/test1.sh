#!/bin/bash
cd pelican
git clean -xdf
git reset --hard 5d860471ac6e14b4ada641eb1c3a5b7c4f3f3940
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test1.py
#test-Traceback
#  File "test1.py", line 8, in <module>
#    content, metadata = reader.read(os.path.join('empty.md'))
#  File "./pelican/pelican/readers.py", line 288, in read
#    with pelican_open(source_path) as text:
#  File "/usr/lib/python3.6/contextlib.py", line 81, in __enter__
#    return next(self.gen)
#  File "./pelican/pelican/utils.py", line 247, in pelican_open
#    if content[0] == codecs.BOM_UTF8.decode('utf8'):
#IndexError: string index out of range
#test-errorfilepath
#./pelican/pelican/utils.py

