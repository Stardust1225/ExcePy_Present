#!/bin/bash
cd matplotlib
git clean -xdf
git reset --hard e574613a519bb5cbcf31783f7efe750951b464ba
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test10.py
#test-Traceback
#  File "test10.py", line 14, in <module>
#    plt.tight_layout(rect=[0, 0.08, 1, 0.92])
#  File "./matplotlib/lib/matplotlib/pyplot.py", line 1366, in tight_layout
#    fig.tight_layout(pad=pad, h_pad=h_pad, w_pad=w_pad, rect=rect)
#  File "./matplotlib/lib/matplotlib/figure.py", line 2269, in tight_layout
#    kwargs = get_tight_layout_figure(
#  File "./matplotlib/lib/matplotlib/tight_layout.py", line 323, in get_tight_layout_figure
#    kwargs = auto_adjust_subplotpars(fig, renderer,
#  File "./matplotlib/lib/matplotlib/tight_layout.py", line 114, in auto_adjust_subplotpars
#    tight_bbox_raw = union([ax.get_tightbbox(renderer) for ax in subplots
#  File "./matplotlib/lib/matplotlib/tight_layout.py", line 114, in <listcomp>
#    tight_bbox_raw = union([ax.get_tightbbox(renderer) for ax in subplots
#  File "./matplotlib/lib/matplotlib/axes/_base.py", line 4185, in get_tightbbox
#    bb.append(child._legend_box.get_window_extent(renderer))
#  File "./matplotlib/lib/matplotlib/offsetbox.py", line 262, in get_window_extent
#    w, h, xd, yd, offsets = self.get_extent_offsets(renderer)
#  File "./matplotlib/lib/matplotlib/offsetbox.py", line 381, in get_extent_offsets
#    whd_list = [c.get_extent(renderer)
#  File "./matplotlib/lib/matplotlib/offsetbox.py", line 381, in <listcomp>
#    whd_list = [c.get_extent(renderer)
#  File "./matplotlib/lib/matplotlib/offsetbox.py", line 255, in get_extent
#    w, h, xd, yd, offsets = self.get_extent_offsets(renderer)
#  File "./matplotlib/lib/matplotlib/offsetbox.py", line 478, in get_extent_offsets
#    return width + 2 * pad, height + 2 * pad, \
#TypeError: unsupported operand type(s) for +: 'NoneType' and 'float'
#test-errorfilepath
#./matplotlib/lib/matplotlib/offsetbox.py
