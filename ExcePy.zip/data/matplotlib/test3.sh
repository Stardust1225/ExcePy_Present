#!/bin/bash
cd matplotlib
git clean -xdf
git reset --hard 980fbee43bc4a16f196e7d3e5efe9e3798c24259
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test3.py
#test-Traceback
#  File "test3.py", line 6, in <module>
#    savefig("/tmp/test.svg")
#  File "./matplotlib/lib/matplotlib/pyplot.py", line 711, in savefig
#    res = fig.savefig(*args, **kwargs)
#  File "./matplotlib/lib/matplotlib/figure.py", line 1864, in savefig
#    self.canvas.print_figure(fname, **kwargs)
#  File "./matplotlib/lib/matplotlib/backend_bases.py", line 2268, in print_figure
#    **kwargs)
#  File "./matplotlib/lib/matplotlib/backends/backend_svg.py", line 1195, in print_svg
#    return self._print_svg(filename, svgwriter, **kwargs)
#  File "./matplotlib/lib/matplotlib/backends/backend_svg.py", line 1251, in _print_svg
#    renderer.finalize()
#  File "./matplotlib/lib/matplotlib/backends/backend_svg.py", line 304, in finalize
#    self._write_svgfonts()
#  File "./matplotlib/lib/matplotlib/backends/backend_svg.py", line 509, in _write_svgfonts
#    writer.start('font', id=sfnt[(1, 0, 0, 4)])
#  File "./matplotlib/lib/matplotlib/backends/backend_svg.py", line 156, in start
#    v = escape_attrib(v)
#  File "./matplotlib/lib/matplotlib/backends/backend_svg.py", line 89, in escape_attrib
#    s = s.replace("&", "&amp;")
#TypeError: a bytes-like object is required, not 'str'
#test-errorfilepath
#./matplotlib/lib/matplotlib/backends/backend_svg.py
