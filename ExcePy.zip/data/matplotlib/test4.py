import io

import matplotlib.pyplot as plt

plt.figtext(.5, .5, "foo", usetex=True)
plt.savefig(io.BytesIO(), format="ps")
