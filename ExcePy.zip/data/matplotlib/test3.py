from matplotlib import rcParams
from matplotlib.pyplot import title, savefig

rcParams["svg.fonttype"] = "svgfont"
title("foo")
savefig("/tmp/test.svg")
