#!/bin/bash
cd matplotlib
git clean -xdf
git reset --hard 6cb9d626d87f047b689e021ab3daac8332396974
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test4.py
#test-Traceback
#  File "test4.py", line 6, in <module>
#    plt.savefig(io.BytesIO(), format="ps")
#  File "./matplotlib/lib/matplotlib/pyplot.py", line 771, in savefig
#    res = fig.savefig(*args, **kwargs)
#  File "./matplotlib/lib/matplotlib/figure.py", line 2179, in savefig
#    self.canvas.print_figure(fname, **kwargs)
#  File "./matplotlib/lib/matplotlib/backend_bases.py", line 2103, in print_figure
#    result = print_method(
#  File "./matplotlib/lib/matplotlib/backends/backend_ps.py", line 759, in print_ps
#    return self._print_ps(outfile, 'ps', *args, **kwargs)
#  File "./matplotlib/lib/matplotlib/backends/backend_ps.py", line 799, in _print_ps
#    printer(outfile, format, dpi=dpi, dsc_comments=dsc_comments,
#  File "./matplotlib/lib/matplotlib/cbook/deprecation.py", line 387, in wrapper
#    return func(*inner_args, **inner_kwargs)
#  File "./matplotlib/lib/matplotlib/backends/backend_ps.py", line 869, in _print_figure
#    self.figure.draw(renderer)
#  File "./matplotlib/lib/matplotlib/artist.py", line 41, in draw_wrapper
#    return draw(artist, renderer, *args, **kwargs)
#  File "./matplotlib/lib/matplotlib/figure.py", line 1736, in draw
#    mimage._draw_list_compositing_images(
#  File "./matplotlib/lib/matplotlib/image.py", line 132, in _draw_list_compositing_images
#    a.draw(renderer)
#  File "./matplotlib/lib/matplotlib/artist.py", line 41, in draw_wrapper
#    return draw(artist, renderer, *args, **kwargs)
#  File "./matplotlib/lib/matplotlib/text.py", line 727, in draw
#    textrenderer.draw_tex(gc, x, y, clean_line,
#  File "./matplotlib/lib/matplotlib/backends/backend_ps.py", line 475, in draw_tex
#    thetext = 'psmarker%d' % self.textcnt
#AttributeError: 'RendererPS' object has no attribute 'textcnt'
#test-errorfilepath
#./matplotlib/lib/matplotlib/backends/backend_ps.py
