#!/bin/bash
apt-get install -y libfreetype6-dev
apt-get install -y libpng-dev
cd matplotlib
git clean -xdf
git reset --hard 014c02b99d40f399ed9852474032e52ea2eae218
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test1.py
#test-Traceback
#  File "test1.py", line 5, in <module>
#    print(im)
#  File "./matplotlib/lib/matplotlib/image.py", line 181, in __str__
#    return "AxesImage(%g,%g;%gx%g)" % tuple(self.axes.bbox.bounds)
#AttributeError: 'NoneType' object has no attribute 'bbox'
#test-errorfilepath
#./matplotlib/lib/matplotlib/image.py
