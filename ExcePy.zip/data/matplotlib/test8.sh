#!/bin/bash
cd matplotlib
git clean -xdf
git reset --hard fffe9f3e9c29bd1a71036254cd4c429f2c525c03
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test8.py
#test-Traceback
#  File "test8.py", line 4, in <module>
#    repr(ss)
#  File "./matplotlib/lib/matplotlib/gridspec.py", line 51, in __repr__
#    height_arg = (', height_ratios=%r' % self._row_height_ratios
#TypeError: not all arguments converted during string formatting
#test-errorfilepath
#./matplotlib/lib/matplotlib/gridspec.py
