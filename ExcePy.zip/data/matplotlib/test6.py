import matplotlib.pyplot as plt

plt.bar([], [], label='test')
plt.legend()
