#!/bin/bash
apt-get install -y git python3-dev python-dev
apt-get install -y libgirepository1.0-dev gcc libcairo2-dev pkg-config python3-dev gir1.2-gtk-3.0
pip3 install pycairo PyGObject
git clone https://github.com/matplotlib/matplotlib.git
