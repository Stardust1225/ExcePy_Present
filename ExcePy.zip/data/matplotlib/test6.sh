#!/bin/bash
cd matplotlib
git clean -xdf
git reset --hard a06ed93fdba30351b4f8edc96141e6205b574639
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test6.py
#test-Traceback
#  File "test6.py", line 4, in <module>
#    plt.legend()
#  File "./matplotlib/lib/matplotlib/pyplot.py", line 2670, in legend
#    return gca().legend(*args, **kwargs)
#  File "./matplotlib/lib/matplotlib/axes/_axes.py", line 382, in legend
#    self.legend_ = mlegend.Legend(self, handles, labels, **kwargs)
#  File "./matplotlib/lib/matplotlib/legend.py", line 575, in __init__
#    self._init_legend_box(handles, labels, markerfirst)
#  File "./matplotlib/lib/matplotlib/legend.py", line 836, in _init_legend_box
#    handle_list.append(handler.legend_artist(self, orig_handle,
#  File "./matplotlib/lib/matplotlib/legend_handler.py", line 113, in legend_artist
#    artists = self.create_artists(legend, orig_handle,
#  File "./matplotlib/lib/matplotlib/legend_handler.py", line 299, in create_artists
#    self.update_prop(p, orig_handle, legend)
#  File "./matplotlib/lib/matplotlib/legend_handler.py", line 72, in update_prop
#    self._update_prop(legend_handle, orig_handle)
#  File "./matplotlib/lib/matplotlib/legend_handler.py", line 65, in _update_prop
#    self._update_prop_func(legend_handle, orig_handle)
#  File "./matplotlib/lib/matplotlib/legend_handler.py", line 38, in update_from_first_child
#    tgt.update_from(src.get_children()[0])
#IndexError: list index out of range
#test-errorfilepath
#./matplotlib/lib/matplotlib/legend_handler.py
