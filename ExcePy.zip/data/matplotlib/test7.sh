#!/bin/bash
cd matplotlib
git clean -xdf
git reset --hard f964afdc35476af45db8a66af715b691226de19b
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test7.py
#test-Traceback
#  File "test7.py", line 5, in <module>
#    plt.plot([1, 2], ls="--")
#  File "./matplotlib/lib/matplotlib/pyplot.py", line 2680, in plot
#    return gca().plot(
#  File "./matplotlib/lib/matplotlib/axes/_axes.py", line 1743, in plot
#    lines = [*self._get_lines(*args, data=data, **kwargs)]
#  File "./matplotlib/lib/matplotlib/axes/_base.py", line 270, in __call__
#    yield from self._plot_args(this, kwargs)
#  File "./matplotlib/lib/matplotlib/axes/_base.py", line 415, in _plot_args
#    return [func(x[:, j % ncx], y[:, j % ncy], kw, kwargs)
#  File "./matplotlib/lib/matplotlib/axes/_base.py", line 415, in <listcomp>
#    return [func(x[:, j % ncx], y[:, j % ncy], kw, kwargs)
#  File "./matplotlib/lib/matplotlib/axes/_base.py", line 309, in _makeline
#    seg = mlines.Line2D(x, y, **kw)
#  File "./matplotlib/lib/matplotlib/lines.py", line 363, in __init__
#    self.set_linestyle(linestyle)
#  File "./matplotlib/lib/matplotlib/lines.py", line 1134, in set_linestyle
#    self._us_dashOffset, self._us_dashSeq = _get_dash_pattern(ls)
#  File "./matplotlib/lib/matplotlib/lines.py", line 60, in _get_dash_pattern
#    dsum = sum(dashes)
#TypeError: unsupported operand type(s) for +: 'float' and 'NoneType'
#test-errorfilepath
#./matplotlib/lib/matplotlib/lines.py
