from matplotlib.pyplot import scatter
import numpy as np

scatter(range(4), range(4), c=np.arange(4).reshape((2, 2)))
