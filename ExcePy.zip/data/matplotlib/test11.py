import matplotlib.pyplot as plt

_, ax = plt.subplots()
ax.arrow(0, 0, 0, 0, head_length=0)
