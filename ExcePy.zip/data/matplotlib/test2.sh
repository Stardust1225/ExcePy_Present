#!/bin/bash
cd matplotlib
git clean -xdf
git reset --hard 1aa5a83c16c1125bcba4bb9a27e987b587d8517d
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test2.py
#test-Traceback
#  File "test2.py", line 4, in <module>
#    scatter(range(4), range(4), c=np.arange(4).reshape((2, 2)))
#  File "./matplotlib/lib/matplotlib/pyplot.py", line 2826, in scatter
#    None else {}), **kwargs)
#  File "./matplotlib/lib/matplotlib/__init__.py", line 1512, in inner
#    return func(ax, *map(sanitize_sequence, args), **kwargs)
#  File "./matplotlib/lib/matplotlib/axes/_axes.py", line 4458, in scatter
#    get_next_color_func=self._get_patches_for_fill.get_next_color)
#  File "./matplotlib/lib/matplotlib/axes/_axes.py", line 4302, in _parse_scatter_color_args
#    .format(nc=n_elem, xs=xsize, ys=ysize)
#ValueError: 'c' argument has 2 elements, which is not acceptable for use with 'x' with size 4, 'y' with size 4.
#test-errorfilepath
#./matplotlib/lib/matplotlib/axes/_axes.py
