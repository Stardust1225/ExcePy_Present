import matplotlib.pyplot as plt
from matplotlib import rcParams

rcParams["lines.dashed_pattern"] = (1, None)
plt.plot([1, 2], ls="--")
