#!/bin/bash
cd matplotlib
git clean -xdf
git reset --hard 606e8e2f7b004efc5d0a726590035ef51ecb3e08
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test11.py
#test-Traceback
#  File "test11.py", line 4, in <module>
#    ax.arrow(0, 0, 0, 0, head_length=0)
#  File "./matplotlib/lib/matplotlib/axes/_axes.py", line 4978, in arrow
#    a = mpatches.FancyArrow(x, y, dx, dy, **kwargs)
#  File "./matplotlib/lib/matplotlib/patches.py", line 1313, in __init__
#    super().__init__(verts, closed=True, **kwargs)
#  File "./matplotlib/lib/matplotlib/patches.py", line 983, in __init__
#    self.set_xy(xy)
#  File "./matplotlib/lib/matplotlib/patches.py", line 1050, in set_xy
#    self._path = Path(xy, closed=self._closed)
#  File "./matplotlib/lib/matplotlib/path.py", line 129, in __init__
#    raise ValueError(
#ValueError: 'vertices' must be a 2D list or array with shape Nx2
#test-errorfilepath
#./matplotlib/lib/matplotlib/path.py
