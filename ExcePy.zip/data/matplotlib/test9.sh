#!/bin/bash
cd matplotlib
git clean -xdf
git reset --hard 35b875c8bbb993104f3c047118147d0d1b28a9a8
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test9.py
#test-Traceback
#  File "test9.py", line 7, in <module>
#    plt.bar(x, y)
#  File "./matplotlib/lib/matplotlib/pyplot.py", line 2417, in bar
#    return gca().bar(
#  File "./matplotlib/lib/matplotlib/__init__.py", line 1570, in inner
#    return func(ax, *map(sanitize_sequence, args), **kwargs)
#  File "./matplotlib/lib/matplotlib/axes/_axes.py", line 2385, in bar
#    raise TypeError(f'the dtypes of parameters x ({x.dtype}) '
#TypeError: the dtypes of parameters x (object) and width (float64) are incompatible
#test-errorfilepath
#./matplotlib/lib/matplotlib/axes/_axes.py
