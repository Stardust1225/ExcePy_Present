from matplotlib.pyplot import figimage
import numpy as np

im = figimage(np.random.rand(100, 100), xo=100, yo=100)
print(im)
