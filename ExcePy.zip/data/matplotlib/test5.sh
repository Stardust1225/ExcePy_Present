#!/bin/bash
cd matplotlib
git clean -xdf
git reset --hard 9ca7245788c4ac7fa245833b32d681b2ba47c45a
git reset --hard HEAD^
pip3 install -e .
cd ..
python3 test5.py
#test-Traceback
#  File "test5.py", line 7, in <module>
#    plt.show()
#  File "./matplotlib/lib/matplotlib/pyplot.py", line 337, in show
#    return _backend_mod.show(*args, **kwargs)
#  File "./matplotlib/lib/matplotlib/backend_bases.py", line 3520, in show
#    manager.show()  # Emits a warning for non-interactive backend.
#  File "./matplotlib/lib/matplotlib/backends/backend_gtk3.py", line 446, in show
#    self.canvas.draw()
#  File "./matplotlib/lib/matplotlib/backends/backend_gtk3agg.py", line 70, in draw
#    backend_agg.FigureCanvasAgg.draw(self)
#  File "./matplotlib/lib/matplotlib/backends/backend_agg.py", line 407, in draw
#    self.figure.draw(self.renderer)
#  File "./matplotlib/lib/matplotlib/artist.py", line 41, in draw_wrapper
#    return draw(artist, renderer, *args, **kwargs)
#  File "./matplotlib/lib/matplotlib/figure.py", line 1863, in draw
#    mimage._draw_list_compositing_images(
#  File "./matplotlib/lib/matplotlib/image.py", line 132, in _draw_list_compositing_images
#    a.draw(renderer)
#  File "./matplotlib/lib/matplotlib/artist.py", line 41, in draw_wrapper
#    return draw(artist, renderer, *args, **kwargs)
#  File "./matplotlib/lib/mpl_toolkits/mplot3d/axes3d.py", line 445, in draw
#    sorted(self.collections,
#  File "./matplotlib/lib/mpl_toolkits/mplot3d/axes3d.py", line 446, in <lambda>
#    key=lambda col: col.do_3d_projection(renderer),
#  File "./matplotlib/lib/mpl_toolkits/mplot3d/art3d.py", line 510, in do_3d_projection
#    fcs = fcs[z_markers_idx]
#IndexError: index 1 is out of bounds for axis 0 with size 1
#test-errorfilepath
#./matplotlib/lib/mpl_toolkits/mplot3d/art3d.py
