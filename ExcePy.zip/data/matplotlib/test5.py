import matplotlib.pyplot as plt

fig = plt.figure()
ax = fig.gca(projection="3d")
ax.scatter([0, 1], [0, 1], [0, 1], c="royalblue", marker="o",
           depthshade=False, s=60, label="H")
plt.show()
