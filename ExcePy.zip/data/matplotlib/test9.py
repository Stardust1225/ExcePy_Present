from decimal import Decimal
import matplotlib.pyplot as plt

plt.subplot(111)
x = [Decimal(x) for x in range(10)]
y = [Decimal(x) for x in range(10)]
plt.bar(x, y)
plt.show()
