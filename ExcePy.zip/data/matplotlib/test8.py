from matplotlib import gridspec

ss = gridspec.GridSpec(2, 2, height_ratios=(3, 1), width_ratios=(1, 3))
repr(ss)
