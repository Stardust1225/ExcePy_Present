import argparse
import json
import os

exception_record = None
current_project = None

with open("record.json", "r", encoding="utf-8") as record_file:
    exception_record = json.loads(record_file.read())

parser = argparse.ArgumentParser()
parser.add_argument("--list", help="List exceptions", metavar="--l", action="store_const", const=1)
parser.add_argument("--init_project", help="Init corresponding project", dest="project", default=None)
parser.add_argument("--init_test", help="Use exception ID to get corresponding fault version and test code",
                    dest="hash_id_init_test", default=-1)
parser.add_argument("--run_test", help="Run corresponding test code", dest="hash_id_run", default=-1)
parser.add_argument("--get_traceback", help="Get corresponding traceback of the exception", dest="hash_id_traceback",
                    default=-1)
parser.add_argument("--get_install_commands", help="Get the install commands for specific test case", dest="hash_id_install",
                    default=-1)

args = parser.parse_args()

if args.list == 1:
    for repo_name in exception_record.keys():
        print("project:  " + repo_name)
        project = exception_record[repo_name]
        for id in project.keys():
            print("ID: " + id + "      " +
                  "TYPE: " + project[id]["exception"] + "      " +
                  "COMMIT: " + project[id]["fixed_commit"])
        print()

if args.project != None:
    for filename in os.listdir(r"."):
        if filename.__contains__("ExceptionsInPy") \
                or filename.__contains__("data") \
                or filename.__contains__("record"):
            pass
        else:
            os.system("rm -rf " + filename)

    for file in os.listdir("./data/" + args.project):
        if ".sh" in file:
            os.system("dos2unix ./data/" + args.project + "/" + file)
            os.system("chmod +x ./data/" + args.project + "/" + file)

    os.system("cp -rf ./data/" + args.project + "/init.sh .")
    os.system("dos2unix init.sh")
    os.system("chmod +x init.sh")
    with open("./data/" + args.project + "/init.sh", "r") as command_file:
        os.system(command_file.read())

    print("Current project has tests: ")
    for id in exception_record[args.project].keys():
        print(id)

if args.hash_id_init_test != -1:
    for repo_name in exception_record.keys():
        for id in exception_record[repo_name].keys():
            if id == args.hash_id_init_test:
                onetest = exception_record[repo_name][id]
                project = onetest["repo_short"]
                os.system("cp -rf ./data/" + project + "/" + onetest["test_code"].replace(".py", ".*") + " .")
                with open(onetest["test_code"].replace(".py", ".sh"), "r") as command_file:
                    os.system(command_file.read())

if args.hash_id_run != -1:
    for repo_name in exception_record.keys():
        for id in exception_record[repo_name].keys():
            if id == args.hash_id_run:
                onetest = exception_record[repo_name][id]
                os.system(onetest["run_command"])

if args.hash_id_traceback != -1:
    for repo_name in exception_record.keys():
        for id in exception_record[repo_name].keys():
            if id == args.hash_id_traceback:
                onetest = exception_record[repo_name][id]
                print("Traceback: ")
                print(onetest["traceback"])

if args.hash_id_install != -1:
    for repo_name in exception_record.keys():
        for id in exception_record[repo_name].keys():
            if id == args.hash_id_install:
                onetest = exception_record[repo_name][id]
                print("Install commands: ")
                print(onetest["install_command"])